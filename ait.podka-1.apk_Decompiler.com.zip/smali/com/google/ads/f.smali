###### Class com.google.ads.f (com.google.ads.f)
.class public final enum Lcom/google/ads/f;
.super Ljava/lang/Enum;


# static fields
.field public static final enum a:Lcom/google/ads/f;

.field public static final enum b:Lcom/google/ads/f;

.field public static final enum c:Lcom/google/ads/f;

.field private static final synthetic d:[Lcom/google/ads/f;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/google/ads/f;

    const-string v1, "UNKNOWN"

    invoke-direct {v0, v1, v2}, Lcom/google/ads/f;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/google/ads/f;->a:Lcom/google/ads/f;

    new-instance v0, Lcom/google/ads/f;

    const-string v1, "MALE"

    invoke-direct {v0, v1, v3}, Lcom/google/ads/f;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/google/ads/f;->b:Lcom/google/ads/f;

    new-instance v0, Lcom/google/ads/f;

    const-string v1, "FEMALE"

    invoke-direct {v0, v1, v4}, Lcom/google/ads/f;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/google/ads/f;->c:Lcom/google/ads/f;

    const/4 v0, 0x3

    new-array v0, v0, [Lcom/google/ads/f;

    sget-object v1, Lcom/google/ads/f;->a:Lcom/google/ads/f;

    aput-object v1, v0, v2

    sget-object v1, Lcom/google/ads/f;->b:Lcom/google/ads/f;

    aput-object v1, v0, v3

    sget-object v1, Lcom/google/ads/f;->c:Lcom/google/ads/f;

    aput-object v1, v0, v4

    sput-object v0, Lcom/google/ads/f;->d:[Lcom/google/ads/f;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/ads/f;
    .registers 2

    const-class v0, Lcom/google/ads/f;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/google/ads/f;

    return-object v0
.end method

.method public static values()[Lcom/google/ads/f;
    .registers 1

    sget-object v0, Lcom/google/ads/f;->d:[Lcom/google/ads/f;

    invoke-virtual {v0}, [Lcom/google/ads/f;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/google/ads/f;

    return-object v0
.end method
