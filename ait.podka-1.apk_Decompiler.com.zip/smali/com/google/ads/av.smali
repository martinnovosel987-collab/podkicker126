###### Class com.google.ads.av (com.google.ads.av)
.class public final Lcom/google/ads/av;
.super Ljava/io/IOException;


# direct methods
.method constructor <init>()V
    .registers 2

    const-string v0, "CodedOutputStream was writing to a flat byte array and ran out of space."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    return-void
.end method
