###### Class com.google.ads.bt (com.google.ads.bt)
.class public final Lcom/google/ads/bt;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/bs;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
    .registers 5

    const-string v0, "name"

    invoke-virtual {p2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_10

    const-string v0, "Error: App event with no name parameter."

    invoke-static {v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;)V

    :goto_f
    return-void

    :cond_10
    const-string v0, "info"

    invoke-virtual {p2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, Lcom/google/ads/internal/t;->u()V

    goto :goto_f
.end method
