###### Class com.google.ads.bb (com.google.ads.bb)
.class public final Lcom/google/ads/bb;
.super Ljava/lang/Object;


# instance fields
.field final a:Lcom/google/ads/internal/t;

.field public b:Ljava/lang/Thread;

.field public final c:Ljava/lang/Object;

.field public d:Z

.field public final e:Ljava/lang/Object;

.field private f:Lcom/google/ads/bi;

.field private final g:Ljava/lang/Object;


# direct methods
.method protected constructor <init>()V
    .registers 3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/google/ads/bb;->f:Lcom/google/ads/bi;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/bb;->g:Ljava/lang/Object;

    iput-object v1, p0, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/bb;->c:Ljava/lang/Object;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/google/ads/bb;->d:Z

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/bb;->e:Ljava/lang/Object;

    iput-object v1, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    return-void
.end method

.method public constructor <init>(Lcom/google/ads/internal/t;)V
    .registers 4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/google/ads/bb;->f:Lcom/google/ads/bi;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/bb;->g:Ljava/lang/Object;

    iput-object v1, p0, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/bb;->c:Ljava/lang/Object;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/google/ads/bb;->d:Z

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/bb;->e:Ljava/lang/Object;

    invoke-static {p1}, Lcom/google/ads/util/c;->a(Ljava/lang/Object;)V

    iput-object p1, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    return-void
.end method

.method private b()Z
    .registers 3

    iget-object v1, p0, Lcom/google/ads/bb;->c:Ljava/lang/Object;

    monitor-enter v1

    :try_start_3
    iget-object v0, p0, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    if-eqz v0, :cond_a

    const/4 v0, 0x1

    :goto_8
    monitor-exit v1
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_c

    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_8

    :catchall_c
    move-exception v0

    monitor-exit v1

    throw v0
.end method


# virtual methods
.method public final a(Lcom/google/ads/ay;Lcom/google/ads/d;)V
    .registers 8

    iget-object v1, p0, Lcom/google/ads/bb;->c:Ljava/lang/Object;

    monitor-enter v1

    :try_start_3
    invoke-direct {p0}, Lcom/google/ads/bb;->b()Z

    move-result v0

    if-eqz v0, :cond_10

    const-string v0, "Mediation thread is not done executing previous mediation  request. Ignoring new mediation request"

    invoke-static {v0}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    monitor-exit v1

    :goto_f
    return-void

    :cond_10
    invoke-virtual {p1}, Lcom/google/ads/ay;->d()Z

    move-result v0

    if-eqz v0, :cond_64

    iget-object v0, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {p1}, Lcom/google/ads/ay;->e()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v2}, Lcom/google/ads/internal/t;->a(F)V

    iget-object v0, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->q()Z

    move-result v0

    if-nez v0, :cond_2d

    iget-object v0, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->g()V

    :cond_2d
    :goto_2d
    iget-object v0, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {p1}, Lcom/google/ads/ay;->j()Lcom/google/ads/internal/z;

    move-result-object v2

    if-eqz v2, :cond_4e

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/ads/br;->b()Z

    move-result v2

    if-eqz v2, :cond_72

    invoke-virtual {p1}, Lcom/google/ads/ay;->j()Lcom/google/ads/internal/z;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/ads/internal/z;->a()Z

    move-result v0

    if-nez v0, :cond_4e

    const-string v0, "InterstitialAd received a mediation response corresponding to a non-interstitial ad. Make sure you specify \'interstitial\' as the ad-type in the mediation UI."

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    :cond_4e
    :goto_4e
    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Lcom/google/ads/bc;

    invoke-direct {v2, p0, p1, p2}, Lcom/google/ads/bc;-><init>(Lcom/google/ads/bb;Lcom/google/ads/ay;Lcom/google/ads/d;)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    iget-object v0, p0, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    monitor-exit v1
    :try_end_60
    .catchall {:try_start_3 .. :try_end_60} :catchall_61

    goto :goto_f

    :catchall_61
    move-exception v0

    monitor-exit v1

    throw v0

    :cond_64
    :try_start_64
    iget-object v0, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->q()Z

    move-result v0

    if-eqz v0, :cond_2d

    iget-object v0, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->f()V

    goto :goto_2d

    :cond_72
    invoke-virtual {v0}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v0

    iget-object v0, v0, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/z;

    invoke-virtual {v0}, Lcom/google/ads/internal/z;->c()Lcom/google/ads/g;

    move-result-object v0

    invoke-virtual {p1}, Lcom/google/ads/ay;->j()Lcom/google/ads/internal/z;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/ads/internal/z;->a()Z

    move-result v2

    if-eqz v2, :cond_a5

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "AdView received a mediation response corresponding to an interstitial ad. Make sure you specify the banner ad size corresponding to the AdSize you used in your AdView  ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ") in the ad-type field in the mediation UI."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    goto :goto_4e

    :cond_a5
    invoke-virtual {p1}, Lcom/google/ads/ay;->j()Lcom/google/ads/internal/z;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/ads/internal/z;->c()Lcom/google/ads/g;

    move-result-object v2

    if-eq v2, v0, :cond_4e

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Mediation server returned ad size: \'"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\', while the AdView was created with ad size: \'"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\'. Using the ad-size passed to the AdView on creation."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V
    :try_end_d1
    .catchall {:try_start_64 .. :try_end_d1} :catchall_61

    goto/16 :goto_4e
.end method

.method final a()Z
    .registers 3

    iget-object v1, p0, Lcom/google/ads/bb;->e:Ljava/lang/Object;

    monitor-enter v1

    :try_start_3
    iget-boolean v0, p0, Lcom/google/ads/bb;->d:Z

    monitor-exit v1
    :try_end_6
    .catchall {:try_start_3 .. :try_end_6} :catchall_7

    return v0

    :catchall_7
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method final a(Lcom/google/ads/bi;)Z
    .registers 4

    iget-object v1, p0, Lcom/google/ads/bb;->e:Ljava/lang/Object;

    monitor-enter v1

    :try_start_3
    invoke-virtual {p0}, Lcom/google/ads/bb;->a()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p1}, Lcom/google/ads/bi;->a()V

    const/4 v0, 0x1

    monitor-exit v1
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_12

    :goto_e
    return v0

    :cond_f
    const/4 v0, 0x0

    monitor-exit v1

    goto :goto_e

    :catchall_12
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method final a(Ljava/lang/String;Landroid/app/Activity;Lcom/google/ads/d;Lcom/google/ads/bf;Ljava/util/HashMap;J)Z
    .registers 15

    new-instance v0, Lcom/google/ads/bi;

    iget-object v1, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v1}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v1

    iget-object v1, v1, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    invoke-virtual {v1}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/ads/internal/z;

    move-object v1, p0

    move-object v3, p4

    move-object v4, p1

    move-object v5, p3

    move-object v6, p5

    invoke-direct/range {v0 .. v6}, Lcom/google/ads/bi;-><init>(Lcom/google/ads/bb;Lcom/google/ads/internal/z;Lcom/google/ads/bf;Ljava/lang/String;Lcom/google/ads/d;Ljava/util/HashMap;)V

    monitor-enter v0

    :try_start_19
    invoke-virtual {v0, p2}, Lcom/google/ads/bi;->a(Landroid/app/Activity;)V
    :try_end_1c
    .catchall {:try_start_19 .. :try_end_1c} :catchall_b2

    :goto_1c
    :try_start_1c
    invoke-virtual {v0}, Lcom/google/ads/bi;->b()Z

    move-result v1

    if-nez v1, :cond_4a

    const-wide/16 v1, 0x0

    cmp-long v1, p6, v1

    if-lez v1, :cond_4a

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual {v0, p6, p7}, Ljava/lang/Object;->wait(J)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J
    :try_end_32
    .catch Ljava/lang/InterruptedException; {:try_start_1c .. :try_end_32} :catch_37
    .catchall {:try_start_1c .. :try_end_32} :catchall_b2

    move-result-wide v3

    sub-long v1, v3, v1

    sub-long/2addr p6, v1

    goto :goto_1c

    :catch_37
    move-exception v1

    :try_start_38
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Interrupted while waiting for ad network to load ad using adapter class: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    :cond_4a
    iget-object v1, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v1}, Lcom/google/ads/internal/t;->m()Lcom/google/ads/internal/y;

    move-result-object v1

    invoke-virtual {v0}, Lcom/google/ads/bi;->d()Lcom/google/ads/bh;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/google/ads/internal/y;->a(Lcom/google/ads/bh;)V

    invoke-virtual {v0}, Lcom/google/ads/bi;->b()Z

    move-result v1

    if-eqz v1, :cond_8f

    invoke-virtual {v0}, Lcom/google/ads/bi;->c()Z

    move-result v1

    if-eqz v1, :cond_8f

    iget-object v1, p0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v1}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/ads/br;->b()Z

    move-result v1

    if-eqz v1, :cond_89

    const/4 v1, 0x0

    move-object v2, v1

    :goto_71
    invoke-static {}, Lcom/google/ads/bp;->a()Lcom/google/ads/bp;

    move-result-object v1

    iget-object v1, v1, Lcom/google/ads/bp;->c:Lcom/google/ads/util/z;

    invoke-virtual {v1}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Handler;

    new-instance v3, Lcom/google/ads/be;

    invoke-direct {v3, p0, v0, v2, p4}, Lcom/google/ads/be;-><init>(Lcom/google/ads/bb;Lcom/google/ads/bi;Landroid/view/View;Lcom/google/ads/bf;)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v1, 0x1

    monitor-exit v0

    move v0, v1

    :goto_88
    return v0

    :cond_89
    invoke-virtual {v0}, Lcom/google/ads/bi;->e()Landroid/view/View;

    move-result-object v1

    move-object v2, v1

    goto :goto_71

    :cond_8f
    invoke-virtual {v0}, Lcom/google/ads/bi;->b()Z

    move-result v1

    if-nez v1, :cond_ab

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Timeout occurred in adapter class: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/google/ads/bi;->f()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    :cond_ab
    invoke-virtual {v0}, Lcom/google/ads/bi;->a()V

    const/4 v1, 0x0

    monitor-exit v0
    :try_end_b0
    .catchall {:try_start_38 .. :try_end_b0} :catchall_b2

    move v0, v1

    goto :goto_88

    :catchall_b2
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final b(Lcom/google/ads/bi;)V
    .registers 4

    iget-object v1, p0, Lcom/google/ads/bb;->g:Ljava/lang/Object;

    monitor-enter v1

    :try_start_3
    iget-object v0, p0, Lcom/google/ads/bb;->f:Lcom/google/ads/bi;

    if-eq v0, p1, :cond_12

    iget-object v0, p0, Lcom/google/ads/bb;->f:Lcom/google/ads/bi;

    if-eqz v0, :cond_10

    iget-object v0, p0, Lcom/google/ads/bb;->f:Lcom/google/ads/bi;

    invoke-virtual {v0}, Lcom/google/ads/bi;->a()V

    :cond_10
    iput-object p1, p0, Lcom/google/ads/bb;->f:Lcom/google/ads/bi;

    :cond_12
    monitor-exit v1
    :try_end_13
    .catchall {:try_start_3 .. :try_end_13} :catchall_14

    return-void

    :catchall_14
    move-exception v0

    monitor-exit v1

    throw v0
.end method
