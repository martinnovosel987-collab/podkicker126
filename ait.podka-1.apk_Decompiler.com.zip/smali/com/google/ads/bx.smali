###### Class com.google.ads.bx (com.google.ads.bx)
.class public final Lcom/google/ads/bx;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/bs;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
    .registers 6

    instance-of v0, p3, Lcom/google/ads/internal/AdWebView;

    if-eqz v0, :cond_16

    check-cast p3, Lcom/google/ads/internal/AdWebView;

    const-string v0, "1"

    const-string v1, "custom_close"

    invoke-virtual {p2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {p3, v0}, Lcom/google/ads/internal/AdWebView;->setCustomClose(Z)V

    :goto_15
    return-void

    :cond_16
    const-string v0, "Trying to set a custom close icon on a WebView that isn\'t an AdWebView"

    invoke-static {v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;)V

    goto :goto_15
.end method
