###### Class com.google.ads.br (com.google.ads.br)
.class public final Lcom/google/ads/br;
.super Lcom/google/ads/util/x;


# instance fields
.field public final a:Lcom/google/ads/util/z;

.field public final b:Lcom/google/ads/util/z;

.field public final c:Lcom/google/ads/util/ab;

.field public final d:Lcom/google/ads/util/z;

.field public final e:Lcom/google/ads/util/z;

.field public final f:Lcom/google/ads/util/z;

.field public final g:Lcom/google/ads/util/z;

.field public final h:Lcom/google/ads/util/z;

.field public final i:Lcom/google/ads/util/z;

.field public final j:Lcom/google/ads/util/z;

.field public final k:Lcom/google/ads/util/z;

.field public final l:Lcom/google/ads/util/aa;

.field public final m:Lcom/google/ads/util/aa;

.field public final n:Lcom/google/ads/util/aa;

.field public final o:Lcom/google/ads/util/aa;

.field public final p:Lcom/google/ads/util/aa;

.field public final q:Lcom/google/ads/util/aa;

.field public final r:Lcom/google/ads/util/aa;

.field public final s:Lcom/google/ads/util/aa;

.field public final t:Lcom/google/ads/util/aa;


# direct methods
.method public constructor <init>(Lcom/google/ads/bp;Lcom/google/ads/a;Lcom/google/ads/AdView;Lcom/google/ads/i;Ljava/lang/String;Landroid/app/Activity;Landroid/content/Context;Landroid/view/ViewGroup;Lcom/google/ads/internal/z;Lcom/google/ads/internal/t;)V
    .registers 15

    const/4 v0, 0x0

    invoke-direct {p0}, Lcom/google/ads/util/x;-><init>()V

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "currentAd"

    invoke-direct {v1, p0, v2, v0}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->l:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "nextAd"

    invoke-direct {v1, p0, v2, v0}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->m:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "adListener"

    invoke-direct {v1, p0, v2}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;)V

    iput-object v1, p0, Lcom/google/ads/br;->o:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "appEventListener"

    invoke-direct {v1, p0, v2}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;)V

    iput-object v1, p0, Lcom/google/ads/br;->p:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "swipeableEventListener"

    invoke-direct {v1, p0, v2}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;)V

    iput-object v1, p0, Lcom/google/ads/br;->q:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "spamSignals"

    invoke-direct {v1, p0, v2, v0}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->r:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "spamSignalsUtil"

    invoke-direct {v1, p0, v2, v0}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->s:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "usesManualImpressions"

    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-direct {v1, p0, v2, v3}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->t:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "appState"

    invoke-direct {v1, p0, v2, p1}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->d:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "ad"

    invoke-direct {v1, p0, v2, p2}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->a:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "adView"

    invoke-direct {v1, p0, v2, p3}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->j:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "adType"

    invoke-direct {v1, p0, v2, p9}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "adUnitId"

    invoke-direct {v1, p0, v2, p5}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->h:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/ab;

    const-string v2, "activity"

    invoke-direct {v1, p0, v2, p6}, Lcom/google/ads/util/ab;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->c:Lcom/google/ads/util/ab;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "interstitialAd"

    invoke-direct {v1, p0, v2, p4}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->k:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "bannerContainer"

    invoke-direct {v1, p0, v2, p8}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->i:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "applicationContext"

    invoke-direct {v1, p0, v2, p7}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->f:Lcom/google/ads/util/z;

    new-instance v1, Lcom/google/ads/util/aa;

    const-string v2, "adSizes"

    invoke-direct {v1, p0, v2, v0}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->n:Lcom/google/ads/util/aa;

    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "adManager"

    invoke-direct {v1, p0, v2, p10}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    if-eqz p9, :cond_c1

    invoke-virtual {p9}, Lcom/google/ads/internal/z;->b()Z

    move-result v1

    if-eqz v1, :cond_c1

    new-instance v0, Lcom/google/ads/internal/ActivationOverlay;

    invoke-direct {v0, p0}, Lcom/google/ads/internal/ActivationOverlay;-><init>(Lcom/google/ads/br;)V

    :cond_c1
    new-instance v1, Lcom/google/ads/util/z;

    const-string v2, "activationOverlay"

    invoke-direct {v1, p0, v2, v0}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v1, p0, Lcom/google/ads/br;->e:Lcom/google/ads/util/z;

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 2

    invoke-virtual {p0}, Lcom/google/ads/br;->b()Z

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x1

    :goto_7
    return v0

    :cond_8
    const/4 v0, 0x0

    goto :goto_7
.end method

.method public final b()Z
    .registers 2

    iget-object v0, p0, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/z;

    invoke-virtual {v0}, Lcom/google/ads/internal/z;->a()Z

    move-result v0

    return v0
.end method
