###### Class com.google.ads.aw (com.google.ads.aw)
.class public final Lcom/google/ads/aw;
.super Ljava/lang/Object;


# static fields
.field static final a:I

.field static final b:I

.field static final c:I

.field static final d:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0xb

    sput v0, Lcom/google/ads/aw;->a:I

    const/16 v0, 0xc

    sput v0, Lcom/google/ads/aw;->b:I

    const/16 v0, 0x10

    sput v0, Lcom/google/ads/aw;->c:I

    const/16 v0, 0x1a

    sput v0, Lcom/google/ads/aw;->d:I

    return-void
.end method

.method static a(II)I
    .registers 3

    shl-int/lit8 v0, p0, 0x3

    or-int/2addr v0, p1

    return v0
.end method
