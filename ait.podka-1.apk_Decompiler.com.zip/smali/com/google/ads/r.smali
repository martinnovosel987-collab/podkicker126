###### Class com.google.ads.r (com.google.ads.r)
.class interface abstract Lcom/google/ads/r;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a([B[B)V
.end method
