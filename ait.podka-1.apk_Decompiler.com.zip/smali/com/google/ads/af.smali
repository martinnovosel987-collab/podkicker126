###### Class com.google.ads.af (com.google.ads.af)
.class public interface abstract Lcom/google/ads/af;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
.end method
