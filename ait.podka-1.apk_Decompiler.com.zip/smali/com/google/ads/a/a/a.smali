###### Class com.google.ads.a.a.a (com.google.ads.a.a.a)
.class public Lcom/google/ads/a/a/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Z

.field private b:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/google/ads/a/a/a;->a:Z

    invoke-virtual {p0}, Lcom/google/ads/a/a/a;->b()Lcom/google/ads/a/a/a;

    return-void
.end method


# virtual methods
.method public b()Lcom/google/ads/a/a/a;
    .registers 2

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/google/ads/a/a/a;->b:Ljava/util/Map;

    return-object p0
.end method

.method public final c()Ljava/util/Map;
    .registers 2

    iget-object v0, p0, Lcom/google/ads/a/a/a;->b:Ljava/util/Map;

    return-object v0
.end method
