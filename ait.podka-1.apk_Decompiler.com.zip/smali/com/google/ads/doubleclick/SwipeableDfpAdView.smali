###### Class com.google.ads.doubleclick.SwipeableDfpAdView (com.google.ads.doubleclick.SwipeableDfpAdView)
.class public Lcom/google/ads/doubleclick/SwipeableDfpAdView;
.super Lcom/google/ads/doubleclick/DfpAdView;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/google/ads/doubleclick/DfpAdView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/ads/doubleclick/DfpAdView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public setSwipeableEventListener(Lcom/google/ads/j;)V
    .registers 2

    invoke-super {p0, p1}, Lcom/google/ads/doubleclick/DfpAdView;->setSwipeableEventListener(Lcom/google/ads/j;)V

    return-void
.end method
