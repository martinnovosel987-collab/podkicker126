###### Class com.google.ads.doubleclick.a (com.google.ads.doubleclick.a)
.class public Lcom/google/ads/doubleclick/a;
.super Lcom/google/ads/a/a/a;


# instance fields
.field private a:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/google/ads/a/a/a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/google/ads/doubleclick/a;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final bridge synthetic b()Lcom/google/ads/a/a/a;
    .registers 1

    invoke-super {p0}, Lcom/google/ads/a/a/a;->b()Lcom/google/ads/a/a/a;

    return-object p0
.end method
