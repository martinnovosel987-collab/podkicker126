###### Class com.google.ads.doubleclick.DfpAdView (com.google.ads.doubleclick.DfpAdView)
.class public Lcom/google/ads/doubleclick/DfpAdView;
.super Lcom/google/ads/AdView;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/google/ads/AdView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/ads/AdView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public setAppEventListener(Lcom/google/ads/h;)V
    .registers 2

    invoke-super {p0, p1}, Lcom/google/ads/AdView;->setAppEventListener(Lcom/google/ads/h;)V

    return-void
.end method

.method public varargs setSupportedAdSizes([Lcom/google/ads/g;)V
    .registers 2

    invoke-super {p0, p1}, Lcom/google/ads/AdView;->setSupportedAdSizes([Lcom/google/ads/g;)V

    return-void
.end method
