###### Class com.google.ads.bc (com.google.ads.bc)
.class final Lcom/google/ads/bc;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/ads/ay;

.field final synthetic b:Lcom/google/ads/d;

.field final synthetic c:Lcom/google/ads/bb;


# direct methods
.method constructor <init>(Lcom/google/ads/bb;Lcom/google/ads/ay;Lcom/google/ads/d;)V
    .registers 4

    iput-object p1, p0, Lcom/google/ads/bc;->c:Lcom/google/ads/bb;

    iput-object p2, p0, Lcom/google/ads/bc;->a:Lcom/google/ads/ay;

    iput-object p3, p0, Lcom/google/ads/bc;->b:Lcom/google/ads/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 16

    iget-object v9, p0, Lcom/google/ads/bc;->c:Lcom/google/ads/bb;

    iget-object v10, p0, Lcom/google/ads/bc;->a:Lcom/google/ads/ay;

    iget-object v11, p0, Lcom/google/ads/bc;->b:Lcom/google/ads/d;

    iget-object v1, v9, Lcom/google/ads/bb;->c:Ljava/lang/Object;

    monitor-enter v1

    :try_start_9
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    iget-object v2, v9, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    invoke-static {v0, v2}, Lcom/google/ads/util/c;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    monitor-exit v1
    :try_end_13
    .catchall {:try_start_9 .. :try_end_13} :catchall_95

    invoke-virtual {v10}, Lcom/google/ads/ay;->f()Ljava/util/List;

    move-result-object v0

    invoke-virtual {v10}, Lcom/google/ads/ay;->a()Z

    move-result v1

    if-eqz v1, :cond_98

    invoke-virtual {v10}, Lcom/google/ads/ay;->b()I

    move-result v1

    int-to-long v7, v1

    :goto_22
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_26
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_bf

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lcom/google/ads/k;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Looking to fetch ads from network: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v2, Lcom/google/ads/k;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    iget-object v13, v2, Lcom/google/ads/k;->c:Ljava/util/List;

    iget-object v14, v2, Lcom/google/ads/k;->e:Ljava/util/HashMap;

    iget-object v4, v2, Lcom/google/ads/k;->d:Ljava/util/List;

    new-instance v0, Lcom/google/ads/bf;

    iget-object v1, v2, Lcom/google/ads/k;->a:Ljava/lang/String;

    iget-object v2, v2, Lcom/google/ads/k;->b:Ljava/lang/String;

    invoke-virtual {v10}, Lcom/google/ads/ay;->c()Ljava/lang/String;

    move-result-object v3

    if-eqz v4, :cond_9b

    :goto_59
    invoke-virtual {v10}, Lcom/google/ads/ay;->h()Ljava/util/List;

    move-result-object v5

    invoke-virtual {v10}, Lcom/google/ads/ay;->i()Ljava/util/List;

    move-result-object v6

    invoke-direct/range {v0 .. v6}, Lcom/google/ads/bf;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_68
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_26

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v1, v9, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v1}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v1

    iget-object v1, v1, Lcom/google/ads/br;->c:Lcom/google/ads/util/ab;

    invoke-virtual {v1}, Lcom/google/ads/util/ab;->a()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/Activity;

    if-nez v3, :cond_a0

    const-string v0, "Activity is null while mediating.  Terminating mediation thread."

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    :cond_89
    :goto_89
    iget-object v0, p0, Lcom/google/ads/bc;->c:Lcom/google/ads/bb;

    iget-object v1, v0, Lcom/google/ads/bb;->c:Ljava/lang/Object;

    monitor-enter v1

    :try_start_8e
    iget-object v0, p0, Lcom/google/ads/bc;->c:Lcom/google/ads/bb;

    const/4 v2, 0x0

    iput-object v2, v0, Lcom/google/ads/bb;->b:Ljava/lang/Thread;

    monitor-exit v1
    :try_end_94
    .catchall {:try_start_8e .. :try_end_94} :catchall_d4

    return-void

    :catchall_95
    move-exception v0

    monitor-exit v1

    throw v0

    :cond_98
    const-wide/16 v7, 0x2710

    goto :goto_22

    :cond_9b
    invoke-virtual {v10}, Lcom/google/ads/ay;->g()Ljava/util/List;

    move-result-object v4

    goto :goto_59

    :cond_a0
    iget-object v1, v9, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v1}, Lcom/google/ads/internal/t;->m()Lcom/google/ads/internal/y;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/ads/internal/y;->c()V

    move-object v1, v9

    move-object v4, v11

    move-object v5, v0

    move-object v6, v14

    invoke-virtual/range {v1 .. v8}, Lcom/google/ads/bb;->a(Ljava/lang/String;Landroid/app/Activity;Lcom/google/ads/d;Lcom/google/ads/bf;Ljava/util/HashMap;J)Z

    move-result v1

    if-nez v1, :cond_89

    invoke-virtual {v9}, Lcom/google/ads/bb;->a()Z

    move-result v1

    if-eqz v1, :cond_68

    const-string v0, "GWController.destroy() called. Terminating mediation thread."

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    goto :goto_89

    :cond_bf
    invoke-static {}, Lcom/google/ads/bp;->a()Lcom/google/ads/bp;

    move-result-object v0

    iget-object v0, v0, Lcom/google/ads/bp;->c:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Handler;

    new-instance v1, Lcom/google/ads/bd;

    invoke-direct {v1, v9, v10}, Lcom/google/ads/bd;-><init>(Lcom/google/ads/bb;Lcom/google/ads/ay;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_89

    :catchall_d4
    move-exception v0

    monitor-exit v1

    throw v0
.end method
