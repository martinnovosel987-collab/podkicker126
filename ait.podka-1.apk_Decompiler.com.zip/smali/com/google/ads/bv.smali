###### Class com.google.ads.bv (com.google.ads.bv)
.class public final Lcom/google/ads/bv;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/bs;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
    .registers 10

    const-string v0, "u"

    invoke-virtual {p2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_10

    const-string v0, "Could not get URL from click gmsg."

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    :goto_f
    return-void

    :cond_10
    invoke-virtual {p1}, Lcom/google/ads/internal/t;->m()Lcom/google/ads/internal/y;

    move-result-object v2

    if-eqz v2, :cond_5f

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v3}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_5f

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v1, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v4, ".admob.com"

    invoke-virtual {v1, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5f

    const/4 v1, 0x0

    invoke-virtual {v3}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_5c

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v4, v3

    const/4 v5, 0x4

    if-lt v4, v5, :cond_5c

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    aget-object v4, v3, v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, "/"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/4 v4, 0x3

    aget-object v3, v3, v4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_5c
    invoke-virtual {v2, v1}, Lcom/google/ads/internal/y;->a(Ljava/lang/String;)V

    :cond_5f
    invoke-virtual {p1}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v2

    iget-object v1, v2, Lcom/google/ads/br;->f:Lcom/google/ads/util/z;

    invoke-virtual {v1}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Context;

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    :try_start_6f
    iget-object v2, v2, Lcom/google/ads/br;->s:Lcom/google/ads/util/aa;

    invoke-virtual {v2}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/ads/aj;

    if-eqz v2, :cond_a9

    invoke-virtual {v2, v3}, Lcom/google/ads/aj;->a(Landroid/net/Uri;)Z

    move-result v4

    if-eqz v4, :cond_a9

    invoke-virtual {v2, v3, v1}, Lcom/google/ads/aj;->a(Landroid/net/Uri;Landroid/content/Context;)Landroid/net/Uri;
    :try_end_82
    .catch Lcom/google/ads/ak; {:try_start_6f .. :try_end_82} :catch_96

    move-result-object v0

    :goto_83
    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/google/ads/o;

    invoke-direct {v3, v0, v1}, Lcom/google/ads/o;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    goto/16 :goto_f

    :catch_96
    move-exception v2

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Unable to append parameter to URL: "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    :cond_a9
    move-object v0, v3

    goto :goto_83
.end method
