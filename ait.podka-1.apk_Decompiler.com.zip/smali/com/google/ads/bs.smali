###### Class com.google.ads.bs (com.google.ads.bs)
.class public interface abstract Lcom/google/ads/bs;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
.end method
