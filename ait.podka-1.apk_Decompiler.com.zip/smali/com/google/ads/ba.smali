###### Class com.google.ads.ba (com.google.ads.ba)
.class public final Lcom/google/ads/ba;
.super Ljava/lang/Object;


# instance fields
.field public a:Lcom/google/ads/ay;

.field public b:J


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/google/ads/ba;->a:Lcom/google/ads/ay;

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/google/ads/ba;->b:J

    return-void
.end method
