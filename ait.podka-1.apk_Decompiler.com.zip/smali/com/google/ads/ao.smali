###### Class com.google.ads.ao (com.google.ads.ao)
.class public final Lcom/google/ads/ao;
.super Ljava/lang/Object;


# static fields
.field private static final a:[C

.field private static final b:[C

.field private static final c:[B

.field private static final d:[B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v1, 0x80

    const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    sput-object v0, Lcom/google/ads/ao;->a:[C

    const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    sput-object v0, Lcom/google/ads/ao;->b:[C

    new-array v0, v1, [B

    fill-array-data v0, :array_22

    sput-object v0, Lcom/google/ads/ao;->c:[B

    new-array v0, v1, [B

    fill-array-data v0, :array_66

    sput-object v0, Lcom/google/ads/ao;->d:[B

    return-void

    nop

    :array_22
    .array-data 1
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x5t
        -0x5t
        -0x9t
        -0x9t
        -0x5t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x5t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        0x3et
        -0x9t
        -0x9t
        -0x9t
        0x3ft
        0x34t
        0x35t
        0x36t
        0x37t
        0x38t
        0x39t
        0x3at
        0x3bt
        0x3ct
        0x3dt
        -0x9t
        -0x9t
        -0x9t
        -0x1t
        -0x9t
        -0x9t
        -0x9t
        0x0t
        0x1t
        0x2t
        0x3t
        0x4t
        0x5t
        0x6t
        0x7t
        0x8t
        0x9t
        0xat
        0xbt
        0xct
        0xdt
        0xet
        0xft
        0x10t
        0x11t
        0x12t
        0x13t
        0x14t
        0x15t
        0x16t
        0x17t
        0x18t
        0x19t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        0x1at
        0x1bt
        0x1ct
        0x1dt
        0x1et
        0x1ft
        0x20t
        0x21t
        0x22t
        0x23t
        0x24t
        0x25t
        0x26t
        0x27t
        0x28t
        0x29t
        0x2at
        0x2bt
        0x2ct
        0x2dt
        0x2et
        0x2ft
        0x30t
        0x31t
        0x32t
        0x33t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
    .end array-data

    :array_66
    .array-data 1
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x5t
        -0x5t
        -0x9t
        -0x9t
        -0x5t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x5t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        0x3et
        -0x9t
        -0x9t
        0x34t
        0x35t
        0x36t
        0x37t
        0x38t
        0x39t
        0x3at
        0x3bt
        0x3ct
        0x3dt
        -0x9t
        -0x9t
        -0x9t
        -0x1t
        -0x9t
        -0x9t
        -0x9t
        0x0t
        0x1t
        0x2t
        0x3t
        0x4t
        0x5t
        0x6t
        0x7t
        0x8t
        0x9t
        0xat
        0xbt
        0xct
        0xdt
        0xet
        0xft
        0x10t
        0x11t
        0x12t
        0x13t
        0x14t
        0x15t
        0x16t
        0x17t
        0x18t
        0x19t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        0x3ft
        -0x9t
        0x1at
        0x1bt
        0x1ct
        0x1dt
        0x1et
        0x1ft
        0x20t
        0x21t
        0x22t
        0x23t
        0x24t
        0x25t
        0x26t
        0x27t
        0x28t
        0x29t
        0x2at
        0x2bt
        0x2ct
        0x2dt
        0x2et
        0x2ft
        0x30t
        0x31t
        0x32t
        0x33t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
        -0x9t
    .end array-data
.end method

.method private static a([C[BI[B)I
    .registers 10

    const/16 v5, 0x3d

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    aget-char v3, p0, v1

    if-ne v3, v5, :cond_21

    aget-char v1, p0, v4

    aget-byte v1, p3, v1

    shl-int/lit8 v1, v1, 0x18

    ushr-int/lit8 v1, v1, 0x6

    aget-char v2, p0, v0

    aget-byte v2, p3, v2

    shl-int/lit8 v2, v2, 0x18

    ushr-int/lit8 v2, v2, 0xc

    or-int/2addr v1, v2

    ushr-int/lit8 v1, v1, 0x10

    int-to-byte v1, v1

    aput-byte v1, p1, p2

    :goto_20
    return v0

    :cond_21
    aget-char v3, p0, v2

    if-ne v3, v5, :cond_4d

    aget-char v2, p0, v4

    aget-byte v2, p3, v2

    shl-int/lit8 v2, v2, 0x18

    ushr-int/lit8 v2, v2, 0x6

    aget-char v0, p0, v0

    aget-byte v0, p3, v0

    shl-int/lit8 v0, v0, 0x18

    ushr-int/lit8 v0, v0, 0xc

    or-int/2addr v0, v2

    aget-char v2, p0, v1

    aget-byte v2, p3, v2

    shl-int/lit8 v2, v2, 0x18

    ushr-int/lit8 v2, v2, 0x12

    or-int/2addr v0, v2

    ushr-int/lit8 v2, v0, 0x10

    int-to-byte v2, v2

    aput-byte v2, p1, p2

    add-int/lit8 v2, p2, 0x1

    ushr-int/lit8 v0, v0, 0x8

    int-to-byte v0, v0

    aput-byte v0, p1, v2

    move v0, v1

    goto :goto_20

    :cond_4d
    aget-char v3, p0, v4

    aget-byte v3, p3, v3

    shl-int/lit8 v3, v3, 0x18

    ushr-int/lit8 v3, v3, 0x6

    aget-char v0, p0, v0

    aget-byte v0, p3, v0

    shl-int/lit8 v0, v0, 0x18

    ushr-int/lit8 v0, v0, 0xc

    or-int/2addr v0, v3

    aget-char v1, p0, v1

    aget-byte v1, p3, v1

    shl-int/lit8 v1, v1, 0x18

    ushr-int/lit8 v1, v1, 0x12

    or-int/2addr v0, v1

    aget-char v1, p0, v2

    aget-byte v1, p3, v1

    shl-int/lit8 v1, v1, 0x18

    ushr-int/lit8 v1, v1, 0x18

    or-int/2addr v0, v1

    shr-int/lit8 v1, v0, 0x10

    int-to-byte v1, v1

    aput-byte v1, p1, p2

    add-int/lit8 v1, p2, 0x1

    shr-int/lit8 v3, v0, 0x8

    int-to-byte v3, v3

    aput-byte v3, p1, v1

    add-int/lit8 v1, p2, 0x2

    int-to-byte v0, v0

    aput-byte v0, p1, v1

    move v0, v2

    goto :goto_20
.end method

.method public static a([B)Ljava/lang/String;
    .registers 15

    const/16 v13, 0xa

    const v12, 0x7fffffff

    const/16 v11, 0x3d

    const/4 v1, 0x0

    array-length v5, p0

    sget-object v6, Lcom/google/ads/ao;->b:[C

    add-int/lit8 v0, v5, 0x2

    div-int/lit8 v0, v0, 0x3

    mul-int/lit8 v0, v0, 0x4

    div-int v2, v0, v12

    add-int/2addr v0, v2

    new-array v7, v0, [C

    add-int/lit8 v8, v5, -0x2

    move v4, v1

    move v2, v1

    move v3, v1

    :goto_1b
    if-ge v3, v8, :cond_6f

    add-int/lit8 v0, v3, 0x0

    aget-byte v0, p0, v0

    shl-int/lit8 v0, v0, 0x18

    ushr-int/lit8 v0, v0, 0x8

    add-int/lit8 v9, v3, 0x1

    add-int/lit8 v9, v9, 0x0

    aget-byte v9, p0, v9

    shl-int/lit8 v9, v9, 0x18

    ushr-int/lit8 v9, v9, 0x10

    or-int/2addr v0, v9

    add-int/lit8 v9, v3, 0x2

    add-int/lit8 v9, v9, 0x0

    aget-byte v9, p0, v9

    shl-int/lit8 v9, v9, 0x18

    ushr-int/lit8 v9, v9, 0x18

    or-int/2addr v0, v9

    ushr-int/lit8 v9, v0, 0x12

    aget-char v9, v6, v9

    aput-char v9, v7, v2

    add-int/lit8 v9, v2, 0x1

    ushr-int/lit8 v10, v0, 0xc

    and-int/lit8 v10, v10, 0x3f

    aget-char v10, v6, v10

    aput-char v10, v7, v9

    add-int/lit8 v9, v2, 0x2

    ushr-int/lit8 v10, v0, 0x6

    and-int/lit8 v10, v10, 0x3f

    aget-char v10, v6, v10

    aput-char v10, v7, v9

    add-int/lit8 v9, v2, 0x3

    and-int/lit8 v0, v0, 0x3f

    aget-char v0, v6, v0

    aput-char v0, v7, v9

    add-int/lit8 v0, v4, 0x4

    if-ne v0, v12, :cond_69

    add-int/lit8 v0, v2, 0x4

    aput-char v13, v7, v0

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    move v0, v1

    :cond_69
    add-int/lit8 v3, v3, 0x3

    add-int/lit8 v2, v2, 0x4

    move v4, v0

    goto :goto_1b

    :cond_6f
    if-ge v3, v5, :cond_a0

    add-int/lit8 v8, v3, 0x0

    sub-int/2addr v5, v3

    if-lez v5, :cond_ac

    aget-byte v0, p0, v8

    shl-int/lit8 v0, v0, 0x18

    ushr-int/lit8 v0, v0, 0x8

    move v3, v0

    :goto_7d
    const/4 v0, 0x1

    if-le v5, v0, :cond_ae

    add-int/lit8 v0, v8, 0x1

    aget-byte v0, p0, v0

    shl-int/lit8 v0, v0, 0x18

    ushr-int/lit8 v0, v0, 0x10

    :goto_88
    or-int/2addr v3, v0

    const/4 v0, 0x2

    if-le v5, v0, :cond_b0

    add-int/lit8 v0, v8, 0x2

    aget-byte v0, p0, v0

    shl-int/lit8 v0, v0, 0x18

    ushr-int/lit8 v0, v0, 0x18

    :goto_94
    or-int/2addr v0, v3

    packed-switch v5, :pswitch_data_114

    :goto_98
    add-int/lit8 v0, v4, 0x4

    if-ne v0, v12, :cond_a0

    add-int/lit8 v0, v2, 0x4

    aput-char v13, v7, v0

    :cond_a0
    array-length v0, v7

    :goto_a1
    if-lez v0, :cond_10d

    add-int/lit8 v2, v0, -0x1

    aget-char v2, v7, v2

    if-ne v2, v11, :cond_10d

    add-int/lit8 v0, v0, -0x1

    goto :goto_a1

    :cond_ac
    move v3, v1

    goto :goto_7d

    :cond_ae
    move v0, v1

    goto :goto_88

    :cond_b0
    move v0, v1

    goto :goto_94

    :pswitch_b2
    ushr-int/lit8 v3, v0, 0x12

    aget-char v3, v6, v3

    aput-char v3, v7, v2

    add-int/lit8 v3, v2, 0x1

    ushr-int/lit8 v5, v0, 0xc

    and-int/lit8 v5, v5, 0x3f

    aget-char v5, v6, v5

    aput-char v5, v7, v3

    add-int/lit8 v3, v2, 0x2

    ushr-int/lit8 v5, v0, 0x6

    and-int/lit8 v5, v5, 0x3f

    aget-char v5, v6, v5

    aput-char v5, v7, v3

    add-int/lit8 v3, v2, 0x3

    and-int/lit8 v0, v0, 0x3f

    aget-char v0, v6, v0

    aput-char v0, v7, v3

    goto :goto_98

    :pswitch_d5
    ushr-int/lit8 v3, v0, 0x12

    aget-char v3, v6, v3

    aput-char v3, v7, v2

    add-int/lit8 v3, v2, 0x1

    ushr-int/lit8 v5, v0, 0xc

    and-int/lit8 v5, v5, 0x3f

    aget-char v5, v6, v5

    aput-char v5, v7, v3

    add-int/lit8 v3, v2, 0x2

    ushr-int/lit8 v0, v0, 0x6

    and-int/lit8 v0, v0, 0x3f

    aget-char v0, v6, v0

    aput-char v0, v7, v3

    add-int/lit8 v0, v2, 0x3

    aput-char v11, v7, v0

    goto :goto_98

    :pswitch_f4
    ushr-int/lit8 v3, v0, 0x12

    aget-char v3, v6, v3

    aput-char v3, v7, v2

    add-int/lit8 v3, v2, 0x1

    ushr-int/lit8 v0, v0, 0xc

    and-int/lit8 v0, v0, 0x3f

    aget-char v0, v6, v0

    aput-char v0, v7, v3

    add-int/lit8 v0, v2, 0x2

    aput-char v11, v7, v0

    add-int/lit8 v0, v2, 0x3

    aput-char v11, v7, v0

    goto :goto_98

    :cond_10d
    new-instance v2, Ljava/lang/String;

    invoke-direct {v2, v7, v1, v0}, Ljava/lang/String;-><init>([CII)V

    return-object v2

    nop

    :pswitch_data_114
    .packed-switch 0x1
        :pswitch_f4
        :pswitch_d5
        :pswitch_b2
    .end packed-switch
.end method

.method public static a(Ljava/lang/String;)[B
    .registers 13

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v5

    array-length v6, v5

    sget-object v7, Lcom/google/ads/ao;->c:[B

    mul-int/lit8 v0, v6, 0x3

    div-int/lit8 v0, v0, 0x4

    add-int/lit8 v0, v0, 0x2

    new-array v8, v0, [B

    const/4 v3, 0x0

    const/4 v0, 0x4

    new-array v9, v0, [C

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    move v4, v1

    move v1, v2

    :goto_18
    if-ge v4, v6, :cond_b8

    add-int/lit8 v2, v4, 0x0

    aget-char v2, v5, v2

    and-int/lit8 v10, v2, 0x7f

    int-to-char v10, v10

    aget-byte v11, v7, v10

    if-ne v10, v2, :cond_51

    const/4 v2, -0x5

    if-ge v11, v2, :cond_51

    new-instance v0, Lcom/google/ads/an;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Bad Base64 input character at "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    add-int/lit8 v2, v4, 0x0

    aget-char v2, v5, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "(decimal)"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/ads/an;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_51
    const/4 v2, -0x1

    if-lt v11, v2, :cond_e8

    const/16 v2, 0x3d

    if-ne v10, v2, :cond_92

    if-nez v0, :cond_e8

    const/4 v0, 0x2

    if-ge v4, v0, :cond_72

    new-instance v0, Lcom/google/ads/an;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid padding char found in position "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/ads/an;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_72
    const/4 v0, 0x1

    add-int/lit8 v2, v6, -0x1

    add-int/lit8 v2, v2, 0x0

    aget-char v2, v5, v2

    and-int/lit8 v2, v2, 0x7f

    int-to-char v2, v2

    const/16 v10, 0x3d

    if-eq v2, v10, :cond_8c

    const/16 v10, 0xa

    if-eq v2, v10, :cond_8c

    new-instance v0, Lcom/google/ads/an;

    const-string v1, "encoded value has invalid trailing char"

    invoke-direct {v0, v1}, Lcom/google/ads/an;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8c
    move v2, v3

    :goto_8d
    add-int/lit8 v3, v4, 0x1

    move v4, v3

    move v3, v2

    goto :goto_18

    :cond_92
    if-eqz v0, :cond_a9

    new-instance v0, Lcom/google/ads/an;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Data found after trailing padding char at index "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/ads/an;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a9
    add-int/lit8 v2, v1, 0x1

    aput-char v10, v9, v1

    const/4 v1, 0x4

    if-ne v2, v1, :cond_e5

    invoke-static {v9, v8, v3, v7}, Lcom/google/ads/ao;->a([C[BI[B)I

    move-result v1

    add-int v2, v3, v1

    const/4 v1, 0x0

    goto :goto_8d

    :cond_b8
    if-eqz v1, :cond_dd

    const/4 v0, 0x1

    if-ne v1, v0, :cond_d4

    new-instance v0, Lcom/google/ads/an;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "single trailing character at offset "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    add-int/lit8 v2, v6, -0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/ads/an;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d4
    const/16 v0, 0x3d

    aput-char v0, v9, v1

    invoke-static {v9, v8, v3, v7}, Lcom/google/ads/ao;->a([C[BI[B)I

    move-result v0

    add-int/2addr v3, v0

    :cond_dd
    new-array v0, v3, [B

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v8, v1, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v0

    :cond_e5
    move v1, v2

    move v2, v3

    goto :goto_8d

    :cond_e8
    move v2, v3

    goto :goto_8d
.end method
