###### Class com.google.ads.ca (com.google.ads.ca)
.class public final Lcom/google/ads/ca;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/bs;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
    .registers 16

    const/4 v11, 0x1

    const/4 v6, 0x0

    const-string v0, "url"

    invoke-virtual {p2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "type"

    invoke-virtual {p2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "afma_notify_dt"

    invoke-virtual {p2, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v3, "activation_overlay_url"

    invoke-virtual {p2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const-string v4, "check_packages"

    invoke-virtual {p2, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const-string v5, "1"

    const-string v7, "drt_include"

    invoke-virtual {p2, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const-string v5, "request_scenario"

    invoke-virtual {p2, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    const-string v8, "1"

    const-string v9, "use_webview_loadurl"

    invoke-virtual {p2, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    sget-object v9, Lcom/google/ads/internal/r;->d:Lcom/google/ads/internal/r;

    iget-object v9, v9, Lcom/google/ads/internal/r;->e:Ljava/lang/String;

    invoke-virtual {v9, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_d0

    sget-object v5, Lcom/google/ads/internal/r;->d:Lcom/google/ads/internal/r;

    :goto_56
    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "Received ad url: <url: \""

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "\" type: \""

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v9, "\" afmaNotifyDt: \""

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\" activationOverlayUrl: \""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\" useWebViewLoadUrl: \""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\">"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11d

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11d

    new-instance v1, Ljava/math/BigInteger;

    new-array v2, v11, [B

    invoke-direct {v1, v2}, Ljava/math/BigInteger;-><init>([B)V

    const-string v2, ","

    invoke-virtual {v4, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    move v2, v6

    move-object v4, v1

    :goto_b1
    array-length v1, v9

    if-ge v2, v1, :cond_f0

    invoke-virtual {p1}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v1

    iget-object v1, v1, Lcom/google/ads/br;->c:Lcom/google/ads/util/ab;

    invoke-virtual {v1}, Lcom/google/ads/util/ab;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Context;

    aget-object v10, v9, v2

    invoke-static {v1, v10}, Lcom/google/ads/util/AdUtil;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_cc

    invoke-virtual {v4, v2}, Ljava/math/BigInteger;->setBit(I)Ljava/math/BigInteger;

    move-result-object v4

    :cond_cc
    add-int/lit8 v1, v2, 0x1

    move v2, v1

    goto :goto_b1

    :cond_d0
    sget-object v9, Lcom/google/ads/internal/r;->c:Lcom/google/ads/internal/r;

    iget-object v9, v9, Lcom/google/ads/internal/r;->e:Ljava/lang/String;

    invoke-virtual {v9, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_de

    sget-object v5, Lcom/google/ads/internal/r;->c:Lcom/google/ads/internal/r;

    goto/16 :goto_56

    :cond_de
    sget-object v9, Lcom/google/ads/internal/r;->a:Lcom/google/ads/internal/r;

    iget-object v9, v9, Lcom/google/ads/internal/r;->e:Ljava/lang/String;

    invoke-virtual {v9, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_ec

    sget-object v5, Lcom/google/ads/internal/r;->a:Lcom/google/ads/internal/r;

    goto/16 :goto_56

    :cond_ec
    sget-object v5, Lcom/google/ads/internal/r;->b:Lcom/google/ads/internal/r;

    goto/16 :goto_56

    :cond_f0
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v2, "%X"

    new-array v9, v11, [Ljava/lang/Object;

    aput-object v4, v9, v6

    invoke-static {v1, v2, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "%40installed_markets%40"

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/google/ads/bp;->a()Lcom/google/ads/bp;

    move-result-object v2

    iget-object v2, v2, Lcom/google/ads/bp;->a:Lcom/google/ads/util/aa;

    invoke-virtual {v2, v1}, Lcom/google/ads/util/aa;->a(Ljava/lang/Object;)V

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Ad url modified to "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    :cond_11d
    invoke-virtual {p1}, Lcom/google/ads/internal/t;->j()Lcom/google/ads/internal/k;

    move-result-object v1

    if-eqz v1, :cond_132

    invoke-virtual {v1, v7}, Lcom/google/ads/internal/k;->c(Z)V

    invoke-virtual {v1, v5}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/internal/r;)V

    invoke-virtual {v1, v8}, Lcom/google/ads/internal/k;->d(Z)V

    invoke-virtual {v1, v3}, Lcom/google/ads/internal/k;->e(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lcom/google/ads/internal/k;->d(Ljava/lang/String;)V

    :cond_132
    return-void
.end method
