###### Class com.google.ads.a (com.google.ads.a)
.class public interface abstract Lcom/google/ads/a;
.super Ljava/lang/Object;
