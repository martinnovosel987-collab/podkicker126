###### Class com.google.ads.bp (com.google.ads.bp)
.class public final Lcom/google/ads/bp;
.super Lcom/google/ads/util/x;


# static fields
.field private static final d:Lcom/google/ads/bp;


# instance fields
.field public final a:Lcom/google/ads/util/aa;

.field public final b:Lcom/google/ads/util/z;

.field public final c:Lcom/google/ads/util/z;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/google/ads/bp;

    invoke-direct {v0}, Lcom/google/ads/bp;-><init>()V

    sput-object v0, Lcom/google/ads/bp;->d:Lcom/google/ads/bp;

    return-void
.end method

.method private constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lcom/google/ads/util/x;-><init>()V

    new-instance v0, Lcom/google/ads/util/aa;

    const-string v1, "marketPackages"

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bp;->a:Lcom/google/ads/util/aa;

    new-instance v0, Lcom/google/ads/util/z;

    const-string v1, "constants"

    new-instance v2, Lcom/google/ads/bq;

    invoke-direct {v2}, Lcom/google/ads/bq;-><init>()V

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bp;->b:Lcom/google/ads/util/z;

    new-instance v0, Lcom/google/ads/util/z;

    const-string v1, "uiHandler"

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bp;->c:Lcom/google/ads/util/z;

    return-void
.end method

.method public static a()Lcom/google/ads/bp;
    .registers 1

    sget-object v0, Lcom/google/ads/bp;->d:Lcom/google/ads/bp;

    return-object v0
.end method
