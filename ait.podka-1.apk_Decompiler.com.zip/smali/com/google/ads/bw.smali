###### Class com.google.ads.bw (com.google.ads.bw)
.class public final Lcom/google/ads/bw;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/bs;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
    .registers 5

    instance-of v0, p3, Lcom/google/ads/internal/AdWebView;

    if-eqz v0, :cond_a

    check-cast p3, Lcom/google/ads/internal/AdWebView;

    invoke-virtual {p3}, Lcom/google/ads/internal/AdWebView;->f()V

    :goto_9
    return-void

    :cond_a
    const-string v0, "Trying to close WebView that isn\'t an AdWebView"

    invoke-static {v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;)V

    goto :goto_9
.end method
