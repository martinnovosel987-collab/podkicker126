###### Class com.google.ads.d (com.google.ads.d)
.class public Lcom/google/ads/d;
.super Ljava/lang/Object;


# static fields
.field public static final b:Ljava/lang/String;

.field private static final c:Ljava/text/SimpleDateFormat;

.field private static d:Ljava/lang/reflect/Method;

.field private static e:Ljava/lang/reflect/Method;


# instance fields
.field public final a:Ljava/util/Map;

.field private f:Lcom/google/ads/f;

.field private g:Ljava/util/Date;

.field private h:Ljava/util/Set;

.field private i:Ljava/util/Map;

.field private j:Landroid/location/Location;

.field private k:Z

.field private l:Z

.field private m:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    const/4 v2, 0x0

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyyMMdd"

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/google/ads/d;->c:Ljava/text/SimpleDateFormat;

    sput-object v2, Lcom/google/ads/d;->d:Ljava/lang/reflect/Method;

    sput-object v2, Lcom/google/ads/d;->e:Ljava/lang/reflect/Method;

    :try_start_e
    const-string v0, "com.google.analytics.tracking.android.AdMobInfo"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v1

    array-length v2, v1

    const/4 v0, 0x0

    :goto_1a
    if-ge v0, v2, :cond_5b

    aget-object v3, v1, v0

    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "getInstance"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_36

    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v4

    array-length v4, v4

    if-nez v4, :cond_36

    sput-object v3, Lcom/google/ads/d;->d:Ljava/lang/reflect/Method;

    :cond_33
    :goto_33
    add-int/lit8 v0, v0, 0x1

    goto :goto_1a

    :cond_36
    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "getJoinIds"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_33

    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v4

    array-length v4, v4

    if-nez v4, :cond_33

    sput-object v3, Lcom/google/ads/d;->e:Ljava/lang/reflect/Method;
    :try_end_4b
    .catch Ljava/lang/ClassNotFoundException; {:try_start_e .. :try_end_4b} :catch_4c
    .catch Ljava/lang/Throwable; {:try_start_e .. :try_end_4b} :catch_6f

    goto :goto_33

    :catch_4c
    move-exception v0

    const-string v0, "No Google Analytics: Library Not Found."

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    :cond_52
    :goto_52
    const-string v0, "emulator"

    invoke-static {v0}, Lcom/google/ads/util/AdUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/ads/d;->b:Ljava/lang/String;

    return-void

    :cond_5b
    :try_start_5b
    sget-object v0, Lcom/google/ads/d;->d:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_63

    sget-object v0, Lcom/google/ads/d;->e:Ljava/lang/reflect/Method;

    if-nez v0, :cond_52

    :cond_63
    const/4 v0, 0x0

    sput-object v0, Lcom/google/ads/d;->d:Ljava/lang/reflect/Method;

    const/4 v0, 0x0

    sput-object v0, Lcom/google/ads/d;->e:Ljava/lang/reflect/Method;

    const-string v0, "No Google Analytics: Library Incompatible."

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V
    :try_end_6e
    .catch Ljava/lang/ClassNotFoundException; {:try_start_5b .. :try_end_6e} :catch_4c
    .catch Ljava/lang/Throwable; {:try_start_5b .. :try_end_6e} :catch_6f

    goto :goto_52

    :catch_6f
    move-exception v0

    const-string v0, "No Google Analytics: Error Loading Library"

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    goto :goto_52
.end method

.method public constructor <init>()V
    .registers 4

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/google/ads/d;->f:Lcom/google/ads/f;

    iput-object v1, p0, Lcom/google/ads/d;->g:Ljava/util/Date;

    iput-object v1, p0, Lcom/google/ads/d;->h:Ljava/util/Set;

    iput-object v1, p0, Lcom/google/ads/d;->i:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/google/ads/d;->a:Ljava/util/Map;

    iput-object v1, p0, Lcom/google/ads/d;->j:Landroid/location/Location;

    iput-boolean v2, p0, Lcom/google/ads/d;->k:Z

    iput-boolean v2, p0, Lcom/google/ads/d;->l:Z

    iput-object v1, p0, Lcom/google/ads/d;->m:Ljava/util/Set;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Set;)Lcom/google/ads/d;
    .registers 2

    iput-object p1, p0, Lcom/google/ads/d;->h:Ljava/util/Set;

    return-object p0
.end method

.method public final a(Ljava/lang/Class;)Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lcom/google/ads/d;->a:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public a(Landroid/content/Context;)Ljava/util/Map;
    .registers 7

    const/4 v4, 0x1

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iget-object v0, p0, Lcom/google/ads/d;->h:Ljava/util/Set;

    if-eqz v0, :cond_11

    const-string v0, "kw"

    iget-object v1, p0, Lcom/google/ads/d;->h:Ljava/util/Set;

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_11
    iget-object v0, p0, Lcom/google/ads/d;->f:Lcom/google/ads/f;

    if-eqz v0, :cond_24

    const-string v0, "cust_gender"

    iget-object v1, p0, Lcom/google/ads/d;->f:Lcom/google/ads/f;

    invoke-virtual {v1}, Lcom/google/ads/f;->ordinal()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_24
    iget-object v0, p0, Lcom/google/ads/d;->g:Ljava/util/Date;

    if-eqz v0, :cond_35

    const-string v0, "cust_age"

    sget-object v1, Lcom/google/ads/d;->c:Ljava/text/SimpleDateFormat;

    iget-object v3, p0, Lcom/google/ads/d;->g:Ljava/util/Date;

    invoke-virtual {v1, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_35
    iget-object v0, p0, Lcom/google/ads/d;->j:Landroid/location/Location;

    if-eqz v0, :cond_44

    const-string v0, "uule"

    iget-object v1, p0, Lcom/google/ads/d;->j:Landroid/location/Location;

    invoke-static {v1}, Lcom/google/ads/util/AdUtil;->a(Landroid/location/Location;)Ljava/util/HashMap;

    move-result-object v1

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_44
    iget-boolean v0, p0, Lcom/google/ads/d;->k:Z

    if-eqz v0, :cond_51

    const-string v0, "testing"

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_51
    invoke-virtual {p0, p1}, Lcom/google/ads/d;->b(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_cc

    const-string v0, "adtest"

    const-string v1, "on"

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_5e
    :goto_5e
    const-class v0, Lcom/google/ads/a/a/a;

    invoke-virtual {p0, v0}, Lcom/google/ads/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/a/a/a;

    const-class v1, Lcom/google/ads/doubleclick/a;

    invoke-virtual {p0, v1}, Lcom/google/ads/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/google/ads/doubleclick/a;

    if-eqz v1, :cond_10e

    invoke-virtual {v1}, Lcom/google/ads/doubleclick/a;->c()Ljava/util/Map;

    move-result-object v3

    if-eqz v3, :cond_10e

    invoke-virtual {v1}, Lcom/google/ads/doubleclick/a;->c()Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_10e

    const-string v0, "extras"

    invoke-virtual {v1}, Lcom/google/ads/doubleclick/a;->c()Ljava/util/Map;

    move-result-object v3

    invoke-interface {v2, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_89
    :goto_89
    if-eqz v1, :cond_9a

    invoke-virtual {v1}, Lcom/google/ads/doubleclick/a;->a()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_9a

    const-string v1, "ppid"

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9a
    iget-object v0, p0, Lcom/google/ads/d;->i:Ljava/util/Map;

    if-eqz v0, :cond_a5

    const-string v0, "mediation_extras"

    iget-object v1, p0, Lcom/google/ads/d;->i:Ljava/util/Map;

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a5
    :try_start_a5
    sget-object v0, Lcom/google/ads/d;->d:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_cb

    sget-object v0, Lcom/google/ads/d;->d:Ljava/lang/reflect/Method;

    const/4 v1, 0x0

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {v0, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lcom/google/ads/d;->e:Ljava/lang/reflect/Method;

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {v1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-eqz v0, :cond_cb

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v1

    if-lez v1, :cond_cb

    const-string v1, "analytics_join_id"

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_cb
    .catch Ljava/lang/Throwable; {:try_start_a5 .. :try_end_cb} :catch_12b

    :cond_cb
    :goto_cb
    return-object v2

    :cond_cc
    iget-boolean v0, p0, Lcom/google/ads/d;->l:Z

    if-nez v0, :cond_5e

    invoke-static {}, Lcom/google/ads/util/AdUtil;->c()Z

    move-result v0

    if-eqz v0, :cond_f4

    const-string v0, "AdRequest.TEST_EMULATOR"

    :goto_d8
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "To get test ads on this device, call adRequest.addTestDevice("

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ");"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    iput-boolean v4, p0, Lcom/google/ads/d;->l:Z

    goto/16 :goto_5e

    :cond_f4
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\""

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lcom/google/ads/util/AdUtil;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_d8

    :cond_10e
    if-eqz v0, :cond_89

    invoke-virtual {v0}, Lcom/google/ads/a/a/a;->c()Ljava/util/Map;

    move-result-object v3

    if-eqz v3, :cond_89

    invoke-virtual {v0}, Lcom/google/ads/a/a/a;->c()Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_89

    const-string v3, "extras"

    invoke-virtual {v0}, Lcom/google/ads/a/a/a;->c()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_89

    :catch_12b
    move-exception v0

    const-string v1, "Internal Analytics Error:"

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->c(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_cb
.end method

.method public final b(Ljava/util/Set;)Lcom/google/ads/d;
    .registers 2

    iput-object p1, p0, Lcom/google/ads/d;->m:Ljava/util/Set;

    return-object p0
.end method

.method public final b(Landroid/content/Context;)Z
    .registers 5

    const/4 v0, 0x0

    iget-object v1, p0, Lcom/google/ads/d;->m:Ljava/util/Set;

    if-eqz v1, :cond_b

    invoke-static {p1}, Lcom/google/ads/util/AdUtil;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_c

    :cond_b
    :goto_b
    return v0

    :cond_c
    iget-object v2, p0, Lcom/google/ads/d;->m:Ljava/util/Set;

    invoke-interface {v2, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    const/4 v0, 0x1

    goto :goto_b
.end method
