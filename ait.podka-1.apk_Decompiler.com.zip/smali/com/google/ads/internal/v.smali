###### Class com.google.ads.internal.v (com.google.ads.internal.v)
.class public final Lcom/google/ads/internal/v;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field volatile a:Z

.field b:Z

.field private final c:Lcom/google/ads/bo;

.field private final d:Lcom/google/ads/internal/x;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/Thread;


# direct methods
.method constructor <init>(Lcom/google/ads/bo;)V
    .registers 3

    new-instance v0, Lcom/google/ads/internal/w;

    invoke-direct {v0}, Lcom/google/ads/internal/w;-><init>()V

    invoke-direct {p0, p1, v0}, Lcom/google/ads/internal/v;-><init>(Lcom/google/ads/bo;Lcom/google/ads/internal/x;)V

    return-void
.end method

.method private constructor <init>(Lcom/google/ads/bo;Lcom/google/ads/internal/x;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/google/ads/internal/v;->f:Ljava/lang/Thread;

    iput-object p1, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iput-object p2, p0, Lcom/google/ads/internal/v;->d:Lcom/google/ads/internal/x;

    return-void
.end method

.method private a(Ljava/net/HttpURLConnection;)V
    .registers 9

    const/4 v6, 0x2

    const/4 v1, 0x0

    const-string v0, "X-Afma-Debug-Dialog"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1b

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-virtual {v0, v2}, Lcom/google/ads/internal/k;->f(Ljava/lang/String;)V

    :cond_1b
    const-string v0, "X-Afma-Tracking-Urls"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_50

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v2, "\\s+"

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v4, v3

    move v2, v1

    :goto_33
    if-ge v2, v4, :cond_50

    aget-object v5, v3, v2

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    invoke-virtual {v0, v5}, Lcom/google/ads/internal/t;->b(Ljava/lang/String;)V

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_33

    :cond_50
    const-string v0, "X-Afma-Manual-Tracking-Urls"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_85

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v2, "\\s+"

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v4, v3

    move v2, v1

    :goto_68
    if-ge v2, v4, :cond_85

    aget-object v5, v3, v2

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    invoke-virtual {v0, v5}, Lcom/google/ads/internal/t;->c(Ljava/lang/String;)V

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_68

    :cond_85
    const-string v0, "X-Afma-Click-Tracking-Urls"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_b1

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v2, "\\s+"

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    array-length v3, v2

    :goto_9c
    if-ge v1, v3, :cond_b1

    aget-object v4, v2, v1

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-virtual {v0, v4}, Lcom/google/ads/internal/k;->a(Ljava/lang/String;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_9c

    :cond_b1
    const-string v0, "X-Afma-Refresh-Rate"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_e4

    :try_start_bd
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F
    :try_end_c0
    .catch Ljava/lang/NumberFormatException; {:try_start_bd .. :try_end_c0} :catch_1f8

    move-result v1

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    const/4 v2, 0x0

    cmpl-float v2, v1, v2

    if-lez v2, :cond_20d

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/t;->a(F)V

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->q()Z

    move-result v1

    if-nez v1, :cond_e4

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->g()V

    :cond_e4
    :goto_e4
    const-string v0, "X-Afma-Interstitial-Timeout"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_10d

    :try_start_f0
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    const/high16 v3, 0x447a0000    # 1000.0f

    mul-float/2addr v2, v3

    float-to-long v2, v2

    invoke-virtual {v0, v2, v3}, Lcom/google/ads/internal/t;->a(J)V
    :try_end_10d
    .catch Ljava/lang/NumberFormatException; {:try_start_f0 .. :try_end_10d} :catch_218

    :cond_10d
    :goto_10d
    const-string v0, "X-Afma-Orientation"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_132

    const-string v1, "portrait"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_22d

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-static {}, Lcom/google/ads/util/AdUtil;->b()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->a(I)V

    :cond_132
    :goto_132
    const-string v0, "X-Afma-Doritos-Cache-Life"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_15d

    :try_start_13e
    const-string v0, "X-Afma-Doritos-Cache-Life"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    invoke-virtual {v0, v1, v2}, Lcom/google/ads/internal/t;->b(J)V
    :try_end_15d
    .catch Ljava/lang/NumberFormatException; {:try_start_13e .. :try_end_15d} :catch_248

    :cond_15d
    :goto_15d
    const-string v0, "Cache-Control"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_176

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->c(Ljava/lang/String;)V

    :cond_176
    const-string v0, "X-Afma-Mediation"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_197

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->b(Z)V

    :cond_197
    const-string v0, "Content-Type"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1b0

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->b(Ljava/lang/String;)V

    :cond_1b0
    const-string v0, "X-Afma-Ad-Size"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1d8

    :try_start_1bc
    const-string v1, "x"

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    if-eq v2, v6, :cond_269

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Could not parse size header: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V
    :try_end_1d8
    .catch Ljava/lang/NumberFormatException; {:try_start_1bc .. :try_end_1d8} :catch_28b

    :cond_1d8
    :goto_1d8
    const-string v0, "X-Afma-Disable-Activation-And-Scroll"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1f7

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    const-string v2, "1"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->a(Z)V

    :cond_1f7
    return-void

    :catch_1f8
    move-exception v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Could not get refresh value: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, Lcom/google/ads/util/e;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto/16 :goto_e4

    :cond_20d
    invoke-virtual {v0}, Lcom/google/ads/internal/t;->q()Z

    move-result v1

    if-eqz v1, :cond_e4

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->f()V

    goto/16 :goto_e4

    :catch_218
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Could not get timeout value: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto/16 :goto_10d

    :cond_22d
    const-string v1, "landscape"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_132

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    invoke-static {}, Lcom/google/ads/util/AdUtil;->a()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->a(I)V

    goto/16 :goto_132

    :catch_248
    move-exception v0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Got bad value of Doritos cookie cache life from header: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "X-Afma-Doritos-Cache-Life"

    invoke-virtual {p1, v1}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ". Using default value instead."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    goto/16 :goto_15d

    :cond_269
    const/4 v2, 0x0

    :try_start_26a
    aget-object v2, v1, v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x1

    aget-object v1, v1, v3

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_276
    .catch Ljava/lang/NumberFormatException; {:try_start_26a .. :try_end_276} :catch_28b

    move-result v1

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    new-instance v3, Lcom/google/ads/g;

    invoke-direct {v3, v2, v1}, Lcom/google/ads/g;-><init>(II)V

    invoke-virtual {v0, v3}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/g;)V

    goto/16 :goto_1d8

    :catch_28b
    move-exception v1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Could not parse size header: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    goto/16 :goto_1d8
.end method


# virtual methods
.method final declared-synchronized a(Ljava/lang/String;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/google/ads/internal/v;->f:Ljava/lang/Thread;

    if-nez v0, :cond_16

    iput-object p1, p0, Lcom/google/ads/internal/v;->e:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z

    new-instance v0, Ljava/lang/Thread;

    invoke-direct {v0, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Lcom/google/ads/internal/v;->f:Ljava/lang/Thread;

    iget-object v0, p0, Lcom/google/ads/internal/v;->f:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_16
    .catchall {:try_start_1 .. :try_end_16} :catchall_18

    :cond_16
    monitor-exit p0

    return-void

    :catchall_18
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final run()V
    .registers 6

    const/16 v4, 0x190

    :goto_2
    :try_start_2
    iget-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z

    if-nez v0, :cond_b8

    new-instance v0, Ljava/net/URL;

    iget-object v1, p0, Lcom/google/ads/internal/v;->e:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/google/ads/internal/v;->d:Lcom/google/ads/internal/x;

    invoke-interface {v1, v0}, Lcom/google/ads/internal/x;->a(Ljava/net/URL;)Ljava/net/HttpURLConnection;
    :try_end_12
    .catch Ljava/net/MalformedURLException; {:try_start_2 .. :try_end_12} :catch_a3
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_12} :catch_c4
    .catch Ljava/lang/Throwable; {:try_start_2 .. :try_end_12} :catch_18b

    move-result-object v1

    :try_start_13
    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->f:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "drt"

    const-string v3, ""

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-boolean v2, p0, Lcom/google/ads/internal/v;->b:Z

    if-eqz v2, :cond_46

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_46

    sget v2, Lcom/google/ads/util/AdUtil;->a:I

    const/16 v3, 0x8

    if-ne v2, v3, :cond_b9

    const-string v2, "X-Afma-drt-Cookie"

    invoke-virtual {v1, v2, v0}, Ljava/net/HttpURLConnection;->addRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_46
    :goto_46
    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->f:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    invoke-static {v1, v0}, Lcom/google/ads/util/AdUtil;->a(Ljava/net/HttpURLConnection;Landroid/content/Context;)V

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->connect()V

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v2, 0x12c

    if-gt v2, v0, :cond_e0

    if-ge v0, v4, :cond_e0

    const-string v2, "Location"

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_da

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Could not get redirect location from a "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " redirect."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v2, Lcom/google/ads/e;->d:Lcom/google/ads/e;

    invoke-virtual {v0, v2}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z
    :try_end_9e
    .catchall {:try_start_13 .. :try_end_9e} :catchall_bf

    :goto_9e
    :try_start_9e
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_a1
    .catch Ljava/net/MalformedURLException; {:try_start_9e .. :try_end_a1} :catch_a3
    .catch Ljava/io/IOException; {:try_start_9e .. :try_end_a1} :catch_c4
    .catch Ljava/lang/Throwable; {:try_start_9e .. :try_end_a1} :catch_18b

    goto/16 :goto_2

    :catch_a3
    move-exception v0

    const-string v1, "Received malformed ad url from javascript."

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v1, Lcom/google/ads/e;->d:Lcom/google/ads/e;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    :cond_b8
    :goto_b8
    return-void

    :cond_b9
    :try_start_b9
    const-string v2, "Cookie"

    invoke-virtual {v1, v2, v0}, Ljava/net/HttpURLConnection;->addRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_be
    .catchall {:try_start_b9 .. :try_end_be} :catchall_bf

    goto :goto_46

    :catchall_bf
    move-exception v0

    :try_start_c0
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0
    :try_end_c4
    .catch Ljava/net/MalformedURLException; {:try_start_c0 .. :try_end_c4} :catch_a3
    .catch Ljava/io/IOException; {:try_start_c0 .. :try_end_c4} :catch_c4
    .catch Ljava/lang/Throwable; {:try_start_c0 .. :try_end_c4} :catch_18b

    :catch_c4
    move-exception v0

    const-string v1, "IOException connecting to ad url."

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v1, Lcom/google/ads/e;->c:Lcom/google/ads/e;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    goto :goto_b8

    :cond_da
    :try_start_da
    invoke-direct {p0, v1}, Lcom/google/ads/internal/v;->a(Ljava/net/HttpURLConnection;)V

    iput-object v2, p0, Lcom/google/ads/internal/v;->e:Ljava/lang/String;

    goto :goto_9e

    :cond_e0
    const/16 v2, 0xc8

    if-ne v0, v2, :cond_14a

    invoke-direct {p0, v1}, Lcom/google/ads/internal/v;->a(Ljava/net/HttpURLConnection;)V

    new-instance v0, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-static {v0}, Lcom/google/ads/util/AdUtil;->a(Ljava/lang/Readable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Response content is: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_136

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Response message is null or zero length: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v2, Lcom/google/ads/e;->b:Lcom/google/ads/e;

    invoke-virtual {v0, v2}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z

    goto/16 :goto_9e

    :cond_136
    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    iget-object v3, p0, Lcom/google/ads/internal/v;->e:Ljava/lang/String;

    invoke-virtual {v0, v2, v3}, Lcom/google/ads/internal/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z

    goto/16 :goto_9e

    :cond_14a
    if-ne v0, v4, :cond_165

    const-string v0, "Bad request"

    invoke-static {v0}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v2, Lcom/google/ads/e;->a:Lcom/google/ads/e;

    invoke-virtual {v0, v2}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z

    goto/16 :goto_9e

    :cond_165
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Invalid response code: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->c(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v2, Lcom/google/ads/e;->d:Lcom/google/ads/e;

    invoke-virtual {v0, v2}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/ads/internal/v;->a:Z
    :try_end_189
    .catchall {:try_start_da .. :try_end_189} :catchall_bf

    goto/16 :goto_9e

    :catch_18b
    move-exception v0

    const-string v1, "An unknown error occurred in AdResponseLoader."

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, p0, Lcom/google/ads/internal/v;->c:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/k;

    sget-object v1, Lcom/google/ads/e;->d:Lcom/google/ads/e;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/k;->a(Lcom/google/ads/e;)V

    goto/16 :goto_b8
.end method
