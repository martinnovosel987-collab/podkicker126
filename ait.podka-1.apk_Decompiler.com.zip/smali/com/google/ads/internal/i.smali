###### Class com.google.ads.internal.i (com.google.ads.internal.i)
.class final Lcom/google/ads/internal/i;
.super Ljava/util/HashMap;


# direct methods
.method constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    const-string v0, "/log"

    new-instance v1, Lcom/google/ads/cc;

    invoke-direct {v1}, Lcom/google/ads/cc;-><init>()V

    invoke-virtual {p0, v0, v1}, Lcom/google/ads/internal/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "/setNativeActivationOverlay"

    new-instance v1, Lcom/google/ads/l;

    invoke-direct {v1}, Lcom/google/ads/l;-><init>()V

    invoke-virtual {p0, v0, v1}, Lcom/google/ads/internal/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
