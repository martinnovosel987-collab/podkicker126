###### Class com.google.ads.internal.o (com.google.ads.internal.o)
.class final Lcom/google/ads/internal/o;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Lcom/google/ads/internal/t;

.field private final b:Landroid/webkit/WebView;

.field private final c:Lcom/google/ads/internal/v;

.field private final d:Lcom/google/ads/e;

.field private final e:Z


# direct methods
.method public constructor <init>(Lcom/google/ads/internal/t;Landroid/webkit/WebView;Lcom/google/ads/internal/v;Lcom/google/ads/e;Z)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/ads/internal/o;->a:Lcom/google/ads/internal/t;

    iput-object p2, p0, Lcom/google/ads/internal/o;->b:Landroid/webkit/WebView;

    iput-object p3, p0, Lcom/google/ads/internal/o;->c:Lcom/google/ads/internal/v;

    iput-object p4, p0, Lcom/google/ads/internal/o;->d:Lcom/google/ads/e;

    iput-boolean p5, p0, Lcom/google/ads/internal/o;->e:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/google/ads/internal/o;->b:Landroid/webkit/WebView;

    if-eqz v0, :cond_e

    iget-object v0, p0, Lcom/google/ads/internal/o;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->stopLoading()V

    iget-object v0, p0, Lcom/google/ads/internal/o;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    :cond_e
    iget-object v0, p0, Lcom/google/ads/internal/o;->c:Lcom/google/ads/internal/v;

    if-eqz v0, :cond_17

    iget-object v0, p0, Lcom/google/ads/internal/o;->c:Lcom/google/ads/internal/v;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lcom/google/ads/internal/v;->a:Z

    :cond_17
    iget-boolean v0, p0, Lcom/google/ads/internal/o;->e:Z

    if-eqz v0, :cond_45

    iget-object v0, p0, Lcom/google/ads/internal/o;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->k()Lcom/google/ads/internal/AdWebView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/ads/internal/AdWebView;->stopLoading()V

    iget-object v0, p0, Lcom/google/ads/internal/o;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v0

    iget-object v0, v0, Lcom/google/ads/br;->i:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_45

    iget-object v0, p0, Lcom/google/ads/internal/o;->a:Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v0

    iget-object v0, v0, Lcom/google/ads/br;->i:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    :cond_45
    iget-object v0, p0, Lcom/google/ads/internal/o;->a:Lcom/google/ads/internal/t;

    iget-object v1, p0, Lcom/google/ads/internal/o;->d:Lcom/google/ads/e;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/t;->a(Lcom/google/ads/e;)V

    return-void
.end method
