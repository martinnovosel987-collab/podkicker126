###### Class com.google.ads.internal.ag (com.google.ads.internal.ag)
.class final Lcom/google/ads/internal/ag;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lcom/google/ads/internal/ae;


# direct methods
.method constructor <init>(Lcom/google/ads/internal/ae;)V
    .registers 2

    iput-object p1, p0, Lcom/google/ads/internal/ag;->a:Lcom/google/ads/internal/ae;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    new-instance v0, Lcom/google/ads/internal/ab;

    iget-object v1, p0, Lcom/google/ads/internal/ag;->a:Lcom/google/ads/internal/ae;

    invoke-static {v1}, Lcom/google/ads/internal/ae;->a(Lcom/google/ads/internal/ae;)Lcom/google/ads/internal/t;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/ads/internal/t;->d()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/google/ads/internal/ag;->a:Lcom/google/ads/internal/ae;

    invoke-static {v2}, Lcom/google/ads/internal/ae;->b(Lcom/google/ads/internal/ae;)Landroid/app/Activity;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lcom/google/ads/internal/ab;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    new-instance v1, Ljava/lang/Thread;

    invoke-direct {v1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    return-void
.end method
