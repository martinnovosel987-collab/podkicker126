###### Class com.google.ads.internal.d (com.google.ads.internal.d)
.class final Lcom/google/ads/internal/d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field final synthetic a:Lcom/google/ads/internal/AdWebView;


# direct methods
.method constructor <init>(Lcom/google/ads/internal/AdWebView;)V
    .registers 2

    iput-object p1, p0, Lcom/google/ads/internal/d;->a:Lcom/google/ads/internal/AdWebView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 5

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_9

    const/4 v0, 0x1

    :goto_8
    return v0

    :cond_9
    const/4 v0, 0x0

    goto :goto_8
.end method
