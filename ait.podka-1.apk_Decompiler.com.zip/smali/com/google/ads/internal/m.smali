###### Class com.google.ads.internal.m (com.google.ads.internal.m)
.class final Lcom/google/ads/internal/m;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/ads/ay;

.field final synthetic b:Lcom/google/ads/internal/k;


# direct methods
.method constructor <init>(Lcom/google/ads/internal/k;Lcom/google/ads/ay;)V
    .registers 3

    iput-object p1, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iput-object p2, p0, Lcom/google/ads/internal/m;->a:Lcom/google/ads/ay;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->a:Landroid/webkit/WebView;

    if-eqz v0, :cond_14

    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->a:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->stopLoading()V

    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->a:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    :cond_14
    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    iget-object v1, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v1, v1, Lcom/google/ads/internal/k;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/t;->a(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->e:Lcom/google/ads/g;

    if-eqz v0, :cond_50

    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/z;

    iget-object v1, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v1, v1, Lcom/google/ads/internal/k;->e:Lcom/google/ads/g;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/z;->b(Lcom/google/ads/g;)V

    :cond_50
    iget-object v0, p0, Lcom/google/ads/internal/m;->b:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    iget-object v1, p0, Lcom/google/ads/internal/m;->a:Lcom/google/ads/ay;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/t;->a(Lcom/google/ads/ay;)V

    return-void
.end method
