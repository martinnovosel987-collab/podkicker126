###### Class com.google.ads.internal.ActivationOverlay (com.google.ads.internal.ActivationOverlay)
.class public Lcom/google/ads/internal/ActivationOverlay;
.super Lcom/google/ads/internal/AdWebView;


# instance fields
.field private volatile b:Z

.field private c:Z

.field private d:I

.field private e:I

.field private final f:Lcom/google/ads/internal/aa;


# direct methods
.method public constructor <init>(Lcom/google/ads/br;)V
    .registers 5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/ads/internal/AdWebView;-><init>(Lcom/google/ads/br;Lcom/google/ads/g;)V

    iput-boolean v2, p0, Lcom/google/ads/internal/ActivationOverlay;->b:Z

    iput-boolean v2, p0, Lcom/google/ads/internal/ActivationOverlay;->c:Z

    iput v1, p0, Lcom/google/ads/internal/ActivationOverlay;->d:I

    iput v1, p0, Lcom/google/ads/internal/ActivationOverlay;->e:I

    iget-object v0, p1, Lcom/google/ads/br;->d:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/bp;

    iget-object v0, v0, Lcom/google/ads/bp;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/bq;

    sget v1, Lcom/google/ads/util/AdUtil;->a:I

    iget-object v0, v0, Lcom/google/ads/bq;->c:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-ge v1, v0, :cond_36

    const-string v0, "Disabling hardware acceleration for an activation overlay."

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/google/ads/internal/ActivationOverlay;->g()V

    :cond_36
    iget-object v0, p1, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    sget-object v1, Lcom/google/ads/internal/e;->c:Ljava/util/Map;

    invoke-static {v0, v1, v2, v2}, Lcom/google/ads/internal/aa;->a(Lcom/google/ads/internal/t;Ljava/util/Map;ZZ)Lcom/google/ads/internal/aa;

    move-result-object v0

    iput-object v0, p0, Lcom/google/ads/internal/ActivationOverlay;->f:Lcom/google/ads/internal/aa;

    iget-object v0, p0, Lcom/google/ads/internal/ActivationOverlay;->f:Lcom/google/ads/internal/aa;

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/ActivationOverlay;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 2

    iget-boolean v0, p0, Lcom/google/ads/internal/ActivationOverlay;->b:Z

    return v0
.end method

.method public final b()Z
    .registers 2

    iget-boolean v0, p0, Lcom/google/ads/internal/ActivationOverlay;->c:Z

    return v0
.end method

.method public final c()I
    .registers 2

    iget v0, p0, Lcom/google/ads/internal/ActivationOverlay;->e:I

    return v0
.end method

.method public canScrollHorizontally(I)Z
    .registers 3

    const/4 v0, 0x0

    return v0
.end method

.method public canScrollVertically(I)Z
    .registers 3

    const/4 v0, 0x0

    return v0
.end method

.method public final d()I
    .registers 2

    iget v0, p0, Lcom/google/ads/internal/ActivationOverlay;->d:I

    return v0
.end method

.method public final e()Lcom/google/ads/internal/aa;
    .registers 2

    iget-object v0, p0, Lcom/google/ads/internal/ActivationOverlay;->f:Lcom/google/ads/internal/aa;

    return-object v0
.end method

.method public setOverlayActivated(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/google/ads/internal/ActivationOverlay;->c:Z

    return-void
.end method

.method public setOverlayEnabled(Z)V
    .registers 4

    if-nez p1, :cond_16

    invoke-static {}, Lcom/google/ads/bp;->a()Lcom/google/ads/bp;

    move-result-object v0

    iget-object v0, v0, Lcom/google/ads/bp;->c:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Handler;

    new-instance v1, Lcom/google/ads/internal/a;

    invoke-direct {v1, p0, p0}, Lcom/google/ads/internal/a;-><init>(Lcom/google/ads/internal/ActivationOverlay;Lcom/google/ads/internal/ActivationOverlay;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_16
    iput-boolean p1, p0, Lcom/google/ads/internal/ActivationOverlay;->b:Z

    return-void
.end method

.method public setXPosition(I)V
    .registers 2

    iput p1, p0, Lcom/google/ads/internal/ActivationOverlay;->d:I

    return-void
.end method

.method public setYPosition(I)V
    .registers 2

    iput p1, p0, Lcom/google/ads/internal/ActivationOverlay;->e:I

    return-void
.end method
