###### Class com.google.ads.internal.q (com.google.ads.internal.q)
.class final Lcom/google/ads/internal/q;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/ads/internal/k;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>(Lcom/google/ads/internal/k;Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    iput-object p1, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/google/ads/internal/q;->d:Landroid/webkit/WebView;

    iput-object p3, p0, Lcom/google/ads/internal/q;->b:Ljava/lang/String;

    iput-object p4, p0, Lcom/google/ads/internal/q;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    iget-object v0, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->c:Lcom/google/ads/util/aa;

    iget-object v1, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-boolean v1, v1, Lcom/google/ads/internal/k;->f:Z

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/google/ads/util/aa;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/t;

    invoke-virtual {v0}, Lcom/google/ads/internal/t;->k()Lcom/google/ads/internal/AdWebView;

    move-result-object v0

    iget-object v1, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-boolean v1, v1, Lcom/google/ads/internal/k;->f:Z

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/AdWebView;->a(Z)V

    iget-object v0, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->e:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_62

    iget-object v0, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-object v0, v0, Lcom/google/ads/internal/k;->b:Lcom/google/ads/bo;

    iget-object v0, v0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->e:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/internal/ActivationOverlay;

    iget-object v1, p0, Lcom/google/ads/internal/q;->a:Lcom/google/ads/internal/k;

    iget-boolean v1, v1, Lcom/google/ads/internal/k;->f:Z

    if-nez v1, :cond_75

    const/4 v1, 0x1

    :goto_5f
    invoke-virtual {v0, v1}, Lcom/google/ads/internal/ActivationOverlay;->setOverlayEnabled(Z)V

    :cond_62
    iget-object v0, p0, Lcom/google/ads/internal/q;->c:Ljava/lang/String;

    if-eqz v0, :cond_77

    iget-object v0, p0, Lcom/google/ads/internal/q;->d:Landroid/webkit/WebView;

    iget-object v1, p0, Lcom/google/ads/internal/q;->b:Ljava/lang/String;

    iget-object v2, p0, Lcom/google/ads/internal/q;->c:Ljava/lang/String;

    const-string v3, "text/html"

    const-string v4, "utf-8"

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_74
    return-void

    :cond_75
    const/4 v1, 0x0

    goto :goto_5f

    :cond_77
    iget-object v0, p0, Lcom/google/ads/internal/q;->d:Landroid/webkit/WebView;

    iget-object v1, p0, Lcom/google/ads/internal/q;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    goto :goto_74
.end method
