###### Class com.google.ads.internal.AdWebView (com.google.ads.internal.AdWebView)
.class public Lcom/google/ads/internal/AdWebView;
.super Landroid/webkit/WebView;


# instance fields
.field protected final a:Lcom/google/ads/br;

.field private b:Ljava/lang/ref/WeakReference;

.field private c:Lcom/google/ads/g;

.field private d:Z

.field private e:Z

.field private f:Z


# direct methods
.method public constructor <init>(Lcom/google/ads/br;Lcom/google/ads/g;)V
    .registers 8

    const/16 v4, 0xb

    const/4 v3, 0x0

    iget-object v0, p1, Lcom/google/ads/br;->f:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    invoke-direct {p0, v0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/google/ads/internal/AdWebView;->a:Lcom/google/ads/br;

    iput-object p2, p0, Lcom/google/ads/internal/AdWebView;->c:Lcom/google/ads/g;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/google/ads/internal/AdWebView;->b:Ljava/lang/ref/WeakReference;

    iput-boolean v3, p0, Lcom/google/ads/internal/AdWebView;->d:Z

    iput-boolean v3, p0, Lcom/google/ads/internal/AdWebView;->e:Z

    iput-boolean v3, p0, Lcom/google/ads/internal/AdWebView;->f:Z

    invoke-virtual {p0, v3}, Lcom/google/ads/internal/AdWebView;->setBackgroundColor(I)V

    invoke-static {p0}, Lcom/google/ads/util/AdUtil;->a(Landroid/webkit/WebView;)V

    invoke-virtual {p0}, Lcom/google/ads/internal/AdWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setSupportMultipleWindows(Z)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setSavePassword(Z)V

    new-instance v1, Lcom/google/ads/internal/c;

    invoke-direct {v1, p0}, Lcom/google/ads/internal/c;-><init>(Lcom/google/ads/internal/AdWebView;)V

    invoke-virtual {p0, v1}, Lcom/google/ads/internal/AdWebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    sget v1, Lcom/google/ads/util/AdUtil;->a:I

    const/16 v2, 0x11

    if-lt v1, v2, :cond_57

    invoke-static {v0, p1}, Lcom/google/ads/util/n;->a(Landroid/webkit/WebSettings;Lcom/google/ads/br;)V

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    :cond_43
    :goto_43
    const/high16 v0, 0x2000000

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setScrollBarStyle(I)V

    sget v0, Lcom/google/ads/util/AdUtil;->a:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_5f

    new-instance v0, Lcom/google/ads/util/b;

    invoke-direct {v0, p1}, Lcom/google/ads/util/b;-><init>(Lcom/google/ads/br;)V

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    :cond_56
    :goto_56
    return-void

    :cond_57
    sget v1, Lcom/google/ads/util/AdUtil;->a:I

    if-lt v1, v4, :cond_43

    invoke-static {v0, p1}, Lcom/google/ads/util/n;->a(Landroid/webkit/WebSettings;Lcom/google/ads/br;)V

    goto :goto_43

    :cond_5f
    sget v0, Lcom/google/ads/util/AdUtil;->a:I

    if-lt v0, v4, :cond_56

    new-instance v0, Lcom/google/ads/util/p;

    invoke-direct {v0, p1}, Lcom/google/ads/util/p;-><init>(Lcom/google/ads/br;)V

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    goto :goto_56
.end method


# virtual methods
.method public final a(Z)V
    .registers 3

    if-eqz p1, :cond_b

    new-instance v0, Lcom/google/ads/internal/d;

    invoke-direct {v0, p0}, Lcom/google/ads/internal/d;-><init>(Lcom/google/ads/internal/AdWebView;)V

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :goto_a
    return-void

    :cond_b
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    goto :goto_a
.end method

.method public destroy()V
    .registers 3

    :try_start_0
    invoke-super {p0}, Landroid/webkit/WebView;->destroy()V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_c

    :goto_3
    :try_start_3
    new-instance v0, Landroid/webkit/WebViewClient;

    invoke-direct {v0}, Landroid/webkit/WebViewClient;-><init>()V

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
    :try_end_b
    .catch Ljava/lang/Throwable; {:try_start_3 .. :try_end_b} :catch_13

    :goto_b
    return-void

    :catch_c
    move-exception v0

    const-string v1, "An error occurred while destroying an AdWebView:"

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3

    :catch_13
    move-exception v0

    goto :goto_b
.end method

.method public final f()V
    .registers 2

    invoke-virtual {p0}, Lcom/google/ads/internal/AdWebView;->i()Lcom/google/ads/AdActivity;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Lcom/google/ads/AdActivity;->finish()V

    :cond_9
    return-void
.end method

.method public final g()V
    .registers 4

    const/4 v2, 0x1

    sget v0, Lcom/google/ads/util/AdUtil;->a:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_b

    const/4 v0, 0x0

    invoke-virtual {p0, v2, v0}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    :cond_b
    iput-boolean v2, p0, Lcom/google/ads/internal/AdWebView;->e:Z

    return-void
.end method

.method public final h()V
    .registers 4

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/ads/internal/AdWebView;->e:Z

    if-eqz v0, :cond_f

    sget v0, Lcom/google/ads/util/AdUtil;->a:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_f

    const/4 v0, 0x0

    invoke-virtual {p0, v2, v0}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    :cond_f
    iput-boolean v2, p0, Lcom/google/ads/internal/AdWebView;->e:Z

    return-void
.end method

.method public final i()Lcom/google/ads/AdActivity;
    .registers 2

    iget-object v0, p0, Lcom/google/ads/internal/AdWebView;->b:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_d

    iget-object v0, p0, Lcom/google/ads/internal/AdWebView;->b:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/AdActivity;

    :goto_c
    return-object v0

    :cond_d
    const/4 v0, 0x0

    goto :goto_c
.end method

.method public final j()Z
    .registers 2

    iget-boolean v0, p0, Lcom/google/ads/internal/AdWebView;->f:Z

    return v0
.end method

.method public final k()Z
    .registers 2

    iget-boolean v0, p0, Lcom/google/ads/internal/AdWebView;->e:Z

    return v0
.end method

.method public loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    :try_start_0
    invoke-super/range {p0 .. p5}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    :goto_3
    return-void

    :catch_4
    move-exception v0

    const-string v1, "An error occurred while loading data in AdWebView:"

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3
.end method

.method public loadUrl(Ljava/lang/String;)V
    .registers 4

    :try_start_0
    invoke-super {p0, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    :goto_3
    return-void

    :catch_4
    move-exception v0

    const-string v1, "An error occurred while loading a URL in AdWebView:"

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3
.end method

.method protected declared-synchronized onMeasure(II)V
    .registers 13

    const v0, 0x7fffffff

    const/high16 v9, 0x40000000    # 2.0f

    const/high16 v8, -0x80000000

    monitor-enter p0

    :try_start_8
    invoke-virtual {p0}, Lcom/google/ads/internal/AdWebView;->isInEditMode()Z

    move-result v1

    if-eqz v1, :cond_13

    invoke-super {p0, p1, p2}, Landroid/webkit/WebView;->onMeasure(II)V
    :try_end_11
    .catchall {:try_start_8 .. :try_end_11} :catchall_1f

    :goto_11
    monitor-exit p0

    return-void

    :cond_13
    :try_start_13
    iget-object v1, p0, Lcom/google/ads/internal/AdWebView;->c:Lcom/google/ads/g;

    if-eqz v1, :cond_1b

    iget-boolean v1, p0, Lcom/google/ads/internal/AdWebView;->d:Z

    if-eqz v1, :cond_22

    :cond_1b
    invoke-super {p0, p1, p2}, Landroid/webkit/WebView;->onMeasure(II)V
    :try_end_1e
    .catchall {:try_start_13 .. :try_end_1e} :catchall_1f

    goto :goto_11

    :catchall_1f
    move-exception v0

    monitor-exit p0

    throw v0

    :cond_22
    :try_start_22
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v2

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v3

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v4

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    invoke-virtual {p0}, Lcom/google/ads/internal/AdWebView;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    iget v5, v5, Landroid/util/DisplayMetrics;->density:F

    iget-object v6, p0, Lcom/google/ads/internal/AdWebView;->c:Lcom/google/ads/g;

    invoke-virtual {v6}, Lcom/google/ads/g;->a()I

    move-result v6

    int-to-float v6, v6

    mul-float/2addr v6, v5

    float-to-int v6, v6

    iget-object v7, p0, Lcom/google/ads/internal/AdWebView;->c:Lcom/google/ads/g;

    invoke-virtual {v7}, Lcom/google/ads/g;->b()I

    move-result v7

    int-to-float v7, v7

    mul-float/2addr v7, v5

    float-to-int v7, v7

    if-eq v2, v8, :cond_56

    if-ne v2, v9, :cond_ad

    :cond_56
    move v2, v3

    :goto_57
    if-eq v4, v8, :cond_5b

    if-ne v4, v9, :cond_5c

    :cond_5b
    move v0, v1

    :cond_5c
    int-to-float v4, v6

    const/high16 v8, 0x40c00000    # 6.0f

    mul-float/2addr v5, v8

    sub-float/2addr v4, v5

    int-to-float v2, v2

    cmpl-float v2, v4, v2

    if-gtz v2, :cond_68

    if-le v7, v0, :cond_a8

    :cond_68
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Not enough space to show ad! Wants: <"

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ">, Has: <"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ">"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;)V

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Lcom/google/ads/internal/AdWebView;->setVisibility(I)V

    invoke-virtual {p0, v3, v1}, Lcom/google/ads/internal/AdWebView;->setMeasuredDimension(II)V

    goto/16 :goto_11

    :cond_a8
    invoke-virtual {p0, v6, v7}, Lcom/google/ads/internal/AdWebView;->setMeasuredDimension(II)V
    :try_end_ab
    .catchall {:try_start_22 .. :try_end_ab} :catchall_1f

    goto/16 :goto_11

    :cond_ad
    move v2, v0

    goto :goto_57
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 3

    iget-object v0, p0, Lcom/google/ads/internal/AdWebView;->a:Lcom/google/ads/br;

    iget-object v0, v0, Lcom/google/ads/br;->r:Lcom/google/ads/util/aa;

    invoke-virtual {v0}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/ah;

    if-eqz v0, :cond_f

    invoke-virtual {v0, p1}, Lcom/google/ads/ah;->a(Landroid/view/MotionEvent;)V

    :cond_f
    invoke-super {p0, p1}, Landroid/webkit/WebView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    return v0
.end method

.method public setAdActivity(Lcom/google/ads/AdActivity;)V
    .registers 3

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/internal/AdWebView;->b:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public declared-synchronized setAdSize(Lcom/google/ads/g;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iput-object p1, p0, Lcom/google/ads/internal/AdWebView;->c:Lcom/google/ads/g;

    invoke-virtual {p0}, Lcom/google/ads/internal/AdWebView;->requestLayout()V
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    monitor-exit p0

    return-void

    :catchall_8
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public setCustomClose(Z)V
    .registers 3

    iput-boolean p1, p0, Lcom/google/ads/internal/AdWebView;->f:Z

    iget-object v0, p0, Lcom/google/ads/internal/AdWebView;->b:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_13

    iget-object v0, p0, Lcom/google/ads/internal/AdWebView;->b:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/AdActivity;

    if-eqz v0, :cond_13

    invoke-virtual {v0, p1}, Lcom/google/ads/AdActivity;->a(Z)V

    :cond_13
    return-void
.end method

.method public setIsExpandedMraid(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/google/ads/internal/AdWebView;->d:Z

    return-void
.end method

.method public stopLoading()V
    .registers 3

    :try_start_0
    invoke-super {p0}, Landroid/webkit/WebView;->stopLoading()V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    :goto_3
    return-void

    :catch_4
    move-exception v0

    const-string v1, "An error occurred while stopping loading in AdWebView:"

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3
.end method
