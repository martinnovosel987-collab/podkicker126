###### Class com.google.ads.internal.p (com.google.ads.internal.p)
.class final Lcom/google/ads/internal/p;
.super Ljava/lang/Exception;


# instance fields
.field final synthetic a:Lcom/google/ads/internal/k;


# direct methods
.method public constructor <init>(Lcom/google/ads/internal/k;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lcom/google/ads/internal/p;->a:Lcom/google/ads/internal/k;

    invoke-direct {p0, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    return-void
.end method
