###### Class com.google.ads.internal.z (com.google.ads.internal.z)
.class public final Lcom/google/ads/internal/z;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lcom/google/ads/internal/z;


# instance fields
.field private b:Lcom/google/ads/g;

.field private c:Z

.field private final d:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/google/ads/internal/z;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/ads/internal/z;-><init>(Lcom/google/ads/g;Z)V

    sput-object v0, Lcom/google/ads/internal/z;->a:Lcom/google/ads/internal/z;

    return-void
.end method

.method private constructor <init>(Lcom/google/ads/g;Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/ads/internal/z;->b:Lcom/google/ads/g;

    iput-boolean p2, p0, Lcom/google/ads/internal/z;->d:Z

    return-void
.end method

.method public static a(Lcom/google/ads/g;)Lcom/google/ads/internal/z;
    .registers 2

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/google/ads/internal/z;->a(Lcom/google/ads/g;Landroid/content/Context;)Lcom/google/ads/internal/z;

    move-result-object v0

    return-object v0
.end method

.method public static a(Lcom/google/ads/g;Landroid/content/Context;)Lcom/google/ads/internal/z;
    .registers 5

    new-instance v0, Lcom/google/ads/internal/z;

    invoke-static {p0, p1}, Lcom/google/ads/g;->a(Lcom/google/ads/g;Landroid/content/Context;)Lcom/google/ads/g;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/google/ads/internal/z;-><init>(Lcom/google/ads/g;Z)V

    return-object v0
.end method


# virtual methods
.method public final a()Z
    .registers 2

    iget-boolean v0, p0, Lcom/google/ads/internal/z;->d:Z

    return v0
.end method

.method public final b(Lcom/google/ads/g;)V
    .registers 3

    iget-boolean v0, p0, Lcom/google/ads/internal/z;->d:Z

    if-nez v0, :cond_6

    iput-object p1, p0, Lcom/google/ads/internal/z;->b:Lcom/google/ads/g;

    :cond_6
    return-void
.end method

.method public final b()Z
    .registers 2

    iget-boolean v0, p0, Lcom/google/ads/internal/z;->c:Z

    return v0
.end method

.method public final c()Lcom/google/ads/g;
    .registers 2

    iget-object v0, p0, Lcom/google/ads/internal/z;->b:Lcom/google/ads/g;

    return-object v0
.end method

.method public final d()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/ads/internal/z;->c:Z

    return-void
.end method
