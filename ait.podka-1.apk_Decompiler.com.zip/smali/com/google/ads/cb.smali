###### Class com.google.ads.cb (com.google.ads.cb)
.class public final Lcom/google/ads/cb;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/bs;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V
    .registers 5

    :try_start_0
    invoke-virtual {p0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_13

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/google/ads/util/aa;->a(Ljava/lang/Object;)V
    :try_end_13
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_13} :catch_14

    :cond_13
    :goto_13
    return-void

    :catch_14
    move-exception v0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Could not parse \""

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\" constant."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    goto :goto_13
.end method

.method private static b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V
    .registers 5

    :try_start_0
    invoke-virtual {p0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_13

    invoke-static {v0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/google/ads/util/aa;->a(Ljava/lang/Object;)V
    :try_end_13
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_13} :catch_14

    :cond_13
    :goto_13
    return-void

    :catch_14
    move-exception v0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Could not parse \""

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\" constant."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    goto :goto_13
.end method

.method private static c(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V
    .registers 5

    invoke-virtual {p0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_f

    invoke-virtual {p2, v0}, Lcom/google/ads/util/aa;->a(Ljava/lang/Object;)V

    :cond_f
    return-void
.end method


# virtual methods
.method public final a(Lcom/google/ads/internal/t;Ljava/util/HashMap;Landroid/webkit/WebView;)V
    .registers 12

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v5

    iget-object v0, v5, Lcom/google/ads/br;->d:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/bp;

    iget-object v0, v0, Lcom/google/ads/bp;->b:Lcom/google/ads/util/z;

    invoke-virtual {v0}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/bq;

    const-string v1, "as_domains"

    iget-object v2, v0, Lcom/google/ads/bq;->a:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->c(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "bad_ad_report_path"

    iget-object v2, v0, Lcom/google/ads/bq;->h:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->c(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "min_hwa_banner"

    iget-object v2, v0, Lcom/google/ads/bq;->b:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->a(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "min_hwa_activation_overlay"

    iget-object v2, v0, Lcom/google/ads/bq;->c:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->a(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "min_hwa_overlay"

    iget-object v2, v0, Lcom/google/ads/bq;->d:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->a(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "mraid_banner_path"

    iget-object v2, v0, Lcom/google/ads/bq;->e:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->c(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "mraid_expanded_banner_path"

    iget-object v2, v0, Lcom/google/ads/bq;->f:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->c(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "mraid_interstitial_path"

    iget-object v2, v0, Lcom/google/ads/bq;->g:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->c(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "ac_max_size"

    iget-object v2, v0, Lcom/google/ads/bq;->i:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "ac_padding"

    iget-object v2, v0, Lcom/google/ads/bq;->j:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "ac_total_quota"

    iget-object v2, v0, Lcom/google/ads/bq;->k:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "db_total_quota"

    iget-object v2, v0, Lcom/google/ads/bq;->l:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "db_quota_per_origin"

    iget-object v2, v0, Lcom/google/ads/bq;->m:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    const-string v1, "db_quota_step_size"

    iget-object v2, v0, Lcom/google/ads/bq;->n:Lcom/google/ads/util/aa;

    invoke-static {p2, v1, v2}, Lcom/google/ads/cb;->b(Ljava/util/HashMap;Ljava/lang/String;Lcom/google/ads/util/aa;)V

    invoke-virtual {p1}, Lcom/google/ads/internal/t;->k()Lcom/google/ads/internal/AdWebView;

    move-result-object v2

    sget v1, Lcom/google/ads/util/AdUtil;->a:I

    const/16 v6, 0xb

    if-lt v1, v6, :cond_90

    invoke-virtual {v2}, Lcom/google/ads/internal/AdWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-static {v1, v5}, Lcom/google/ads/util/n;->a(Landroid/webkit/WebSettings;Lcom/google/ads/br;)V

    invoke-virtual {p3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-static {v1, v5}, Lcom/google/ads/util/n;->a(Landroid/webkit/WebSettings;Lcom/google/ads/br;)V

    :cond_90
    iget-object v1, v5, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    invoke-virtual {v1}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/google/ads/internal/z;

    invoke-virtual {v1}, Lcom/google/ads/internal/z;->a()Z

    move-result v1

    if-nez v1, :cond_bf

    invoke-virtual {v2}, Lcom/google/ads/internal/AdWebView;->k()Z

    move-result v6

    sget v7, Lcom/google/ads/util/AdUtil;->a:I

    iget-object v1, v0, Lcom/google/ads/bq;->b:Lcom/google/ads/util/aa;

    invoke-virtual {v1}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ge v7, v1, :cond_122

    move v1, v3

    :goto_b3
    if-nez v1, :cond_124

    if-eqz v6, :cond_124

    const-string v1, "Re-enabling hardware acceleration for a banner after reading constants."

    invoke-static {v1}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-virtual {v2}, Lcom/google/ads/internal/AdWebView;->h()V

    :cond_bf
    :goto_bf
    iget-object v1, v5, Lcom/google/ads/br;->e:Lcom/google/ads/util/z;

    invoke-virtual {v1}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/google/ads/internal/ActivationOverlay;

    iget-object v2, v5, Lcom/google/ads/br;->g:Lcom/google/ads/util/z;

    invoke-virtual {v2}, Lcom/google/ads/util/z;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/ads/internal/z;

    invoke-virtual {v2}, Lcom/google/ads/internal/z;->b()Z

    move-result v2

    if-nez v2, :cond_f8

    if-eqz v1, :cond_f8

    invoke-virtual {v1}, Lcom/google/ads/internal/ActivationOverlay;->k()Z

    move-result v6

    sget v7, Lcom/google/ads/util/AdUtil;->a:I

    iget-object v2, v0, Lcom/google/ads/bq;->c:Lcom/google/ads/util/aa;

    invoke-virtual {v2}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-ge v7, v2, :cond_131

    move v2, v3

    :goto_ec
    if-nez v2, :cond_133

    if-eqz v6, :cond_133

    const-string v2, "Re-enabling hardware acceleration for an activation overlay after reading constants."

    invoke-static {v2}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/google/ads/internal/ActivationOverlay;->h()V

    :cond_f8
    :goto_f8
    iget-object v1, v0, Lcom/google/ads/bq;->a:Lcom/google/ads/util/aa;

    invoke-virtual {v1}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v2, v5, Lcom/google/ads/br;->s:Lcom/google/ads/util/aa;

    invoke-virtual {v2}, Lcom/google/ads/util/aa;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/ads/aj;

    if-eqz v2, :cond_118

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_118

    const-string v4, ","

    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    iput-object v1, v2, Lcom/google/ads/aj;->a:[Ljava/lang/String;

    :cond_118
    iget-object v0, v0, Lcom/google/ads/bq;->o:Lcom/google/ads/util/aa;

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/google/ads/util/aa;->a(Ljava/lang/Object;)V

    return-void

    :cond_122
    move v1, v4

    goto :goto_b3

    :cond_124
    if-eqz v1, :cond_bf

    if-nez v6, :cond_bf

    const-string v1, "Disabling hardware acceleration for a banner after reading constants."

    invoke-static {v1}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-virtual {v2}, Lcom/google/ads/internal/AdWebView;->g()V

    goto :goto_bf

    :cond_131
    move v2, v4

    goto :goto_ec

    :cond_133
    if-eqz v2, :cond_f8

    if-nez v6, :cond_f8

    const-string v2, "Disabling hardware acceleration for an activation overlay after reading constants."

    invoke-static {v2}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/google/ads/internal/ActivationOverlay;->g()V

    goto :goto_f8
.end method
