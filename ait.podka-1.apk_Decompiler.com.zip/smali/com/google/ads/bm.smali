###### Class com.google.ads.bm (com.google.ads.bm)
.class final Lcom/google/ads/bm;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/google/ads/bi;


# direct methods
.method public constructor <init>(Lcom/google/ads/bi;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/ads/bm;->a:Lcom/google/ads/bi;

    return-void
.end method
