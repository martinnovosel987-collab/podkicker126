###### Class com.google.ads.bo (com.google.ads.bo)
.class public final Lcom/google/ads/bo;
.super Lcom/google/ads/util/x;


# instance fields
.field public final a:Lcom/google/ads/util/z;

.field public final b:Lcom/google/ads/util/aa;

.field public final c:Lcom/google/ads/util/aa;


# direct methods
.method public constructor <init>(Lcom/google/ads/br;)V
    .registers 5

    invoke-direct {p0}, Lcom/google/ads/util/x;-><init>()V

    new-instance v0, Lcom/google/ads/util/aa;

    const-string v1, "disableNativeScroll"

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bo;->c:Lcom/google/ads/util/aa;

    new-instance v0, Lcom/google/ads/util/z;

    const-string v1, "slotState"

    invoke-direct {v0, p0, v1, p1}, Lcom/google/ads/util/z;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bo;->a:Lcom/google/ads/util/z;

    new-instance v0, Lcom/google/ads/util/aa;

    const-string v1, "adLoader"

    new-instance v2, Lcom/google/ads/internal/k;

    invoke-direct {v2, p0}, Lcom/google/ads/internal/k;-><init>(Lcom/google/ads/bo;)V

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/util/aa;-><init>(Lcom/google/ads/util/x;Ljava/lang/String;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bo;->b:Lcom/google/ads/util/aa;

    return-void
.end method
