###### Class com.google.ads.bg (com.google.ads.bg)
.class public final Lcom/google/ads/bg;
.super Ljava/lang/Object;
