###### Class com.google.ads.bn (com.google.ads.bn)
.class final Lcom/google/ads/bn;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/google/ads/bi;


# direct methods
.method constructor <init>(Lcom/google/ads/bi;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/ads/bn;->a:Lcom/google/ads/bi;

    return-void
.end method
