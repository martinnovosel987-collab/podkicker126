###### Class com.google.ads.b (com.google.ads.b)
.class public final Lcom/google/ads/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Lcom/google/ads/internal/t;Lcom/google/ads/internal/u;)V
    .registers 8

    invoke-static {}, Lcom/google/ads/AdActivity;->d()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    :try_start_5
    invoke-static {}, Lcom/google/ads/AdActivity;->g()Lcom/google/ads/internal/t;

    move-result-object v0

    if-nez v0, :cond_23

    invoke-static {p0}, Lcom/google/ads/AdActivity;->a(Lcom/google/ads/internal/t;)Lcom/google/ads/internal/t;
    :try_end_e
    .catchall {:try_start_5 .. :try_end_e} :catchall_30

    :cond_e
    monitor-exit v1

    invoke-virtual {p0}, Lcom/google/ads/internal/t;->h()Lcom/google/ads/br;

    move-result-object v0

    iget-object v0, v0, Lcom/google/ads/br;->c:Lcom/google/ads/util/ab;

    invoke-virtual {v0}, Lcom/google/ads/util/ab;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;

    if-nez v0, :cond_33

    const-string v0, "activity was null while launching an AdActivity."

    invoke-static {v0}, Lcom/google/ads/util/e;->e(Ljava/lang/String;)V

    :goto_22
    return-void

    :cond_23
    :try_start_23
    invoke-static {}, Lcom/google/ads/AdActivity;->g()Lcom/google/ads/internal/t;

    move-result-object v0

    if-eq v0, p0, :cond_e

    const-string v0, "Tried to launch a new AdActivity with a different AdManager."

    invoke-static {v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;)V

    monitor-exit v1
    :try_end_2f
    .catchall {:try_start_23 .. :try_end_2f} :catchall_30

    goto :goto_22

    :catchall_30
    move-exception v0

    monitor-exit v1

    throw v0

    :cond_33
    new-instance v1, Landroid/content/Intent;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lcom/google/ads/AdActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "com.google.ads.AdOpener"

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string v4, "action"

    iget-object v5, p1, Lcom/google/ads/internal/u;->a:Ljava/lang/String;

    invoke-virtual {v3, v4, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v4, "params"

    iget-object v5, p1, Lcom/google/ads/internal/u;->b:Ljava/util/HashMap;

    invoke-virtual {v3, v4, v5}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    :try_start_56
    const-string v2, "Launching AdActivity."

    invoke-static {v2}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_5e
    .catch Landroid/content/ActivityNotFoundException; {:try_start_56 .. :try_end_5e} :catch_5f

    goto :goto_22

    :catch_5f
    move-exception v0

    const-string v1, "Activity not found."

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_22
.end method

.method public static a()Z
    .registers 2

    invoke-static {}, Lcom/google/ads/AdActivity;->d()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    :try_start_5
    invoke-static {}, Lcom/google/ads/AdActivity;->e()Lcom/google/ads/AdActivity;

    move-result-object v0

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    :goto_c
    monitor-exit v1
    :try_end_d
    .catchall {:try_start_5 .. :try_end_d} :catchall_10

    return v0

    :cond_e
    const/4 v0, 0x0

    goto :goto_c

    :catchall_10
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static b()Z
    .registers 2

    invoke-static {}, Lcom/google/ads/AdActivity;->d()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    :try_start_5
    invoke-static {}, Lcom/google/ads/AdActivity;->f()Lcom/google/ads/AdActivity;

    move-result-object v0

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    :goto_c
    monitor-exit v1
    :try_end_d
    .catchall {:try_start_5 .. :try_end_d} :catchall_10

    return v0

    :cond_e
    const/4 v0, 0x0

    goto :goto_c

    :catchall_10
    move-exception v0

    monitor-exit v1

    throw v0
.end method
