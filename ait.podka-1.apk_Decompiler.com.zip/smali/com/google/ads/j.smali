###### Class com.google.ads.j (com.google.ads.j)
.class public interface abstract Lcom/google/ads/j;
.super Ljava/lang/Object;
