###### Class com.google.ads.bd (com.google.ads.bd)
.class final Lcom/google/ads/bd;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/ads/ay;

.field final synthetic b:Lcom/google/ads/bb;


# direct methods
.method constructor <init>(Lcom/google/ads/bb;Lcom/google/ads/ay;)V
    .registers 3

    iput-object p1, p0, Lcom/google/ads/bd;->b:Lcom/google/ads/bb;

    iput-object p2, p0, Lcom/google/ads/bd;->a:Lcom/google/ads/ay;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/google/ads/bd;->b:Lcom/google/ads/bb;

    iget-object v0, v0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    iget-object v1, p0, Lcom/google/ads/bd;->a:Lcom/google/ads/ay;

    invoke-virtual {v0, v1}, Lcom/google/ads/internal/t;->b(Lcom/google/ads/ay;)V

    return-void
.end method
