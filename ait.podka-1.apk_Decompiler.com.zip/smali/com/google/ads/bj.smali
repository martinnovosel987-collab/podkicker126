###### Class com.google.ads.bj (com.google.ads.bj)
.class final Lcom/google/ads/bj;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/ads/bi;


# direct methods
.method constructor <init>(Lcom/google/ads/bi;)V
    .registers 2

    iput-object p1, p0, Lcom/google/ads/bj;->a:Lcom/google/ads/bi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lcom/google/ads/bj;->a:Lcom/google/ads/bi;

    invoke-virtual {v0}, Lcom/google/ads/bi;->h()Z

    move-result v0

    if-eqz v0, :cond_34

    iget-object v0, p0, Lcom/google/ads/bj;->a:Lcom/google/ads/bi;

    iget-object v0, v0, Lcom/google/ads/bi;->b:Lcom/google/ads/a/b;

    invoke-static {v0}, Lcom/google/ads/util/c;->a(Ljava/lang/Object;)V

    :try_start_f
    iget-object v0, p0, Lcom/google/ads/bj;->a:Lcom/google/ads/bi;

    iget-object v0, v0, Lcom/google/ads/bi;->b:Lcom/google/ads/a/b;

    invoke-interface {v0}, Lcom/google/ads/a/b;->a()V
    :try_end_16
    .catch Ljava/lang/Throwable; {:try_start_f .. :try_end_16} :catch_35

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Called destroy() for adapter with class: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/google/ads/bj;->a:Lcom/google/ads/bi;

    iget-object v1, v1, Lcom/google/ads/bi;->b:Lcom/google/ads/a/b;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    :cond_34
    :goto_34
    return-void

    :catch_35
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Error while destroying adapter ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/google/ads/bj;->a:Lcom/google/ads/bi;

    invoke-virtual {v2}, Lcom/google/ads/bi;->f()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "):"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_34
.end method
