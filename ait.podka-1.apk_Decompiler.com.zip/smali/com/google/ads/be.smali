###### Class com.google.ads.be (com.google.ads.be)
.class final Lcom/google/ads/be;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/ads/bi;

.field final synthetic b:Landroid/view/View;

.field final synthetic c:Lcom/google/ads/bf;

.field final synthetic d:Lcom/google/ads/bb;


# direct methods
.method constructor <init>(Lcom/google/ads/bb;Lcom/google/ads/bi;Landroid/view/View;Lcom/google/ads/bf;)V
    .registers 5

    iput-object p1, p0, Lcom/google/ads/be;->d:Lcom/google/ads/bb;

    iput-object p2, p0, Lcom/google/ads/be;->a:Lcom/google/ads/bi;

    iput-object p3, p0, Lcom/google/ads/be;->b:Landroid/view/View;

    iput-object p4, p0, Lcom/google/ads/be;->c:Lcom/google/ads/bf;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Lcom/google/ads/be;->d:Lcom/google/ads/bb;

    iget-object v1, p0, Lcom/google/ads/be;->a:Lcom/google/ads/bi;

    invoke-virtual {v0, v1}, Lcom/google/ads/bb;->a(Lcom/google/ads/bi;)Z

    move-result v0

    if-eqz v0, :cond_10

    const-string v0, "Trying to switch GWAdNetworkAmbassadors, but GWController().destroy() has been called. Destroying the new ambassador and terminating mediation."

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    :goto_f
    return-void

    :cond_10
    iget-object v0, p0, Lcom/google/ads/be;->d:Lcom/google/ads/bb;

    iget-object v0, v0, Lcom/google/ads/bb;->a:Lcom/google/ads/internal/t;

    iget-object v1, p0, Lcom/google/ads/be;->b:Landroid/view/View;

    iget-object v2, p0, Lcom/google/ads/be;->a:Lcom/google/ads/bi;

    iget-object v3, p0, Lcom/google/ads/be;->c:Lcom/google/ads/bf;

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/ads/internal/t;->a(Landroid/view/View;Lcom/google/ads/bi;Lcom/google/ads/bf;)V

    goto :goto_f
.end method
