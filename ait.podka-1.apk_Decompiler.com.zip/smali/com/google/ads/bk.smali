###### Class com.google.ads.bk (com.google.ads.bk)
.class final Lcom/google/ads/bk;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Lcom/google/ads/bi;

.field private final b:Ljava/lang/String;

.field private final c:Lcom/google/ads/d;

.field private final d:Ljava/util/HashMap;

.field private final e:Z

.field private final f:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(Lcom/google/ads/bi;Landroid/app/Activity;Ljava/lang/String;Lcom/google/ads/d;Ljava/util/HashMap;)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    iput-object p3, p0, Lcom/google/ads/bk;->b:Ljava/lang/String;

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/google/ads/bk;->f:Ljava/lang/ref/WeakReference;

    iput-object p4, p0, Lcom/google/ads/bk;->c:Lcom/google/ads/d;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0, p5}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v0, p0, Lcom/google/ads/bk;->d:Ljava/util/HashMap;

    iget-object v0, p0, Lcom/google/ads/bk;->d:Ljava/util/HashMap;

    const-string v1, "gwhirl_share_location"

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    const/4 v0, 0x1

    :goto_2a
    iput-boolean v0, p0, Lcom/google/ads/bk;->e:Z

    return-void

    :cond_2d
    if-eqz v0, :cond_4f

    const-string v1, "0"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4f

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Received an illegal value, \'"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\', for the special share location parameter from mediation server (expected \'0\' or \'1\'). Will not share the location."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->b(Ljava/lang/String;)V

    :cond_4f
    const/4 v0, 0x0

    goto :goto_2a
.end method

.method private a(Ljava/lang/String;Ljava/lang/Throwable;Lcom/google/ads/bh;)V
    .registers 5

    invoke-static {p1, p2}, Lcom/google/ads/util/e;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    invoke-virtual {v0, p3}, Lcom/google/ads/bi;->a(Lcom/google/ads/bh;)V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Trying to instantiate: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/google/ads/bk;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/ads/util/e;->a(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/ads/bk;->b:Ljava/lang/String;

    const-class v1, Lcom/google/ads/a/b;

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/ads/a/b;

    iget-object v1, p0, Lcom/google/ads/bk;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/Activity;

    if-nez v1, :cond_56

    new-instance v0, Lcom/google/ads/bl;

    const-string v1, "Activity became null while trying to instantiate adapter."

    invoke-direct {v0, v1}, Lcom/google/ads/bl;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_38
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_38} :catch_38
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_38} :catch_ab

    :catch_38
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Cannot find adapter class \'"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/google/ads/bk;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\'. Did you link the ad network\'s mediation adapter? Skipping ad network."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/google/ads/bh;->e:Lcom/google/ads/bh;

    invoke-direct {p0, v1, v0, v2}, Lcom/google/ads/bk;->a(Ljava/lang/String;Ljava/lang/Throwable;Lcom/google/ads/bh;)V

    :goto_55
    return-void

    :cond_56
    :try_start_56
    iget-object v2, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    invoke-virtual {v2, v0}, Lcom/google/ads/bi;->a(Lcom/google/ads/a/b;)V

    invoke-interface {v0}, Lcom/google/ads/a/b;->c()Ljava/lang/Class;

    move-result-object v2

    if-eqz v2, :cond_6c

    invoke-virtual {v2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/ads/a/e;

    iget-object v3, p0, Lcom/google/ads/bk;->d:Ljava/util/HashMap;

    invoke-virtual {v2, v3}, Lcom/google/ads/a/e;->a(Ljava/util/Map;)V

    :cond_6c
    invoke-interface {v0}, Lcom/google/ads/a/b;->b()Ljava/lang/Class;

    move-result-object v2

    if-eqz v2, :cond_77

    iget-object v3, p0, Lcom/google/ads/bk;->c:Lcom/google/ads/d;

    invoke-virtual {v3, v2}, Lcom/google/ads/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    :cond_77
    new-instance v2, Lcom/google/ads/a/a;

    iget-object v3, p0, Lcom/google/ads/bk;->c:Lcom/google/ads/d;

    iget-boolean v4, p0, Lcom/google/ads/bk;->e:Z

    invoke-direct {v2, v3, v1, v4}, Lcom/google/ads/a/a;-><init>(Lcom/google/ads/d;Landroid/content/Context;Z)V

    iget-object v1, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    iget-object v1, v1, Lcom/google/ads/bi;->a:Lcom/google/ads/internal/z;

    invoke-virtual {v1}, Lcom/google/ads/internal/z;->a()Z

    move-result v1

    if-eqz v1, :cond_c6

    instance-of v1, v0, Lcom/google/ads/a/d;

    if-nez v1, :cond_b4

    new-instance v0, Lcom/google/ads/bl;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Adapter "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/google/ads/bk;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " doesn\'t support the MediationInterstitialAdapter interface."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/ads/bl;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_ab
    .catch Ljava/lang/ClassNotFoundException; {:try_start_56 .. :try_end_ab} :catch_38
    .catch Ljava/lang/Throwable; {:try_start_56 .. :try_end_ab} :catch_ab

    :catch_ab
    move-exception v0

    const-string v1, "Error while creating adapter and loading ad from ad network. Skipping ad network."

    sget-object v2, Lcom/google/ads/bh;->f:Lcom/google/ads/bh;

    invoke-direct {p0, v1, v0, v2}, Lcom/google/ads/bk;->a(Ljava/lang/String;Ljava/lang/Throwable;Lcom/google/ads/bh;)V

    goto :goto_55

    :cond_b4
    :try_start_b4
    check-cast v0, Lcom/google/ads/a/d;

    new-instance v1, Lcom/google/ads/bn;

    iget-object v2, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    invoke-direct {v1, v2}, Lcom/google/ads/bn;-><init>(Lcom/google/ads/bi;)V

    invoke-interface {v0}, Lcom/google/ads/a/d;->d()V

    :goto_c0
    iget-object v0, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    invoke-virtual {v0}, Lcom/google/ads/bi;->g()V

    goto :goto_55

    :cond_c6
    instance-of v1, v0, Lcom/google/ads/a/c;

    if-nez v1, :cond_e7

    new-instance v0, Lcom/google/ads/bl;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Adapter "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/google/ads/bk;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " doesn\'t support the MediationBannerAdapter interface"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/ads/bl;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e7
    check-cast v0, Lcom/google/ads/a/c;

    new-instance v1, Lcom/google/ads/bm;

    iget-object v2, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    invoke-direct {v1, v2}, Lcom/google/ads/bm;-><init>(Lcom/google/ads/bi;)V

    iget-object v1, p0, Lcom/google/ads/bk;->a:Lcom/google/ads/bi;

    iget-object v1, v1, Lcom/google/ads/bi;->a:Lcom/google/ads/internal/z;

    invoke-virtual {v1}, Lcom/google/ads/internal/z;->c()Lcom/google/ads/g;

    invoke-interface {v0}, Lcom/google/ads/a/c;->d()V
    :try_end_fa
    .catch Ljava/lang/ClassNotFoundException; {:try_start_b4 .. :try_end_fa} :catch_38
    .catch Ljava/lang/Throwable; {:try_start_b4 .. :try_end_fa} :catch_ab

    goto :goto_c0
.end method
