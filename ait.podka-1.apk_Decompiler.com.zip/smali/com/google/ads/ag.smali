###### Class com.google.ads.ag (com.google.ads.ag)
.class public abstract Lcom/google/ads/ag;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/ads/af;


# instance fields
.field protected a:Landroid/view/MotionEvent;

.field protected b:Landroid/util/DisplayMetrics;

.field private c:Lcom/google/ads/au;

.field private d:Ljava/io/ByteArrayOutputStream;


# direct methods
.method protected constructor <init>(Landroid/content/Context;)V
    .registers 4

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/google/ads/ag;->c:Lcom/google/ads/au;

    iput-object v0, p0, Lcom/google/ads/ag;->d:Ljava/io/ByteArrayOutputStream;

    iput-object v0, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    iput-object v0, p0, Lcom/google/ads/ag;->b:Landroid/util/DisplayMetrics;

    :try_start_c
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iput-object v0, p0, Lcom/google/ads/ag;->b:Landroid/util/DisplayMetrics;
    :try_end_16
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_c .. :try_end_16} :catch_17

    :goto_16
    return-void

    :catch_17
    move-exception v0

    new-instance v0, Landroid/util/DisplayMetrics;

    invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V

    iput-object v0, p0, Lcom/google/ads/ag;->b:Landroid/util/DisplayMetrics;

    iget-object v0, p0, Lcom/google/ads/ag;->b:Landroid/util/DisplayMetrics;

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, v0, Landroid/util/DisplayMetrics;->density:F

    goto :goto_16
.end method

.method private a()V
    .registers 4

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    iput-object v0, p0, Lcom/google/ads/ag;->d:Ljava/io/ByteArrayOutputStream;

    iget-object v0, p0, Lcom/google/ads/ag;->d:Ljava/io/ByteArrayOutputStream;

    new-instance v1, Lcom/google/ads/au;

    const/16 v2, 0x1000

    new-array v2, v2, [B

    invoke-direct {v1, v0, v2}, Lcom/google/ads/au;-><init>(Ljava/io/OutputStream;[B)V

    iput-object v1, p0, Lcom/google/ads/ag;->c:Lcom/google/ads/au;

    return-void
.end method

.method private b()[B
    .registers 3

    iget-object v0, p0, Lcom/google/ads/ag;->c:Lcom/google/ads/au;

    iget-object v1, v0, Lcom/google/ads/au;->e:Ljava/io/OutputStream;

    if-eqz v1, :cond_9

    invoke-virtual {v0}, Lcom/google/ads/au;->a()V

    :cond_9
    iget-object v0, p0, Lcom/google/ads/ag;->d:Ljava/io/ByteArrayOutputStream;

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    const/4 v0, 0x1

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/ads/ag;->a(Landroid/content/Context;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final a(Landroid/content/Context;Ljava/lang/String;Z)Ljava/lang/String;
    .registers 10

    const/16 v3, 0xef

    const/16 v5, 0x20

    const/4 v4, 0x7

    :try_start_5
    invoke-direct {p0}, Lcom/google/ads/ag;->a()V

    if-eqz p3, :cond_1a

    invoke-virtual {p0, p1}, Lcom/google/ads/ag;->b(Landroid/content/Context;)V

    :goto_d
    invoke-direct {p0}, Lcom/google/ads/ag;->b()[B

    move-result-object v0

    array-length v1, v0

    if-nez v1, :cond_24

    const/4 v0, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    :goto_19
    return-object v0

    :cond_1a
    invoke-virtual {p0, p1}, Lcom/google/ads/ag;->a(Landroid/content/Context;)V
    :try_end_1d
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_5 .. :try_end_1d} :catch_1e
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_5 .. :try_end_1d} :catch_c6
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_1d} :catch_cd

    goto :goto_d

    :catch_1e
    move-exception v0

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_19

    :cond_24
    :try_start_24
    array-length v1, v0

    if-le v1, v3, :cond_35

    invoke-direct {p0}, Lcom/google/ads/ag;->a()V

    const/16 v0, 0x14

    const-wide/16 v1, 0x1

    invoke-virtual {p0, v0, v1, v2}, Lcom/google/ads/ag;->a(IJ)V

    invoke-direct {p0}, Lcom/google/ads/ag;->b()[B

    move-result-object v0

    :cond_35
    array-length v1, v0

    if-ge v1, v3, :cond_b1

    array-length v1, v0

    rsub-int v1, v1, 0xef

    new-array v1, v1, [B

    new-instance v2, Ljava/security/SecureRandom;

    invoke-direct {v2}, Ljava/security/SecureRandom;-><init>()V

    invoke-virtual {v2, v1}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/16 v2, 0xf0

    invoke-static {v2}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v2

    array-length v3, v0

    int-to-byte v3, v3

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    :goto_5d
    const-string v1, "MD5"

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/security/MessageDigest;->update([B)V

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    const/16 v2, 0x100

    invoke-static {v2}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/16 v1, 0x100

    new-array v1, v1, [B

    new-instance v2, Lcom/google/ads/q;

    invoke-direct {v2}, Lcom/google/ads/q;-><init>()V

    invoke-virtual {v2, v0, v1}, Lcom/google/ads/q;->a([B[B)V

    if-eqz p2, :cond_ab

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_ab

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v5, :cond_9d

    const/4 v0, 0x0

    const/16 v2, 0x20

    invoke-virtual {p2, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    :cond_9d
    const-string v0, "UTF-8"

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    new-instance v2, Lcom/google/ads/ap;

    invoke-direct {v2, v0}, Lcom/google/ads/ap;-><init>([B)V

    invoke-virtual {v2, v1}, Lcom/google/ads/ap;->a([B)V

    :cond_ab
    invoke-static {v1}, Lcom/google/ads/ao;->a([B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_19

    :cond_b1
    const/16 v1, 0xf0

    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    array-length v2, v0

    int-to-byte v2, v2

    invoke-virtual {v1, v2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B
    :try_end_c4
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_24 .. :try_end_c4} :catch_1e
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_24 .. :try_end_c4} :catch_c6
    .catch Ljava/io/IOException; {:try_start_24 .. :try_end_c4} :catch_cd

    move-result-object v0

    goto :goto_5d

    :catch_c6
    move-exception v0

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_19

    :catch_cd
    move-exception v0

    const/4 v0, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_19
.end method

.method public final a(III)V
    .registers 19

    iget-object v1, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    if-eqz v1, :cond_9

    iget-object v1, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    :cond_9
    const-wide/16 v1, 0x0

    move/from16 v0, p3

    int-to-long v3, v0

    const/4 v5, 0x1

    move/from16 v0, p1

    int-to-float v6, v0

    iget-object v7, p0, Lcom/google/ads/ag;->b:Landroid/util/DisplayMetrics;

    iget v7, v7, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v6, v7

    move/from16 v0, p2

    int-to-float v7, v0

    iget-object v8, p0, Lcom/google/ads/ag;->b:Landroid/util/DisplayMetrics;

    iget v8, v8, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v7, v8

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v1 .. v14}, Landroid/view/MotionEvent;->obtain(JJIFFFFIFFII)Landroid/view/MotionEvent;

    move-result-object v1

    iput-object v1, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    return-void
.end method

.method protected final a(IJ)V
    .registers 9

    iget-object v0, p0, Lcom/google/ads/ag;->c:Lcom/google/ads/au;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Lcom/google/ads/au;->a(II)V

    :goto_6
    const-wide/16 v1, -0x80

    and-long/2addr v1, p2

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-nez v1, :cond_14

    long-to-int v1, p2

    invoke-virtual {v0, v1}, Lcom/google/ads/au;->a(I)V

    return-void

    :cond_14
    long-to-int v1, p2

    and-int/lit8 v1, v1, 0x7f

    or-int/lit16 v1, v1, 0x80

    invoke-virtual {v0, v1}, Lcom/google/ads/au;->a(I)V

    const/4 v1, 0x7

    ushr-long/2addr p2, v1

    goto :goto_6
.end method

.method protected final a(ILjava/lang/String;)V
    .registers 10

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/ads/ag;->c:Lcom/google/ads/au;

    const/4 v0, 0x2

    invoke-virtual {v1, p1, v0}, Lcom/google/ads/au;->a(II)V

    const-string v0, "UTF-8"

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v2

    array-length v0, v2

    invoke-virtual {v1, v0}, Lcom/google/ads/au;->b(I)V

    array-length v0, v2

    iget v3, v1, Lcom/google/ads/au;->b:I

    iget v4, v1, Lcom/google/ads/au;->c:I

    sub-int/2addr v3, v4

    if-lt v3, v0, :cond_2b

    iget-object v3, v1, Lcom/google/ads/au;->a:[B

    iget v4, v1, Lcom/google/ads/au;->c:I

    invoke-static {v2, v6, v3, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v2, v1, Lcom/google/ads/au;->c:I

    add-int/2addr v2, v0

    iput v2, v1, Lcom/google/ads/au;->c:I

    :goto_25
    iget v2, v1, Lcom/google/ads/au;->d:I

    add-int/2addr v0, v2

    iput v0, v1, Lcom/google/ads/au;->d:I

    return-void

    :cond_2b
    iget v3, v1, Lcom/google/ads/au;->b:I

    iget v4, v1, Lcom/google/ads/au;->c:I

    sub-int/2addr v3, v4

    iget-object v4, v1, Lcom/google/ads/au;->a:[B

    iget v5, v1, Lcom/google/ads/au;->c:I

    invoke-static {v2, v6, v4, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/lit8 v4, v3, 0x0

    sub-int/2addr v0, v3

    iget v5, v1, Lcom/google/ads/au;->b:I

    iput v5, v1, Lcom/google/ads/au;->c:I

    iget v5, v1, Lcom/google/ads/au;->d:I

    add-int/2addr v3, v5

    iput v3, v1, Lcom/google/ads/au;->d:I

    invoke-virtual {v1}, Lcom/google/ads/au;->a()V

    iget v3, v1, Lcom/google/ads/au;->b:I

    if-gt v0, v3, :cond_52

    iget-object v3, v1, Lcom/google/ads/au;->a:[B

    invoke-static {v2, v4, v3, v6, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput v0, v1, Lcom/google/ads/au;->c:I

    goto :goto_25

    :cond_52
    iget-object v3, v1, Lcom/google/ads/au;->e:Ljava/io/OutputStream;

    invoke-virtual {v3, v2, v4, v0}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_25
.end method

.method protected abstract a(Landroid/content/Context;)V
.end method

.method public final a(Landroid/view/MotionEvent;)V
    .registers 4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_16

    iget-object v0, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    if-eqz v0, :cond_10

    iget-object v0, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    :cond_10
    invoke-static {p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v0

    iput-object v0, p0, Lcom/google/ads/ag;->a:Landroid/view/MotionEvent;

    :cond_16
    return-void
.end method

.method protected abstract b(Landroid/content/Context;)V
.end method
