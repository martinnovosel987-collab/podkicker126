###### Class com.google.ads.k (com.google.ads.k)
.class public final Lcom/google/ads/k;
.super Ljava/lang/Object;


# instance fields
.field final a:Ljava/lang/String;

.field final b:Ljava/lang/String;

.field final c:Ljava/util/List;

.field final d:Ljava/util/List;

.field final e:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/HashMap;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p2}, Lcom/google/ads/util/c;->a(Ljava/lang/String;)V

    if-eqz p1, :cond_b

    invoke-static {p1}, Lcom/google/ads/util/c;->a(Ljava/lang/String;)V

    :cond_b
    iput-object p1, p0, Lcom/google/ads/k;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/google/ads/k;->b:Ljava/lang/String;

    iput-object p3, p0, Lcom/google/ads/k;->c:Ljava/util/List;

    iput-object p5, p0, Lcom/google/ads/k;->e:Ljava/util/HashMap;

    iput-object p4, p0, Lcom/google/ads/k;->d:Ljava/util/List;

    return-void
.end method
