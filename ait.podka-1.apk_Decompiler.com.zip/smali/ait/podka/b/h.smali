###### Class ait.podka.b.h (ait.podka.b.h)
.class public final enum Lait/podka/b/h;
.super Ljava/lang/Enum;


# static fields
.field public static final enum a:Lait/podka/b/h;

.field public static final enum b:Lait/podka/b/h;

.field public static final enum c:Lait/podka/b/h;

.field public static final enum d:Lait/podka/b/h;

.field public static final enum e:Lait/podka/b/h;

.field private static final synthetic f:[Lait/podka/b/h;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Lait/podka/b/h;

    const-string v1, "ATOM_1"

    invoke-direct {v0, v1, v2}, Lait/podka/b/h;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lait/podka/b/h;->a:Lait/podka/b/h;

    new-instance v0, Lait/podka/b/h;

    const-string v1, "ATOM_0_3"

    invoke-direct {v0, v1, v3}, Lait/podka/b/h;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lait/podka/b/h;->b:Lait/podka/b/h;

    new-instance v0, Lait/podka/b/h;

    const-string v1, "RSS_1"

    invoke-direct {v0, v1, v4}, Lait/podka/b/h;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lait/podka/b/h;->c:Lait/podka/b/h;

    new-instance v0, Lait/podka/b/h;

    const-string v1, "RSS_2"

    invoke-direct {v0, v1, v5}, Lait/podka/b/h;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lait/podka/b/h;->d:Lait/podka/b/h;

    new-instance v0, Lait/podka/b/h;

    const-string v1, "UNKNOWN"

    invoke-direct {v0, v1, v6}, Lait/podka/b/h;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lait/podka/b/h;->e:Lait/podka/b/h;

    const/4 v0, 0x5

    new-array v0, v0, [Lait/podka/b/h;

    sget-object v1, Lait/podka/b/h;->a:Lait/podka/b/h;

    aput-object v1, v0, v2

    sget-object v1, Lait/podka/b/h;->b:Lait/podka/b/h;

    aput-object v1, v0, v3

    sget-object v1, Lait/podka/b/h;->c:Lait/podka/b/h;

    aput-object v1, v0, v4

    sget-object v1, Lait/podka/b/h;->d:Lait/podka/b/h;

    aput-object v1, v0, v5

    sget-object v1, Lait/podka/b/h;->e:Lait/podka/b/h;

    aput-object v1, v0, v6

    sput-object v0, Lait/podka/b/h;->f:[Lait/podka/b/h;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lait/podka/b/h;
    .registers 2

    const-class v0, Lait/podka/b/h;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lait/podka/b/h;

    return-object v0
.end method

.method public static values()[Lait/podka/b/h;
    .registers 4

    const/4 v3, 0x0

    sget-object v0, Lait/podka/b/h;->f:[Lait/podka/b/h;

    array-length v1, v0

    new-array v2, v1, [Lait/podka/b/h;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method
