###### Class ait.podka.b.b (ait.podka.b.b)
.class public final Lait/podka/b/b;
.super Ljava/util/Observable;


# static fields
.field private static synthetic d:[I


# instance fields
.field private final a:Landroid/content/ContentResolver;

.field private b:Landroid/content/Context;

.field private c:Landroid/content/Intent;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    invoke-direct {p0}, Ljava/util/Observable;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iput-object v0, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    invoke-virtual {p0}, Lait/podka/b/b;->setChanged()V

    new-instance v0, Landroid/content/Intent;

    const-string v1, "refreshBroadcast"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/b/b;->c:Landroid/content/Intent;

    iput-object p1, p0, Lait/podka/b/b;->b:Landroid/content/Context;

    return-void
.end method

.method private static synthetic b()[I
    .registers 3

    sget-object v0, Lait/podka/b/b;->d:[I

    if-eqz v0, :cond_5

    :goto_4
    return-object v0

    :cond_5
    invoke-static {}, Lait/podka/b/h;->values()[Lait/podka/b/h;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_c
    sget-object v1, Lait/podka/b/h;->b:Lait/podka/b/h;

    invoke-virtual {v1}, Lait/podka/b/h;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_15
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_15} :catch_44

    :goto_15
    :try_start_15
    sget-object v1, Lait/podka/b/h;->a:Lait/podka/b/h;

    invoke-virtual {v1}, Lait/podka/b/h;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_1e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_15 .. :try_end_1e} :catch_42

    :goto_1e
    :try_start_1e
    sget-object v1, Lait/podka/b/h;->c:Lait/podka/b/h;

    invoke-virtual {v1}, Lait/podka/b/h;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_27
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1e .. :try_end_27} :catch_40

    :goto_27
    :try_start_27
    sget-object v1, Lait/podka/b/h;->d:Lait/podka/b/h;

    invoke-virtual {v1}, Lait/podka/b/h;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_30
    .catch Ljava/lang/NoSuchFieldError; {:try_start_27 .. :try_end_30} :catch_3e

    :goto_30
    :try_start_30
    sget-object v1, Lait/podka/b/h;->e:Lait/podka/b/h;

    invoke-virtual {v1}, Lait/podka/b/h;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_39
    .catch Ljava/lang/NoSuchFieldError; {:try_start_30 .. :try_end_39} :catch_3c

    :goto_39
    sput-object v0, Lait/podka/b/b;->d:[I

    goto :goto_4

    :catch_3c
    move-exception v1

    goto :goto_39

    :catch_3e
    move-exception v1

    goto :goto_30

    :catch_40
    move-exception v1

    goto :goto_27

    :catch_42
    move-exception v1

    goto :goto_1e

    :catch_44
    move-exception v1

    goto :goto_15
.end method

.method private d(Ljava/lang/String;)V
    .registers 16

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x1

    :try_start_5
    new-instance v9, Ljava/net/URL;

    invoke-direct {v9, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    new-instance v10, Lait/podka/b/d;

    invoke-direct {v10}, Lait/podka/b/d;-><init>()V

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/net/HttpURLConnection;->setFollowRedirects(Z)V

    iput-object p1, v10, Lait/podka/b/d;->f:Ljava/lang/String;

    iget-object v0, v10, Lait/podka/b/d;->f:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v1, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Parsing "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v10, Lait/podka/b/d;->f:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    const/4 v0, 0x5

    new-array v2, v0, [Ljava/lang/String;

    const/4 v0, 0x0

    const-string v1, "_id"

    aput-object v1, v2, v0

    const/4 v0, 0x1

    const-string v1, "ch_feedlink"

    aput-object v1, v2, v0

    const/4 v0, 0x2

    const-string v1, "ch_etag"

    aput-object v1, v2, v0

    const/4 v0, 0x3

    const-string v1, "ch_lastmodified"

    aput-object v1, v2, v0

    const/4 v0, 0x4

    const-string v1, "ch_ignorecache"

    aput-object v1, v2, v0

    const-string v3, "ch_feedlink = ?"

    const/4 v0, 0x1

    new-array v4, v0, [Ljava/lang/String;

    const/4 v0, 0x0

    iget-object v1, v10, Lait/podka/b/d;->f:Ljava/lang/String;

    aput-object v1, v4, v0

    iget-object v0, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    if-eqz v1, :cond_a3

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_a3

    const-string v0, "ch_etag"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v10, Lait/podka/b/d;->h:Ljava/lang/String;

    const-string v0, "ch_ignorecache"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-ne v0, v8, :cond_10c

    move v0, v8

    :goto_81
    iput-boolean v0, v10, Lait/podka/b/d;->k:Z

    const-string v0, "ch_lastmodified"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v2

    iput-wide v2, v10, Lait/podka/b/d;->i:J

    iget-wide v2, v10, Lait/podka/b/d;->i:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-lez v0, :cond_a3

    sget-object v0, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    new-instance v2, Ljava/util/Date;

    iget-wide v3, v10, Lait/podka/b/d;->i:J

    invoke-direct {v2, v3, v4}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v2}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    :cond_a3
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v9}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_ac
    .catchall {:try_start_5 .. :try_end_ac} :catchall_282

    const/16 v1, 0x3a98

    :try_start_ae
    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/16 v1, 0x3a98

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const-string v1, "Accept-Encoding"

    const-string v2, "gzip, deflate"

    invoke-virtual {v0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "User-Agent"

    sget-object v2, Lait/podka/Podka;->d:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, v10, Lait/podka/b/d;->h:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_d7

    iget-boolean v1, v10, Lait/podka/b/d;->k:Z

    if-nez v1, :cond_d7

    const-string v1, "If-None-Match"

    iget-object v2, v10, Lait/podka/b/d;->h:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_d7
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->connect()V

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    const/16 v2, 0x130

    if-ne v1, v2, :cond_10f

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "HTTP response: "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ". Not modified"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v3, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {p0, v1}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V
    :try_end_106
    .catchall {:try_start_ae .. :try_end_106} :catchall_12c

    if-eqz v0, :cond_10b

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_10b
    :goto_10b
    return-void

    :cond_10c
    move v0, v7

    goto/16 :goto_81

    :cond_10f
    :try_start_10f
    div-int/lit8 v2, v1, 0x64

    if-eq v2, v11, :cond_13b

    div-int/lit8 v2, v1, 0x64

    if-eq v2, v12, :cond_13b

    new-instance v2, Ljava/lang/Exception;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "HTTP response "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_12c
    .catchall {:try_start_10f .. :try_end_12c} :catchall_12c

    :catchall_12c
    move-exception v1

    move-object v13, v1

    move-object v1, v0

    move-object v0, v13

    :goto_130
    if-eqz v6, :cond_135

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V

    :cond_135
    if-eqz v1, :cond_13a

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_13a
    throw v0

    :cond_13b
    :try_start_13b
    const-string v1, "Last-Modified"

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_14f

    const-string v1, "Last-Modified"

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lait/podka/b/c;->b(Ljava/lang/String;)J

    move-result-wide v1

    iput-wide v1, v10, Lait/podka/b/d;->i:J

    :cond_14f
    const-string v1, "ETag"

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v10, Lait/podka/b/d;->h:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getContentEncoding()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1e1

    const-string v2, "gzip"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e1

    new-instance v1, Ljava/util/zip/GZIPInputStream;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v3, v1

    :goto_16f
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getContentType()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_28d

    const-string v2, ";"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    array-length v5, v4

    move v2, v7

    move-object v1, v6

    :goto_17e
    if-lt v2, v5, :cond_204

    :goto_180
    invoke-static {}, Lorg/xmlpull/v1/XmlPullParserFactory;->newInstance()Lorg/xmlpull/v1/XmlPullParserFactory;

    move-result-object v2

    sget-object v4, Landroid/util/Xml;->FEATURE_RELAXED:Ljava/lang/String;

    const/4 v5, 0x1

    invoke-virtual {v2, v4, v5}, Lorg/xmlpull/v1/XmlPullParserFactory;->setFeature(Ljava/lang/String;Z)V

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Lorg/xmlpull/v1/XmlPullParserFactory;->setValidating(Z)V

    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Lorg/xmlpull/v1/XmlPullParserFactory;->setNamespaceAware(Z)V

    invoke-virtual {v2}, Lorg/xmlpull/v1/XmlPullParserFactory;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;
    :try_end_195
    .catchall {:try_start_13b .. :try_end_195} :catchall_12c

    move-result-object v4

    :try_start_196
    invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;
    :try_end_199
    .catch Ljava/lang/Exception; {:try_start_196 .. :try_end_199} :catch_220
    .catchall {:try_start_196 .. :try_end_199} :catchall_12c

    move-result-object v1

    :goto_19a
    if-eqz v1, :cond_227

    :try_start_19c
    new-instance v2, Ljava/io/BufferedReader;

    new-instance v5, Ljava/io/InputStreamReader;

    invoke-direct {v5, v3, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    const/16 v1, 0x2000

    invoke-direct {v2, v5, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_1a8
    .catchall {:try_start_19c .. :try_end_1a8} :catchall_12c

    :try_start_1a8
    invoke-interface {v4, v2}, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/Reader;)V
    :try_end_1ab
    .catchall {:try_start_1a8 .. :try_end_1ab} :catchall_286

    move-object v6, v2

    :goto_1ac
    :try_start_1ac
    invoke-static {v4}, Lait/podka/b/g;->a(Lorg/xmlpull/v1/XmlPullParser;)Lait/podka/b/h;
    :try_end_1af
    .catch Ljava/lang/Exception; {:try_start_1ac .. :try_end_1af} :catch_22c
    .catchall {:try_start_1ac .. :try_end_1af} :catchall_12c

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    :try_start_1b2
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v7, "Feedtype detected: "

    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Lait/podka/b/h;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v3, v5}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {p0, v2}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    invoke-static {}, Lait/podka/b/b;->b()[I

    move-result-object v2

    invoke-virtual {v1}, Lait/podka/b/h;->ordinal()I

    move-result v1

    aget v1, v2, v1

    packed-switch v1, :pswitch_data_290

    new-instance v1, Ljava/lang/Exception;

    const-string v2, "Feedtype unknown"

    invoke-direct {v1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1e1
    if-eqz v1, :cond_1fd

    const-string v2, "deflate"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1fd

    new-instance v1, Ljava/util/zip/InflaterInputStream;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    new-instance v3, Ljava/util/zip/Inflater;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Ljava/util/zip/Inflater;-><init>(Z)V

    invoke-direct {v1, v2, v3}, Ljava/util/zip/InflaterInputStream;-><init>(Ljava/io/InputStream;Ljava/util/zip/Inflater;)V

    move-object v3, v1

    goto/16 :goto_16f

    :cond_1fd
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    move-object v3, v1

    goto/16 :goto_16f

    :cond_204
    aget-object v7, v4, v2

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v8

    const-string v9, "charset="

    invoke-virtual {v8, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_21c

    const/16 v1, 0x8

    invoke-virtual {v7, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    :cond_21c
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_17e

    :catch_220
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-object v1, v6

    goto/16 :goto_19a

    :cond_227
    const/4 v1, 0x0

    invoke-interface {v4, v3, v1}, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/InputStream;Ljava/lang/String;)V

    goto :goto_1ac

    :catch_22c
    move-exception v1

    invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getInputEncoding()Ljava/lang/String;

    invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "Not a valid feed"

    invoke-direct {v2, v3, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2

    :pswitch_23b
    new-instance v1, Lait/podka/b/j;

    iget-object v2, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    invoke-direct {v1, p0, v2}, Lait/podka/b/j;-><init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V

    invoke-virtual {v1, v4, v10}, Lait/podka/b/j;->c(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    :try_end_245
    .catchall {:try_start_1b2 .. :try_end_245} :catchall_12c

    :goto_245
    if-eqz v6, :cond_24a

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V

    :cond_24a
    if-eqz v0, :cond_10b

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    goto/16 :goto_10b

    :pswitch_251
    :try_start_251
    new-instance v1, Lait/podka/b/k;

    iget-object v2, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    invoke-direct {v1, p0, v2}, Lait/podka/b/k;-><init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V

    invoke-virtual {v1, v4, v10}, Lait/podka/b/k;->c(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V

    goto :goto_245

    :pswitch_25c
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Feedtype not supported: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v3, Lait/podka/b/h;->b:Lait/podka/b/h;

    invoke-virtual {v3}, Lait/podka/b/h;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :pswitch_277
    new-instance v1, Lait/podka/b/a;

    iget-object v2, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    invoke-direct {v1, p0, v2}, Lait/podka/b/a;-><init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V

    invoke-virtual {v1, v4, v10}, Lait/podka/b/a;->c(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    :try_end_281
    .catchall {:try_start_251 .. :try_end_281} :catchall_12c

    goto :goto_245

    :catchall_282
    move-exception v0

    move-object v1, v6

    goto/16 :goto_130

    :catchall_286
    move-exception v1

    move-object v6, v2

    move-object v13, v0

    move-object v0, v1

    move-object v1, v13

    goto/16 :goto_130

    :cond_28d
    move-object v1, v6

    goto/16 :goto_180

    :pswitch_data_290
    .packed-switch 0x1
        :pswitch_277
        :pswitch_25c
        :pswitch_23b
        :pswitch_251
    .end packed-switch
.end method


# virtual methods
.method public final a()V
    .registers 8

    const/4 v2, 0x1

    const/4 v6, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lait/podka/b/b;->c:Landroid/content/Intent;

    const-string v1, "refreshing"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    iget-object v0, p0, Lait/podka/b/b;->b:Landroid/content/Context;

    iget-object v1, p0, Lait/podka/b/b;->c:Landroid/content/Intent;

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    new-array v2, v2, [Ljava/lang/String;

    const-string v0, "ch_feedlink"

    aput-object v0, v2, v6

    iget-object v0, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    move-object v4, v3

    move-object v5, v3

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    :goto_21
    if-eqz v0, :cond_29

    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-nez v1, :cond_3b

    :cond_29
    iget-object v1, p0, Lait/podka/b/b;->c:Landroid/content/Intent;

    const-string v2, "refreshing"

    invoke-virtual {v1, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    iget-object v1, p0, Lait/podka/b/b;->b:Landroid/content/Context;

    iget-object v2, p0, Lait/podka/b/b;->c:Landroid/content/Intent;

    invoke-virtual {v1, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    return-void

    :cond_3b
    const-string v1, "ch_feedlink"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lait/podka/b/b;->b(Ljava/lang/String;)V

    goto :goto_21
.end method

.method public final a(Ljava/lang/String;)V
    .registers 6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    :try_start_3
    const-string v2, "Subscribing"

    invoke-static {v0, v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    invoke-direct {p0, p1}, Lait/podka/b/b;->d(Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string v2, "Done subscribing"

    invoke-static {v0, v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_1a} :catch_1b

    :goto_1a
    return-void

    :catch_1b
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v1, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v1, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    goto :goto_1a
.end method

.method public final b(Ljava/lang/String;)V
    .registers 6

    :try_start_0
    invoke-direct {p0, p1}, Lait/podka/b/b;->d(Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_3} :catch_4

    :goto_3
    return-void

    :catch_4
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v2, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    goto :goto_3
.end method

.method public final declared-synchronized c(Ljava/lang/String;)V
    .registers 10

    const/4 v6, 0x0

    monitor-enter p0

    :try_start_2
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_7
    .catch Ljava/net/MalformedURLException; {:try_start_2 .. :try_end_7} :catch_40
    .catchall {:try_start_2 .. :try_end_7} :catchall_5c

    :try_start_7
    new-instance v7, Landroid/content/ContentValues;

    invoke-direct {v7}, Landroid/content/ContentValues;-><init>()V

    const-string v0, "ch_feedlink"

    invoke-virtual {v7, v0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "ch_title"

    const-string v1, "(need refresh)"

    invoke-virtual {v7, v0, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v3, "ch_feedlink = ?"

    const/4 v0, 0x1

    new-array v4, v0, [Ljava/lang/String;

    const/4 v0, 0x0

    aput-object p1, v4, v0
    :try_end_20
    .catchall {:try_start_7 .. :try_end_20} :catchall_5c

    :try_start_20
    iget-object v0, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    const/4 v2, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_29} :catch_5f
    .catchall {:try_start_20 .. :try_end_29} :catchall_6a

    move-result-object v1

    if-eqz v1, :cond_32

    :try_start_2c
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-nez v0, :cond_39

    :cond_32
    iget-object v0, p0, Lait/podka/b/b;->a:Landroid/content/ContentResolver;

    sget-object v2, Lait/podka/database/d;->a:Landroid/net/Uri;

    invoke-virtual {v0, v2, v7}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    :try_end_39
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_39} :catch_74
    .catchall {:try_start_2c .. :try_end_39} :catchall_72

    :cond_39
    if-eqz v1, :cond_3e

    :try_start_3b
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_3e
    .catchall {:try_start_3b .. :try_end_3e} :catchall_5c

    :cond_3e
    :goto_3e
    monitor-exit p0

    return-void

    :catch_40
    move-exception v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :try_start_43
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/net/MalformedURLException;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v2, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V
    :try_end_5b
    .catchall {:try_start_43 .. :try_end_5b} :catchall_5c

    goto :goto_3e

    :catchall_5c
    move-exception v0

    monitor-exit p0

    throw v0

    :catch_5f
    move-exception v0

    move-object v1, v6

    :goto_61
    :try_start_61
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_64
    .catchall {:try_start_61 .. :try_end_64} :catchall_72

    if-eqz v1, :cond_3e

    :try_start_66
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_3e

    :catchall_6a
    move-exception v0

    move-object v1, v6

    :goto_6c
    if-eqz v1, :cond_71

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_71
    throw v0
    :try_end_72
    .catchall {:try_start_66 .. :try_end_72} :catchall_5c

    :catchall_72
    move-exception v0

    goto :goto_6c

    :catch_74
    move-exception v0

    goto :goto_61
.end method

.method public final hasChanged()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method
