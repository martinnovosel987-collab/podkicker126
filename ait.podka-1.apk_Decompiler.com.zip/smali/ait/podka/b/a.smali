###### Class ait.podka.b.a (ait.podka.b.a)
.class public final Lait/podka/b/a;
.super Lait/podka/b/c;


# direct methods
.method public constructor <init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lait/podka/b/c;-><init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V

    return-void
.end method


# virtual methods
.method final a(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    .registers 8

    const-wide/16 v3, 0x0

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v0

    :goto_6
    const/4 v1, 0x1

    if-ne v0, v1, :cond_1d

    :cond_9
    invoke-virtual {p0, p2}, Lait/podka/b/a;->a(Lait/podka/b/d;)J

    move-result-wide v0

    iput-wide v0, p2, Lait/podka/b/d;->a:J

    iget-wide v0, p2, Lait/podka/b/d;->a:J

    cmp-long v0, v0, v3

    if-gez v0, :cond_96

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "this result should not be -1"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1d
    const/4 v1, 0x2

    if-ne v0, v1, :cond_32

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "title"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_37

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lait/podka/b/d;->e:Ljava/lang/String;

    :cond_32
    :goto_32
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v0

    goto :goto_6

    :cond_37
    const-string v1, "link"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_49

    const/4 v0, 0x0

    const-string v1, "href"

    invoke-interface {p1, v0, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lait/podka/b/d;->g:Ljava/lang/String;

    goto :goto_32

    :cond_49
    const-string v1, "logo"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_58

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lait/podka/b/d;->c:Ljava/lang/String;

    goto :goto_32

    :cond_58
    const-string v1, "subtitle"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_70

    :try_start_60
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lait/podka/b/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lait/podka/b/d;->d:Ljava/lang/String;
    :try_end_6a
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_60 .. :try_end_6a} :catch_6b

    goto :goto_32

    :catch_6b
    move-exception v0

    invoke-virtual {v0}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V

    goto :goto_32

    :cond_70
    const-string v1, "modified"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_8d

    iget-wide v1, p2, Lait/podka/b/d;->i:J

    cmp-long v1, v1, v3

    if-nez v1, :cond_8d

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lait/podka/b/a;->c(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    iput-wide v0, p2, Lait/podka/b/d;->i:J

    goto :goto_32

    :cond_8d
    const-string v1, "entry"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_32

    :cond_96
    return-void
.end method

.method final b(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    .registers 15

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v2

    const/4 v0, 0x0

    iget v1, p2, Lait/podka/b/d;->j:I

    :goto_7
    const/4 v3, 0x1

    if-eq v2, v3, :cond_c

    if-gez v1, :cond_d

    :cond_c
    return-void

    :cond_d
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    packed-switch v2, :pswitch_data_1be

    :cond_14
    move v11, v1

    move-object v1, v0

    move v0, v11

    :goto_17
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v2

    move v11, v0

    move-object v0, v1

    move v1, v11

    goto :goto_7

    :pswitch_1f
    const-string v2, "entry"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_34

    new-instance v0, Lait/podka/b/e;

    invoke-direct {v0}, Lait/podka/b/e;-><init>()V

    iget-wide v2, p2, Lait/podka/b/d;->a:J

    iput-wide v2, v0, Lait/podka/b/e;->a:J

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto :goto_17

    :cond_34
    if-eqz v0, :cond_14

    const-string v2, "title"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_48

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lait/podka/b/e;->d:Ljava/lang/String;

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto :goto_17

    :cond_48
    const-string v2, "id"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_5a

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lait/podka/b/e;->c:Ljava/lang/String;

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto :goto_17

    :cond_5a
    const-string v2, "summary"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_78

    :try_start_62
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lait/podka/b/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lait/podka/b/e;->e:Ljava/lang/String;
    :try_end_6c
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_62 .. :try_end_6c} :catch_70

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto :goto_17

    :catch_70
    move-exception v2

    invoke-virtual {v2}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto :goto_17

    :cond_78
    const-string v2, "updated"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_92

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Lait/podka/b/a;->c(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    iput-wide v2, v0, Lait/podka/b/e;->f:J

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto :goto_17

    :cond_92
    const-string v2, "link"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    const-string v3, "rel"

    invoke-interface {p1, v2, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    const-string v3, "rel"

    invoke-interface {p1, v2, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "enclosure"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    new-instance v2, Lait/podka/b/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v2, v0}, Lait/podka/b/f;-><init>(Lait/podka/b/e;)V

    const/4 v3, 0x0

    const-string v4, "href"

    invoke-interface {p1, v3, v4}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lait/podka/b/f;->b:Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "length"

    invoke-interface {p1, v3, v4}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lait/podka/b/f;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "type"

    invoke-interface {p1, v3, v4}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lait/podka/b/f;->c:Ljava/lang/String;

    iget-object v3, v0, Lait/podka/b/e;->b:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v11, v1

    move-object v1, v0

    move v0, v11

    goto/16 :goto_17

    :pswitch_df
    const-string v2, "entry"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    invoke-virtual {v0}, Lait/podka/b/e;->a()Z

    move-result v2

    if-eqz v2, :cond_14

    invoke-static {v0}, Lait/podka/b/a;->a(Lait/podka/b/e;)V

    iget-object v2, p0, Lait/podka/b/c;->c:Lait/podka/b/b;

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v5, ""

    invoke-static {v3, v4, v5}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    const-wide/16 v2, -0x1

    new-instance v4, Landroid/content/ContentValues;

    invoke-direct {v4}, Landroid/content/ContentValues;-><init>()V

    const-string v5, "ent_parent"

    iget-wide v6, v0, Lait/podka/b/e;->a:J

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string v5, "ent_title"

    iget-object v6, v0, Lait/podka/b/e;->d:Ljava/lang/String;

    invoke-virtual {v4, v5, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, "ent_guid"

    iget-object v6, v0, Lait/podka/b/e;->c:Ljava/lang/String;

    invoke-virtual {v4, v5, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, "ent_pubtime"

    iget-wide v6, v0, Lait/podka/b/e;->f:J

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string v5, "ent_description"

    iget-object v6, v0, Lait/podka/b/e;->e:Ljava/lang/String;

    invoke-virtual {v4, v5, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v5, p0, Lait/podka/b/c;->a:Landroid/content/ContentResolver;

    sget-object v6, Lait/podka/database/f;->a:Landroid/net/Uri;

    invoke-virtual {v5, v6, v4}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v5

    if-eqz v5, :cond_13d

    invoke-static {v5}, Landroid/content/ContentUris;->parseId(Landroid/net/Uri;)J

    move-result-wide v2

    :cond_13d
    invoke-virtual {v4}, Landroid/content/ContentValues;->clear()V

    const-wide/16 v5, -0x1

    cmp-long v5, v2, v5

    if-eqz v5, :cond_152

    iget-object v0, v0, Lait/podka/b/e;->b:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_14c
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_158

    :cond_152
    const/4 v2, 0x0

    add-int/lit8 v0, v1, -0x1

    move-object v1, v2

    goto/16 :goto_17

    :cond_158
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lait/podka/b/f;

    iget-object v6, v0, Lait/podka/b/f;->a:Ljava/lang/String;

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_16a

    const-string v6, "0"

    iput-object v6, v0, Lait/podka/b/f;->a:Ljava/lang/String;

    :cond_16a
    const-string v6, "enc_url"

    iget-object v7, v0, Lait/podka/b/f;->b:Ljava/lang/String;

    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "enc_size"

    iget-object v7, v0, Lait/podka/b/f;->a:Ljava/lang/String;

    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "enc_type"

    iget-object v7, v0, Lait/podka/b/f;->c:Ljava/lang/String;

    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "enc_parent"

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string v6, "enc_filename"

    iget-object v7, v0, Lait/podka/b/f;->b:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v7

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v6, p0, Lait/podka/b/c;->a:Landroid/content/ContentResolver;

    sget-object v7, Lait/podka/database/e;->a:Landroid/net/Uri;

    invoke-virtual {v6, v7, v4}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    iget-object v6, p0, Lait/podka/b/c;->c:Lait/podka/b/b;

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "found "

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, Lait/podka/b/f;->c:Ljava/lang/String;

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v8, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v6, v0}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    invoke-virtual {v4}, Landroid/content/ContentValues;->clear()V

    goto :goto_14c

    :pswitch_data_1be
    .packed-switch 0x2
        :pswitch_1f
        :pswitch_df
    .end packed-switch
.end method
