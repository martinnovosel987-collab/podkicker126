###### Class ait.podka.b.c (ait.podka.b.c)
.class public abstract Lait/podka/b/c;
.super Ljava/lang/Object;


# static fields
.field static b:Ljava/text/SimpleDateFormat;

.field private static final e:[Ljava/lang/String;


# instance fields
.field a:Landroid/content/ContentResolver;

.field final c:Lait/podka/b/b;

.field d:Ljava/util/List;

.field private f:[Ljava/text/DateFormat;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "EEE, dd MMM yyyy HH:mm z"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "dd MMM yyy hh:mm:ss z"

    aput-object v2, v0, v1

    sput-object v0, Lait/podka/b/c;->e:[Ljava/lang/String;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "EEE, dd MMM yyyy HH:mm:ss z"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    sput-object v0, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    return-void
.end method

.method public constructor <init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lait/podka/b/c;->d:Ljava/util/List;

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/text/DateFormat;

    const/4 v1, 0x0

    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy-MM-dd\'T\'HH:mm:ssZ"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    aput-object v2, v0, v1

    const/4 v1, 0x1

    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    aput-object v2, v0, v1

    const/4 v1, 0x2

    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy-MM-dd\'T\'HH:mm:ss"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    aput-object v2, v0, v1

    const/4 v1, 0x3

    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy-MM-dd"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    aput-object v2, v0, v1

    iput-object v0, p0, Lait/podka/b/c;->f:[Ljava/text/DateFormat;

    iput-object p2, p0, Lait/podka/b/c;->a:Landroid/content/ContentResolver;

    iput-object p1, p0, Lait/podka/b/c;->c:Lait/podka/b/b;

    return-void
.end method

.method static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    if-nez p0, :cond_5

    const-string v0, ""

    :goto_4
    return-object v0

    :cond_5
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x800

    if-lt v0, v1, :cond_14

    const/4 v0, 0x0

    const/16 v1, 0x7ff

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_14
    invoke-static {p0}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Spanned;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_4
.end method

.method static a(Lait/podka/b/e;)V
    .registers 5

    iget-object v0, p0, Lait/podka/b/e;->c:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1c

    iget-object v0, p0, Lait/podka/b/e;->c:Ljava/lang/String;

    :goto_a
    invoke-static {v0}, Lait/podka/d/b;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_37

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "You MUST generate a hash"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1c
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lait/podka/b/e;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lait/podka/b/e;->e:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-wide v2, p0, Lait/podka/b/e;->f:J

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_a

    :cond_37
    iput-object v0, p0, Lait/podka/b/e;->c:Ljava/lang/String;

    return-void
.end method

.method static b(Ljava/lang/String;)J
    .registers 12

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_a

    :cond_9
    :goto_9
    return-wide v0

    :cond_a
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    :try_start_e
    sget-object v2, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    invoke-virtual {v2, v5}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Date;->getTime()J
    :try_end_17
    .catch Ljava/text/ParseException; {:try_start_e .. :try_end_17} :catch_2f
    .catchall {:try_start_e .. :try_end_17} :catchall_a1

    move-result-wide v0

    sget-object v2, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    const-string v4, "EEE, dd MMM yyyy HH:mm:ss z"

    invoke-virtual {v2, v4}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V

    :goto_1f
    const-wide/16 v4, 0x7530

    sub-long v4, v0, v4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    cmp-long v2, v4, v6

    if-lez v2, :cond_9

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    goto :goto_9

    :catch_2f
    move-exception v2

    :try_start_30
    invoke-virtual {v2}, Ljava/text/ParseException;->getMessage()Ljava/lang/String;

    sget-object v6, Lait/podka/b/c;->e:[Ljava/lang/String;

    array-length v7, v6

    move v4, v3

    :goto_37
    if-lt v4, v7, :cond_72

    move v2, v3

    :goto_3a
    if-nez v2, :cond_6a

    const-string v2, "(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])"

    const/4 v4, 0x0

    invoke-static {v2, v4}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    if-eqz v4, :cond_6a

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v2

    const-string v4, "[^0-9]"

    const-string v5, ""

    invoke-virtual {v2, v4, v5}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v4, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    const-string v5, "yyyyMMdd"

    invoke-virtual {v4, v5}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V
    :try_end_60
    .catchall {:try_start_30 .. :try_end_60} :catchall_a1

    :try_start_60
    sget-object v4, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    invoke-virtual {v4, v2}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Date;->getTime()J
    :try_end_69
    .catch Ljava/text/ParseException; {:try_start_60 .. :try_end_69} :catch_aa
    .catchall {:try_start_60 .. :try_end_69} :catchall_a1

    move-result-wide v0

    :cond_6a
    :goto_6a
    sget-object v2, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    const-string v4, "EEE, dd MMM yyyy HH:mm:ss z"

    invoke-virtual {v2, v4}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V

    goto :goto_1f

    :cond_72
    :try_start_72
    aget-object v8, v6, v4
    :try_end_74
    .catchall {:try_start_72 .. :try_end_74} :catchall_a1

    :try_start_74
    sget-object v9, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    invoke-virtual {v9, v8}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V

    sget-object v9, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    invoke-virtual {v9, v5}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "parsed w/ "

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    sget-object v8, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    const-string v9, "EEE, dd MMM yyyy HH:mm:ss z"

    invoke-virtual {v8, v9}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V
    :try_end_98
    .catch Ljava/text/ParseException; {:try_start_74 .. :try_end_98} :catch_9a
    .catchall {:try_start_74 .. :try_end_98} :catchall_a1

    const/4 v2, 0x1

    goto :goto_3a

    :catch_9a
    move-exception v8

    :try_start_9b
    invoke-virtual {v2}, Ljava/text/ParseException;->getMessage()Ljava/lang/String;
    :try_end_9e
    .catchall {:try_start_9b .. :try_end_9e} :catchall_a1

    add-int/lit8 v4, v4, 0x1

    goto :goto_37

    :catchall_a1
    move-exception v0

    sget-object v1, Lait/podka/b/c;->b:Ljava/text/SimpleDateFormat;

    const-string v2, "EEE, dd MMM yyyy HH:mm:ss z"

    invoke-virtual {v1, v2}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V

    throw v0

    :catch_aa
    move-exception v2

    goto :goto_6a
.end method


# virtual methods
.method final a(Lait/podka/b/d;)J
    .registers 11

    const-wide/16 v0, -0x1

    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const-string v2, "ch_title"

    iget-object v4, p1, Lait/podka/b/d;->e:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_description"

    iget-object v4, p1, Lait/podka/b/d;->d:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_feedlink"

    iget-object v4, p1, Lait/podka/b/d;->f:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_weblink"

    iget-object v4, p1, Lait/podka/b/d;->g:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_imageurl"

    iget-object v4, p1, Lait/podka/b/d;->c:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_lastmodified"

    iget-wide v4, p1, Lait/podka/b/d;->i:J

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string v2, "ch_category"

    iget-object v4, p1, Lait/podka/b/d;->b:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_etag"

    iget-object v4, p1, Lait/podka/b/d;->h:Ljava/lang/String;

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ch_ignorecache"

    const/4 v4, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    :try_start_4d
    iget-object v2, p0, Lait/podka/b/c;->a:Landroid/content/ContentResolver;

    sget-object v4, Lait/podka/database/d;->a:Landroid/net/Uri;

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_4d .. :try_end_54} :catch_7f
    .catchall {:try_start_4d .. :try_end_54} :catchall_87

    move-result-object v2

    if-nez v2, :cond_5b

    invoke-virtual {v3}, Landroid/content/ContentValues;->clear()V

    :goto_5a
    return-wide v0

    :cond_5b
    :try_start_5b
    iget-object v4, p0, Lait/podka/b/c;->c:Lait/podka/b/b;

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "Adding "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v8, p1, Lait/podka/b/d;->e:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v6, v7}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v5

    invoke-virtual {v4, v5}, Lait/podka/b/b;->notifyObservers(Ljava/lang/Object;)V

    invoke-static {v2}, Landroid/content/ContentUris;->parseId(Landroid/net/Uri;)J
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_5b .. :try_end_7a} :catch_7f
    .catchall {:try_start_5b .. :try_end_7a} :catchall_87

    move-result-wide v0

    invoke-virtual {v3}, Landroid/content/ContentValues;->clear()V

    goto :goto_5a

    :catch_7f
    move-exception v2

    :try_start_80
    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_83
    .catchall {:try_start_80 .. :try_end_83} :catchall_87

    invoke-virtual {v3}, Landroid/content/ContentValues;->clear()V

    goto :goto_5a

    :catchall_87
    move-exception v0

    invoke-virtual {v3}, Landroid/content/ContentValues;->clear()V

    throw v0
.end method

.method abstract a(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
.end method

.method abstract b(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
.end method

.method protected final c(Ljava/lang/String;)Ljava/util/Date;
    .registers 8

    const/4 v4, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    new-instance v3, Ljava/text/ParsePosition;

    invoke-direct {v3, v4}, Ljava/text/ParsePosition;-><init>(I)V

    iget-object v0, p0, Lait/podka/b/c;->f:[Ljava/text/DateFormat;

    aget-object v0, v0, v4

    invoke-virtual {v0, p1, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;Ljava/text/ParsePosition;)Ljava/util/Date;

    move-result-object v0

    if-eqz v0, :cond_1d

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v4

    cmp-long v4, v4, v1

    if-gez v4, :cond_1d

    :cond_1c
    :goto_1c
    return-object v0

    :cond_1d
    iget-object v0, p0, Lait/podka/b/c;->f:[Ljava/text/DateFormat;

    const/4 v4, 0x1

    aget-object v0, v0, v4

    invoke-virtual {v0, p1, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;Ljava/text/ParsePosition;)Ljava/util/Date;

    move-result-object v0

    if-eqz v0, :cond_30

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v4

    cmp-long v4, v4, v1

    if-ltz v4, :cond_1c

    :cond_30
    iget-object v0, p0, Lait/podka/b/c;->f:[Ljava/text/DateFormat;

    const/4 v4, 0x2

    aget-object v0, v0, v4

    invoke-virtual {v0, p1, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;Ljava/text/ParsePosition;)Ljava/util/Date;

    move-result-object v0

    if-eqz v0, :cond_43

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v4

    cmp-long v4, v4, v1

    if-ltz v4, :cond_1c

    :cond_43
    iget-object v0, p0, Lait/podka/b/c;->f:[Ljava/text/DateFormat;

    const/4 v4, 0x3

    aget-object v0, v0, v4

    invoke-virtual {v0, p1, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;Ljava/text/ParsePosition;)Ljava/util/Date;

    move-result-object v0

    if-eqz v0, :cond_56

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v3

    cmp-long v1, v3, v1

    if-ltz v1, :cond_1c

    :cond_56
    new-instance v0, Ljava/util/Date;

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    const-wide/16 v1, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/Date;->setTime(J)V

    goto :goto_1c
.end method

.method public final c(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    .registers 9

    :try_start_0
    invoke-virtual {p0, p1, p2}, Lait/podka/b/c;->a(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_3} :catch_3d
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_3} :catch_3f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_3} :catch_41

    :try_start_3
    invoke-virtual {p0, p1, p2}, Lait/podka/b/c;->b(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_6} :catch_7
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_6} :catch_3d
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_3 .. :try_end_6} :catch_3f

    :goto_6
    return-void

    :catch_7
    move-exception v0

    :try_start_8
    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const-string v2, "ch_ignorecache"

    const/4 v3, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    iget-object v2, p0, Lait/podka/b/c;->a:Landroid/content/ContentResolver;

    sget-object v3, Lait/podka/database/d;->a:Landroid/net/Uri;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "ch_feedlink = \'"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, p2, Lait/podka/b/d;->f:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "\'"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v1, v4, v5}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    iget-object v1, p2, Lait/podka/b/d;->e:Ljava/lang/String;

    throw v0
    :try_end_3d
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_3d} :catch_3d
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_8 .. :try_end_3d} :catch_3f
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_3d} :catch_41

    :catch_3d
    move-exception v0

    throw v0

    :catch_3f
    move-exception v0

    throw v0

    :catch_41
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_6
.end method
