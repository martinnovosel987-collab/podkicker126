###### Class ait.podka.b.f (ait.podka.b.f)
.class public final Lait/podka/b/f;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field final synthetic d:Lait/podka/b/e;


# direct methods
.method public constructor <init>(Lait/podka/b/e;)V
    .registers 2

    iput-object p1, p0, Lait/podka/b/f;->d:Lait/podka/b/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
