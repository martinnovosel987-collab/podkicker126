###### Class ait.podka.b.g (ait.podka.b.g)
.class public final Lait/podka/b/g;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lorg/xmlpull/v1/XmlPullParser;)Lait/podka/b/h;
    .registers 7

    const/4 v5, 0x0

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v1

    const/4 v0, 0x0

    :goto_6
    const/4 v2, 0x1

    if-ne v1, v2, :cond_c

    :cond_9
    sget-object v0, Lait/podka/b/h;->e:Lait/podka/b/h;

    :goto_b
    return-object v0

    :cond_c
    add-int/lit8 v0, v0, 0x1

    const/16 v2, 0x64

    if-eq v0, v2, :cond_9

    const/4 v2, 0x2

    if-ne v1, v2, :cond_9c

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "rss"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_44

    const-string v2, "version"

    invoke-interface {p0, v5, v2}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_41

    const-string v3, "2.0"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_41

    const-string v3, "0.91"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_41

    const-string v3, "0.92"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9c

    :cond_41
    sget-object v0, Lait/podka/b/h;->d:Lait/podka/b/h;

    goto :goto_b

    :cond_44
    const-string v3, "rdf"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_65

    const-string v3, "rdf"

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlPullParser;->getNamespace(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_65

    const-string v3, "rdf"

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlPullParser;->getNamespace(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "http://www.w3.org/1999/02/22-rdf-syntax-ns#"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_65

    sget-object v0, Lait/podka/b/h;->c:Lait/podka/b/h;

    goto :goto_b

    :cond_65
    const-string v3, "feed"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_9c

    const-string v3, "version"

    invoke-interface {p0, v5, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_85

    const-string v4, "1.0"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_85

    const-string v4, "http://www.w3.org/2005/Atom"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_88

    :cond_85
    sget-object v0, Lait/podka/b/h;->a:Lait/podka/b/h;

    goto :goto_b

    :cond_88
    const-string v4, "0.3"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_98

    const-string v3, "http://purl.org/atom/ns#"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_9c

    :cond_98
    sget-object v0, Lait/podka/b/h;->b:Lait/podka/b/h;

    goto/16 :goto_b

    :cond_9c
    :try_start_9c
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    :try_end_9f
    .catch Ljava/lang/Exception; {:try_start_9c .. :try_end_9f} :catch_a2

    move-result v1

    goto/16 :goto_6

    :catch_a2
    move-exception v2

    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    goto/16 :goto_6
.end method
