###### Class ait.podka.b.i (ait.podka.b.i)
.class public final Lait/podka/b/i;
.super Ljava/lang/Object;


# instance fields
.field public final a:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lait/podka/b/i;->a:Landroid/content/Context;

    return-void
.end method

.method public static a(Ljava/io/File;)Ljava/util/Map;
    .registers 2

    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-static {v0}, Lait/podka/b/i;->a(Ljava/io/InputStream;)Ljava/util/Map;
    :try_end_8
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_8} :catch_a

    move-result-object v0

    :goto_9
    return-object v0

    :catch_a
    move-exception v0

    invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V

    const/4 v0, 0x0

    goto :goto_9
.end method

.method private static a(Ljava/io/InputStream;)Ljava/util/Map;
    .registers 6

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    :try_start_5
    invoke-static {}, Landroid/util/Xml;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;

    move-result-object v2

    const/4 v1, 0x0

    invoke-interface {v2, p0, v1}, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I
    :try_end_10
    .catch Ljava/io/FileNotFoundException; {:try_start_5 .. :try_end_10} :catch_4e
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_5 .. :try_end_10} :catch_5d
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_10} :catch_6c
    .catchall {:try_start_5 .. :try_end_10} :catchall_7b

    move-result v1

    :goto_11
    const/4 v3, 0x1

    if-ne v1, v3, :cond_1a

    if-eqz p0, :cond_19

    :try_start_16
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_19
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_19} :catch_49

    :cond_19
    :goto_19
    return-object v0

    :cond_1a
    const/4 v3, 0x2

    if-ne v1, v3, :cond_44

    :try_start_1d
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v3, "outline"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_44

    const/4 v1, 0x0

    const-string v3, "xmlUrl"

    invoke-interface {v2, v1, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v1, 0x0

    const-string v4, "text"

    invoke-interface {v2, v1, v4}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_3b

    const-string v1, ""

    :cond_3b
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_44

    invoke-interface {v0, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_44
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    :try_end_47
    .catch Ljava/io/FileNotFoundException; {:try_start_1d .. :try_end_47} :catch_4e
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_1d .. :try_end_47} :catch_5d
    .catch Ljava/io/IOException; {:try_start_1d .. :try_end_47} :catch_6c
    .catchall {:try_start_1d .. :try_end_47} :catchall_7b

    move-result v1

    goto :goto_11

    :catch_49
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_19

    :catch_4e
    move-exception v1

    :try_start_4f
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V
    :try_end_52
    .catchall {:try_start_4f .. :try_end_52} :catchall_7b

    if-eqz p0, :cond_19

    :try_start_54
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_57
    .catch Ljava/io/IOException; {:try_start_54 .. :try_end_57} :catch_58

    goto :goto_19

    :catch_58
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_19

    :catch_5d
    move-exception v1

    :try_start_5e
    invoke-virtual {v1}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V
    :try_end_61
    .catchall {:try_start_5e .. :try_end_61} :catchall_7b

    if-eqz p0, :cond_19

    :try_start_63
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_66
    .catch Ljava/io/IOException; {:try_start_63 .. :try_end_66} :catch_67

    goto :goto_19

    :catch_67
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_19

    :catch_6c
    move-exception v1

    :try_start_6d
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    :try_end_70
    .catchall {:try_start_6d .. :try_end_70} :catchall_7b

    if-eqz p0, :cond_19

    :try_start_72
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_75
    .catch Ljava/io/IOException; {:try_start_72 .. :try_end_75} :catch_76

    goto :goto_19

    :catch_76
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_19

    :catchall_7b
    move-exception v0

    if-eqz p0, :cond_81

    :try_start_7e
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_81
    .catch Ljava/io/IOException; {:try_start_7e .. :try_end_81} :catch_82

    :cond_81
    :goto_81
    throw v0

    :catch_82
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_81
.end method
