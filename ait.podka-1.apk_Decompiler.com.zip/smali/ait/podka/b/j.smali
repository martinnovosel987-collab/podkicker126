###### Class ait.podka.b.j (ait.podka.b.j)
.class public final Lait/podka/b/j;
.super Lait/podka/b/c;


# direct methods
.method public constructor <init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lait/podka/b/c;-><init>(Lait/podka/b/b;Landroid/content/ContentResolver;)V

    return-void
.end method


# virtual methods
.method final a(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    .registers 3

    return-void
.end method

.method final b(Lorg/xmlpull/v1/XmlPullParser;Lait/podka/b/d;)V
    .registers 3

    return-void
.end method
