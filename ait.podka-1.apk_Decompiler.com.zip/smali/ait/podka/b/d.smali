###### Class ait.podka.b.d (ait.podka.b.d)
.class public final Lait/podka/b/d;
.super Ljava/lang/Object;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:J
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public j:I

.field public k:Z


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->b:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->c:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->d:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->e:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->f:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->g:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lait/podka/b/d;->h:Ljava/lang/String;

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lait/podka/b/d;->i:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/b/d;->k:Z

    return-void
.end method
