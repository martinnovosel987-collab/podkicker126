###### Class ait.podka.o (ait.podka.o)
.class final Lait/podka/o;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# instance fields
.field final synthetic a:Lait/podka/Podka;


# direct methods
.method constructor <init>(Lait/podka/Podka;)V
    .registers 2

    iput-object p1, p0, Lait/podka/o;->a:Lait/podka/Podka;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel(Landroid/content/DialogInterface;)V
    .registers 3

    iget-object v0, p0, Lait/podka/o;->a:Lait/podka/Podka;

    invoke-virtual {v0}, Lait/podka/Podka;->finish()V

    return-void
.end method
