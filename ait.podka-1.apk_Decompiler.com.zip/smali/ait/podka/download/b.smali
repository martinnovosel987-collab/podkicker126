###### Class ait.podka.download.b (ait.podka.download.b)
.class final Lait/podka/download/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/download/DownloadService;


# direct methods
.method constructor <init>(Lait/podka/download/DownloadService;)V
    .registers 2

    iput-object p1, p0, Lait/podka/download/b;->a:Lait/podka/download/DownloadService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/download/b;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->a(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ConcurrentLinkedQueue;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->size()I

    move-result v0

    if-nez v0, :cond_18

    iget-object v0, p0, Lait/podka/download/b;->a:Lait/podka/download/DownloadService;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lait/podka/download/DownloadService;->stopForeground(Z)V

    iget-object v0, p0, Lait/podka/download/b;->a:Lait/podka/download/DownloadService;

    invoke-virtual {v0}, Lait/podka/download/DownloadService;->stopSelf()V

    :goto_17
    return-void

    :cond_18
    iget-object v0, p0, Lait/podka/download/b;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->b(Lait/podka/download/DownloadService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x1388

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_17
.end method
