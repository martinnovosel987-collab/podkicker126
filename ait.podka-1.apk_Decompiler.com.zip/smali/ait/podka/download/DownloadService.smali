###### Class ait.podka.download.DownloadService (ait.podka.download.DownloadService)
.class public Lait/podka/download/DownloadService;
.super Landroid/app/Service;


# instance fields
.field private final a:I

.field private volatile b:Landroid/os/Handler;

.field private volatile c:Landroid/os/Looper;

.field private d:Ljava/util/concurrent/ExecutorService;

.field private e:Ljava/util/concurrent/ConcurrentLinkedQueue;

.field private final f:I

.field private g:Landroid/app/Notification;

.field private final h:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v0, 0x2

    iput v0, p0, Lait/podka/download/DownloadService;->a:I

    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    iput-object v0, p0, Lait/podka/download/DownloadService;->e:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/16 v0, 0x5135

    iput v0, p0, Lait/podka/download/DownloadService;->f:I

    new-instance v0, Lait/podka/download/b;

    invoke-direct {v0, p0}, Lait/podka/download/b;-><init>(Lait/podka/download/DownloadService;)V

    iput-object v0, p0, Lait/podka/download/DownloadService;->h:Ljava/lang/Runnable;

    return-void
.end method

.method static synthetic a(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ConcurrentLinkedQueue;
    .registers 2

    iget-object v0, p0, Lait/podka/download/DownloadService;->e:Ljava/util/concurrent/ConcurrentLinkedQueue;

    return-object v0
.end method

.method static synthetic b(Lait/podka/download/DownloadService;)Landroid/os/Handler;
    .registers 2

    iget-object v0, p0, Lait/podka/download/DownloadService;->b:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic c(Lait/podka/download/DownloadService;)Landroid/app/Notification;
    .registers 2

    iget-object v0, p0, Lait/podka/download/DownloadService;->g:Landroid/app/Notification;

    return-object v0
.end method

.method static synthetic d(Lait/podka/download/DownloadService;)Ljava/lang/Runnable;
    .registers 2

    iget-object v0, p0, Lait/podka/download/DownloadService;->h:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic e(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ExecutorService;
    .registers 2

    iget-object v0, p0, Lait/podka/download/DownloadService;->d:Ljava/util/concurrent/ExecutorService;

    return-object v0
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3

    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()V
    .registers 7

    const/4 v5, 0x0

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    new-instance v0, Landroid/app/Notification;

    const v1, 0x1080081

    const-string v2, "Downloading"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/app/Notification;-><init>(ILjava/lang/CharSequence;J)V

    iput-object v0, p0, Lait/podka/download/DownloadService;->g:Landroid/app/Notification;

    iget-object v0, p0, Lait/podka/download/DownloadService;->g:Landroid/app/Notification;

    iget v1, v0, Landroid/app/Notification;->flags:I

    or-int/lit8 v1, v1, 0x2

    iput v1, v0, Landroid/app/Notification;->flags:I

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lait/podka/Podka;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {p0, v5, v0, v5}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iget-object v1, p0, Lait/podka/download/DownloadService;->g:Landroid/app/Notification;

    const-string v2, "Podkicker"

    const-string v3, "Downloading..."

    invoke-virtual {v1, p0, v2, v3, v0}, Landroid/app/Notification;->setLatestEventInfo(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "d-service"

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    iput-object v0, p0, Lait/podka/download/DownloadService;->c:Landroid/os/Looper;

    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lait/podka/download/DownloadService;->c:Landroid/os/Looper;

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lait/podka/download/DownloadService;->b:Landroid/os/Handler;

    const/4 v0, 0x2

    new-instance v1, Lait/podka/download/c;

    invoke-direct {v1, p0}, Lait/podka/download/c;-><init>(Lait/podka/download/DownloadService;)V

    invoke-static {v0, v1}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lait/podka/download/DownloadService;->d:Ljava/util/concurrent/ExecutorService;

    iget-object v0, p0, Lait/podka/download/DownloadService;->b:Landroid/os/Handler;

    new-instance v1, Lait/podka/download/e;

    invoke-virtual {p0}, Lait/podka/download/DownloadService;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Lait/podka/download/e;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onDestroy()V
    .registers 2

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    iget-object v0, p0, Lait/podka/download/DownloadService;->d:Ljava/util/concurrent/ExecutorService;

    if-eqz v0, :cond_c

    iget-object v0, p0, Lait/podka/download/DownloadService;->d:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    :cond_c
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lait/podka/download/DownloadService;->stopForeground(Z)V

    iget-object v0, p0, Lait/podka/download/DownloadService;->c:Landroid/os/Looper;

    invoke-virtual {v0}, Landroid/os/Looper;->quit()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 9

    if-eqz p1, :cond_22

    const-string v0, "action"

    const/4 v1, -0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "id"

    const-wide/16 v2, -0x1

    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v3, 0x1

    if-ne v0, v3, :cond_22

    invoke-virtual {p0}, Lait/podka/download/DownloadService;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v3, p0, Lait/podka/download/DownloadService;->b:Landroid/os/Handler;

    new-instance v4, Lait/podka/download/d;

    invoke-direct {v4, p0, v1, v2, v0}, Lait/podka/download/d;-><init>(Lait/podka/download/DownloadService;JLandroid/content/ContentResolver;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_22
    const/4 v0, 0x2

    return v0
.end method
