###### Class ait.podka.download.e (ait.podka.download.e)
.class public final Lait/podka/download/e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private a:Landroid/content/ContentResolver;

.field private b:Ljava/io/File;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iput-object v0, p0, Lait/podka/download/e;->a:Landroid/content/ContentResolver;

    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "/Android/data/"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/cache/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/download/e;->b:Ljava/io/File;

    iget-object v0, p0, Lait/podka/download/e;->b:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 14

    const/4 v4, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Lait/podka/download/e;->a:Landroid/content/ContentResolver;

    sget-object v1, Lait/podka/database/e;->a:Landroid/net/Uri;

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "enc_filename"

    aput-object v3, v2, v6

    const/4 v3, 0x1

    const-string v5, "enc_dlt"

    aput-object v5, v2, v3

    const-string v3, "enc_dlt IS NOT NULL AND enc_dlt != \'\'"

    move-object v5, v4

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    :goto_1e
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-nez v2, :cond_41

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    iget-object v0, p0, Lait/podka/download/e;->b:Ljava/io/File;

    new-instance v2, Lait/podka/download/f;

    invoke-direct {v2, p0}, Lait/podka/download/f;-><init>(Lait/podka/download/e;)V

    invoke-virtual {v0, v2}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object v2

    if-eqz v2, :cond_38

    array-length v3, v2

    move v0, v6

    :goto_36
    if-lt v0, v3, :cond_49

    :cond_38
    sget-object v0, Lait/podka/Podka;->g:Ljava/io/File;

    if-eqz v0, :cond_40

    sget-object v0, Lait/podka/Podka;->f:Ljava/io/File;

    if-nez v0, :cond_64

    :cond_40
    return-void

    :cond_41
    invoke-interface {v0, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    :cond_49
    aget-object v4, v2, v0

    invoke-virtual {v4}, Ljava/io/File;->lastModified()J

    move-result-wide v7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    const-wide/32 v11, 0x240c8400

    sub-long/2addr v9, v11

    cmp-long v5, v7, v9

    if-gez v5, :cond_61

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    :cond_61
    add-int/lit8 v0, v0, 0x1

    goto :goto_36

    :cond_64
    sget-object v0, Lait/podka/Podka;->g:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    sget-object v0, Lait/podka/Podka;->f:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v3

    if-eqz v2, :cond_76

    array-length v4, v2

    move v0, v6

    :goto_74
    if-lt v0, v4, :cond_8e

    :cond_76
    if-eqz v3, :cond_40

    array-length v2, v3

    move v0, v6

    :goto_7a
    if-ge v0, v2, :cond_40

    aget-object v4, v3, v0

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_8b

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    :cond_8b
    add-int/lit8 v0, v0, 0x1

    goto :goto_7a

    :cond_8e
    aget-object v5, v2, v0

    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_9d

    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    :cond_9d
    add-int/lit8 v0, v0, 0x1

    goto :goto_74
.end method
