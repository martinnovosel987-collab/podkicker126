###### Class ait.podka.download.d (ait.podka.download.d)
.class final Lait/podka/download/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/download/DownloadService;

.field private final synthetic b:J

.field private final synthetic c:Landroid/content/ContentResolver;


# direct methods
.method constructor <init>(Lait/podka/download/DownloadService;JLandroid/content/ContentResolver;)V
    .registers 5

    iput-object p1, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    iput-wide p2, p0, Lait/podka/download/d;->b:J

    iput-object p4, p0, Lait/podka/download/d;->c:Landroid/content/ContentResolver;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 14

    const/4 v12, 0x1

    const/4 v11, 0x0

    iget-wide v0, p0, Lait/podka/download/d;->b:J

    iget-object v2, p0, Lait/podka/download/d;->c:Landroid/content/ContentResolver;

    invoke-static {v0, v1, v2}, Lait/podka/database/a;->a(JLandroid/content/ContentResolver;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_e
    :goto_e
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_2a

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v0

    if-gtz v0, :cond_29

    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-virtual {v0}, Lait/podka/download/DownloadService;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Nothing to download"

    invoke-static {v0, v1, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_29
    return-void

    :cond_2a
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    aget-object v1, v0, v11

    aget-object v2, v0, v12

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/io/File;

    sget-object v4, Lait/podka/Podka;->g:Ljava/io/File;

    invoke-direct {v3, v4, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v0

    iget-object v3, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v3}, Lait/podka/download/DownloadService;->a(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ConcurrentLinkedQueue;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e2

    if-nez v0, :cond_e2

    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->a(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ConcurrentLinkedQueue;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    const/16 v3, 0x5135

    iget-object v4, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v4}, Lait/podka/download/DownloadService;->c(Lait/podka/download/DownloadService;)Landroid/app/Notification;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Lait/podka/download/DownloadService;->startForeground(ILandroid/app/Notification;)V

    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->b(Lait/podka/download/DownloadService;)Landroid/os/Handler;

    move-result-object v0

    iget-object v3, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v3}, Lait/podka/download/DownloadService;->d(Lait/podka/download/DownloadService;)Ljava/lang/Runnable;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->b(Lait/podka/download/DownloadService;)Landroid/os/Handler;

    move-result-object v0

    iget-object v3, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v3}, Lait/podka/download/DownloadService;->d(Lait/podka/download/DownloadService;)Ljava/lang/Runnable;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    invoke-static {v2}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    iget-object v0, p0, Lait/podka/download/d;->c:Landroid/content/ContentResolver;

    new-instance v5, Landroid/content/ContentValues;

    invoke-direct {v5}, Landroid/content/ContentValues;-><init>()V

    const-string v8, "enc_dlt"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-virtual {v5, v8, v9}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string v8, "enc_err"

    invoke-virtual {v5, v8}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    const-string v8, "enc_queue"

    invoke-virtual {v5, v8}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    sget-object v8, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v9, "_id = ?"

    new-array v10, v12, [Ljava/lang/String;

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v10, v11

    invoke-virtual {v0, v8, v5, v9, v10}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->e(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ExecutorService;

    move-result-object v8

    new-instance v0, Lait/podka/download/a;

    invoke-static {v2}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    iget-object v4, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v4}, Lait/podka/download/DownloadService;->a(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ConcurrentLinkedQueue;

    move-result-object v4

    iget-object v5, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-virtual {v5}, Lait/podka/download/DownloadService;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct/range {v0 .. v5}, Lait/podka/download/a;-><init>(Ljava/lang/String;JLjava/util/concurrent/ConcurrentLinkedQueue;Landroid/content/Context;)V

    invoke-interface {v8, v0}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    goto/16 :goto_e

    :cond_e2
    iget-object v0, p0, Lait/podka/download/d;->a:Lait/podka/download/DownloadService;

    invoke-static {v0}, Lait/podka/download/DownloadService;->a(Lait/podka/download/DownloadService;)Ljava/util/concurrent/ConcurrentLinkedQueue;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    sput v0, Lait/podka/download/a;->b:I

    goto/16 :goto_e
.end method
