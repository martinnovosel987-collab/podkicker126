###### Class ait.podka.download.a (ait.podka.download.a)
.class public final Lait/podka/download/a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static volatile a:Z

.field public static volatile b:I


# instance fields
.field private volatile c:J

.field private d:J

.field private volatile e:I

.field private final f:Ljava/lang/String;

.field private g:J

.field private h:Ljava/io/BufferedInputStream;

.field private i:Ljava/io/BufferedOutputStream;

.field private j:I

.field private k:Landroid/content/Context;

.field private l:Ljava/util/concurrent/ConcurrentLinkedQueue;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    sput-boolean v0, Lait/podka/download/a;->a:Z

    sput v0, Lait/podka/download/a;->b:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;JLjava/util/concurrent/ConcurrentLinkedQueue;Landroid/content/Context;)V
    .registers 9

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lait/podka/download/a;->c:J

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lait/podka/download/a;->d:J

    iput-object v2, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    iput-object v2, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    iput-object p1, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    iget-object v0, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    iput v0, p0, Lait/podka/download/a;->j:I

    iput-object p5, p0, Lait/podka/download/a;->k:Landroid/content/Context;

    iput-wide p2, p0, Lait/podka/download/a;->g:J

    iput-object p4, p0, Lait/podka/download/a;->l:Ljava/util/concurrent/ConcurrentLinkedQueue;

    new-instance v0, Ljava/io/File;

    sget-object v1, Lait/podka/Podka;->f:Ljava/io/File;

    iget v2, p0, Lait/podka/download/a;->j:I

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v0

    iput-wide v0, p0, Lait/podka/download/a;->c:J

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .registers 9

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_8

    const-string p1, "Error"

    :cond_8
    iget-wide v0, p0, Lait/podka/download/a;->g:J

    iget-object v2, p0, Lait/podka/download/a;->k:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const-string v4, "enc_err"

    invoke-virtual {v3, v4, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v4, Lait/podka/database/e;->a:Landroid/net/Uri;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "_id = "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v2, v4, v3, v0, v1}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 16

    const-wide/16 v9, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v14, 0x2

    sget-boolean v0, Lait/podka/download/a;->a:Z

    if-eqz v0, :cond_c

    iput v14, p0, Lait/podka/download/a;->e:I

    :cond_b
    :goto_b
    return-void

    :cond_c
    iput v11, p0, Lait/podka/download/a;->e:I

    const/4 v8, 0x0

    :try_start_f
    new-instance v0, Lorg/apache/http/params/BasicHttpParams;

    invoke-direct {v0}, Lorg/apache/http/params/BasicHttpParams;-><init>()V

    const/16 v1, 0x4e20

    invoke-static {v0, v1}, Lorg/apache/http/params/HttpConnectionParams;->setConnectionTimeout(Lorg/apache/http/params/HttpParams;I)V

    const v1, 0x124f8

    invoke-static {v0, v1}, Lorg/apache/http/params/HttpConnectionParams;->setSoTimeout(Lorg/apache/http/params/HttpParams;I)V

    new-instance v13, Lorg/apache/http/impl/client/DefaultHttpClient;

    invoke-direct {v13, v0}, Lorg/apache/http/impl/client/DefaultHttpClient;-><init>(Lorg/apache/http/params/HttpParams;)V

    iget-object v0, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    const-string v1, "UTF-8"

    invoke-static {v0, v1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v7, Ljava/net/URL;

    invoke-direct {v7, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    new-instance v0, Ljava/net/URI;

    invoke-virtual {v7}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7}, Ljava/net/URL;->getUserInfo()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7}, Ljava/net/URL;->getPort()I

    move-result v4

    invoke-virtual {v7}, Ljava/net/URL;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7}, Ljava/net/URL;->getQuery()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7}, Ljava/net/URL;->getRef()Ljava/lang/String;

    move-result-object v7

    invoke-direct/range {v0 .. v7}, Ljava/net/URI;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Lorg/apache/http/client/methods/HttpGet;

    invoke-direct {v1, v0}, Lorg/apache/http/client/methods/HttpGet;-><init>(Ljava/net/URI;)V
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_57} :catch_253
    .catchall {:try_start_f .. :try_end_57} :catchall_250

    :try_start_57
    invoke-virtual {v0}, Ljava/net/URI;->toString()Ljava/lang/String;

    iget-wide v2, p0, Lait/podka/download/a;->c:J

    cmp-long v0, v2, v9

    if-lez v0, :cond_81

    new-instance v0, Lorg/apache/http/message/BasicHeader;

    const-string v2, "Range"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "bytes="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v4, p0, Lait/podka/download/a;->c:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v2, v3}, Lorg/apache/http/message/BasicHeader;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Lorg/apache/http/Header;)V

    :cond_81
    new-instance v0, Lorg/apache/http/message/BasicHeader;

    const-string v2, "User-Agent"

    sget-object v3, Lait/podka/Podka;->d:Ljava/lang/String;

    invoke-direct {v0, v2, v3}, Lorg/apache/http/message/BasicHeader;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Lorg/apache/http/Header;)V

    new-instance v0, Lorg/apache/http/message/BasicHeader;

    const-string v2, "Accept-Encoding"

    const-string v3, "identity"

    invoke-direct {v0, v2, v3}, Lorg/apache/http/message/BasicHeader;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lorg/apache/http/client/methods/HttpGet;->setHeader(Lorg/apache/http/Header;)V

    invoke-interface {v13, v1}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;

    move-result-object v4

    invoke-interface {v4}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object v0

    invoke-interface {v0}, Lorg/apache/http/StatusLine;->getStatusCode()I

    move-result v0

    div-int/lit8 v2, v0, 0x64

    if-eq v2, v14, :cond_ef

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lorg/apache/http/impl/EnglishReasonPhraseCatalog;->INSTANCE:Lorg/apache/http/impl/EnglishReasonPhraseCatalog;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v4

    invoke-virtual {v3, v0, v4}, Lorg/apache/http/impl/EnglishReasonPhraseCatalog;->getReason(ILjava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lait/podka/download/a;->a(Ljava/lang/String;)V

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    :try_end_c6
    .catch Ljava/lang/Exception; {:try_start_57 .. :try_end_c6} :catch_1d6
    .catchall {:try_start_57 .. :try_end_c6} :catchall_21b

    iget-object v0, p0, Lait/podka/download/a;->l:Ljava/util/concurrent/ConcurrentLinkedQueue;

    iget-object v2, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Lorg/apache/http/client/methods/HttpGet;->abort()V

    iget-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    if-eqz v0, :cond_d9

    :try_start_d4
    iget-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->close()V
    :try_end_d9
    .catch Ljava/io/IOException; {:try_start_d4 .. :try_end_d9} :catch_ea

    :cond_d9
    :goto_d9
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    if-eqz v0, :cond_b

    :try_start_dd
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    invoke-virtual {v0}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_e2
    .catch Ljava/io/IOException; {:try_start_dd .. :try_end_e2} :catch_e4

    goto/16 :goto_b

    :catch_e4
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_b

    :catch_ea
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_d9

    :cond_ef
    const/16 v2, 0xce

    if-ne v0, v2, :cond_1b9

    move v0, v11

    :goto_f4
    if-nez v0, :cond_fa

    const-wide/16 v2, 0x0

    :try_start_f8
    iput-wide v2, p0, Lait/podka/download/a;->c:J

    :cond_fa
    const-string v2, "Content-Length"

    invoke-interface {v4, v2}, Lorg/apache/http/HttpResponse;->getFirstHeader(Ljava/lang/String;)Lorg/apache/http/Header;

    move-result-object v2

    if-eqz v2, :cond_256

    invoke-interface {v2}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    :goto_10a
    const-wide/16 v5, -0x1

    cmp-long v5, v2, v5

    if-nez v5, :cond_115

    const-string v5, "content-length < 1"

    invoke-direct {p0, v5}, Lait/podka/download/a;->a(Ljava/lang/String;)V

    :cond_115
    iget-wide v5, p0, Lait/podka/download/a;->c:J

    add-long/2addr v2, v5

    iput-wide v2, p0, Lait/podka/download/a;->d:J

    iget-wide v2, p0, Lait/podka/download/a;->g:J

    iget-wide v5, p0, Lait/podka/download/a;->d:J

    iget-object v7, p0, Lait/podka/download/a;->k:Landroid/content/Context;

    invoke-virtual {v7}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v7

    invoke-static {v2, v3, v5, v6, v7}, Lait/podka/database/a;->a(JJLandroid/content/ContentResolver;)V

    new-instance v2, Ljava/io/File;

    sget-object v3, Lait/podka/Podka;->f:Ljava/io/File;

    iget v5, p0, Lait/podka/download/a;->j:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-interface {v4}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    move-result-object v4

    invoke-interface {v4}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    move-result-object v4

    const/16 v5, 0x2000

    invoke-direct {v0, v4, v5}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;I)V

    iput-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    new-instance v0, Ljava/io/BufferedOutputStream;

    const/16 v4, 0x2000

    invoke-direct {v0, v3, v4}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;I)V

    iput-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    const/16 v0, 0x400

    new-array v0, v0, [B

    :goto_157
    iget v4, p0, Lait/podka/download/a;->e:I

    if-eq v4, v11, :cond_1bc

    :cond_15b
    :goto_15b
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    invoke-virtual {v0}, Ljava/io/BufferedOutputStream;->flush()V

    invoke-virtual {v3}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/FileDescriptor;->sync()V

    iget-wide v3, p0, Lait/podka/download/a;->g:J

    iget-wide v5, p0, Lait/podka/download/a;->d:J

    iget-object v0, p0, Lait/podka/download/a;->k:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-static {v3, v4, v5, v6, v0}, Lait/podka/database/a;->a(JJLandroid/content/ContentResolver;)V

    iget v0, p0, Lait/podka/download/a;->e:I

    if-ne v0, v11, :cond_18c

    new-instance v0, Ljava/io/File;

    sget-object v3, Lait/podka/Podka;->g:Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v0

    if-eqz v0, :cond_18c

    const/4 v0, 0x3

    iput v0, p0, Lait/podka/download/a;->e:I

    :cond_18c
    iget v0, p0, Lait/podka/download/a;->e:I

    if-ne v0, v14, :cond_195

    const-string v0, "Paused"

    invoke-direct {p0, v0}, Lait/podka/download/a;->a(Ljava/lang/String;)V
    :try_end_195
    .catch Ljava/lang/Exception; {:try_start_f8 .. :try_end_195} :catch_1d6
    .catchall {:try_start_f8 .. :try_end_195} :catchall_21b

    :cond_195
    iget-object v0, p0, Lait/podka/download/a;->l:Ljava/util/concurrent/ConcurrentLinkedQueue;

    iget-object v2, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Lorg/apache/http/client/methods/HttpGet;->abort()V

    iget-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    if-eqz v0, :cond_1a8

    :try_start_1a3
    iget-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->close()V
    :try_end_1a8
    .catch Ljava/io/IOException; {:try_start_1a3 .. :try_end_1a8} :catch_24a

    :cond_1a8
    :goto_1a8
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    if-eqz v0, :cond_b

    :try_start_1ac
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    invoke-virtual {v0}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_1b1
    .catch Ljava/io/IOException; {:try_start_1ac .. :try_end_1b1} :catch_1b3

    goto/16 :goto_b

    :catch_1b3
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_b

    :cond_1b9
    move v0, v12

    goto/16 :goto_f4

    :cond_1bc
    :try_start_1bc
    iget-object v4, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    invoke-virtual {v4, v0}, Ljava/io/BufferedInputStream;->read([B)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_15b

    sget-boolean v5, Lait/podka/download/a;->a:Z

    if-nez v5, :cond_1cf

    sget v5, Lait/podka/download/a;->b:I

    iget v6, p0, Lait/podka/download/a;->j:I

    if-ne v5, v6, :cond_20c

    :cond_1cf
    const/4 v0, 0x2

    iput v0, p0, Lait/podka/download/a;->e:I

    const/4 v0, 0x0

    sput v0, Lait/podka/download/a;->b:I
    :try_end_1d5
    .catch Ljava/lang/Exception; {:try_start_1bc .. :try_end_1d5} :catch_1d6
    .catchall {:try_start_1bc .. :try_end_1d5} :catchall_21b

    goto :goto_15b

    :catch_1d6
    move-exception v0

    :goto_1d7
    :try_start_1d7
    iget v2, p0, Lait/podka/download/a;->e:I

    if-eq v2, v14, :cond_1e3

    const-string v2, "Error"

    invoke-direct {p0, v2}, Lait/podka/download/a;->a(Ljava/lang/String;)V

    const/4 v2, 0x5

    iput v2, p0, Lait/podka/download/a;->e:I

    :cond_1e3
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_1e6
    .catchall {:try_start_1d7 .. :try_end_1e6} :catchall_21b

    iget-object v0, p0, Lait/podka/download/a;->l:Ljava/util/concurrent/ConcurrentLinkedQueue;

    iget-object v2, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->remove(Ljava/lang/Object;)Z

    if-eqz v1, :cond_1f2

    invoke-virtual {v1}, Lorg/apache/http/client/methods/HttpGet;->abort()V

    :cond_1f2
    iget-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    if-eqz v0, :cond_1fb

    :try_start_1f6
    iget-object v0, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->close()V
    :try_end_1fb
    .catch Ljava/io/IOException; {:try_start_1f6 .. :try_end_1fb} :catch_23b

    :cond_1fb
    :goto_1fb
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    if-eqz v0, :cond_b

    :try_start_1ff
    iget-object v0, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    invoke-virtual {v0}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_204
    .catch Ljava/io/IOException; {:try_start_1ff .. :try_end_204} :catch_206

    goto/16 :goto_b

    :catch_206
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_b

    :cond_20c
    :try_start_20c
    iget-object v5, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    const/4 v6, 0x0

    invoke-virtual {v5, v0, v6, v4}, Ljava/io/BufferedOutputStream;->write([BII)V

    iget-wide v5, p0, Lait/podka/download/a;->c:J

    int-to-long v7, v4

    add-long v4, v5, v7

    iput-wide v4, p0, Lait/podka/download/a;->c:J
    :try_end_219
    .catch Ljava/lang/Exception; {:try_start_20c .. :try_end_219} :catch_1d6
    .catchall {:try_start_20c .. :try_end_219} :catchall_21b

    goto/16 :goto_157

    :catchall_21b
    move-exception v0

    :goto_21c
    iget-object v2, p0, Lait/podka/download/a;->l:Ljava/util/concurrent/ConcurrentLinkedQueue;

    iget-object v3, p0, Lait/podka/download/a;->f:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentLinkedQueue;->remove(Ljava/lang/Object;)Z

    if-eqz v1, :cond_228

    invoke-virtual {v1}, Lorg/apache/http/client/methods/HttpGet;->abort()V

    :cond_228
    iget-object v1, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    if-eqz v1, :cond_231

    :try_start_22c
    iget-object v1, p0, Lait/podka/download/a;->h:Ljava/io/BufferedInputStream;

    invoke-virtual {v1}, Ljava/io/BufferedInputStream;->close()V
    :try_end_231
    .catch Ljava/io/IOException; {:try_start_22c .. :try_end_231} :catch_240

    :cond_231
    :goto_231
    iget-object v1, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    if-eqz v1, :cond_23a

    :try_start_235
    iget-object v1, p0, Lait/podka/download/a;->i:Ljava/io/BufferedOutputStream;

    invoke-virtual {v1}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_23a
    .catch Ljava/io/IOException; {:try_start_235 .. :try_end_23a} :catch_245

    :cond_23a
    :goto_23a
    throw v0

    :catch_23b
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_1fb

    :catch_240
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_231

    :catch_245
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_23a

    :catch_24a
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_1a8

    :catchall_250
    move-exception v0

    move-object v1, v8

    goto :goto_21c

    :catch_253
    move-exception v0

    move-object v1, v8

    goto :goto_1d7

    :cond_256
    move-wide v2, v9

    goto/16 :goto_10a
.end method
