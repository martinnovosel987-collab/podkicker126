###### Class ait.podka.services.AudioService (ait.podka.services.AudioService)
.class public Lait/podka/services/AudioService;
.super Landroid/app/Service;

# interfaces
.implements Landroid/media/MediaPlayer$OnBufferingUpdateListener;
.implements Landroid/media/MediaPlayer$OnCompletionListener;
.implements Landroid/media/MediaPlayer$OnErrorListener;
.implements Landroid/media/MediaPlayer$OnInfoListener;
.implements Landroid/media/MediaPlayer$OnPreparedListener;
.implements Landroid/widget/MediaController$MediaPlayerControl;


# static fields
.field public static volatile a:J


# instance fields
.field b:Landroid/telephony/PhoneStateListener;

.field private c:Landroid/os/Handler;

.field private d:Landroid/media/MediaPlayer;

.field private e:Landroid/content/BroadcastReceiver;

.field private f:Landroid/os/PowerManager$WakeLock;

.field private g:Landroid/app/NotificationManager;

.field private final h:I

.field private i:Landroid/app/Notification;

.field private volatile j:Ljava/lang/String;

.field private volatile k:Ljava/lang/String;

.field private volatile l:Ljava/lang/String;

.field private volatile m:I

.field private volatile n:Z

.field private volatile o:Z

.field private volatile p:Z

.field private volatile q:J

.field private final r:Landroid/os/IBinder;

.field private volatile s:Z


# direct methods
.method public constructor <init>()V
    .registers 3

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    new-instance v0, Lait/podka/services/d;

    invoke-direct {v0, p0, v1}, Lait/podka/services/d;-><init>(Lait/podka/services/AudioService;B)V

    iput-object v0, p0, Lait/podka/services/AudioService;->e:Landroid/content/BroadcastReceiver;

    const/16 v0, 0x392

    iput v0, p0, Lait/podka/services/AudioService;->h:I

    iput-boolean v1, p0, Lait/podka/services/AudioService;->n:Z

    iput-boolean v1, p0, Lait/podka/services/AudioService;->o:Z

    new-instance v0, Lait/podka/services/a;

    invoke-direct {v0, p0}, Lait/podka/services/a;-><init>(Lait/podka/services/AudioService;)V

    iput-object v0, p0, Lait/podka/services/AudioService;->b:Landroid/telephony/PhoneStateListener;

    new-instance v0, Lait/podka/services/c;

    invoke-direct {v0, p0}, Lait/podka/services/c;-><init>(Lait/podka/services/AudioService;)V

    iput-object v0, p0, Lait/podka/services/AudioService;->r:Landroid/os/IBinder;

    iput-boolean v1, p0, Lait/podka/services/AudioService;->s:Z

    return-void
.end method

.method private a(J)V
    .registers 13

    const/4 v2, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x0

    invoke-direct {p0}, Lait/podka/services/AudioService;->f()V

    iput-boolean v8, p0, Lait/podka/services/AudioService;->o:Z

    sput-wide p1, Lait/podka/services/AudioService;->a:J

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v3, "_id = ?"

    new-array v4, v9, [Ljava/lang/String;

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v8

    move-object v5, v2

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-nez v1, :cond_26

    :goto_25
    return-void

    :cond_26
    const-string v1, "enc_filename"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "enc_url"

    invoke-interface {v0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v2

    invoke-interface {v0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    new-instance v4, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "/Android/data/"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/files/podcasts/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v3, v4, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lait/podka/services/AudioService;->l:Ljava/lang/String;

    const-string v1, "enc_queue"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    iput-wide v4, p0, Lait/podka/services/AudioService;->q:J

    const-string v1, "ent_title"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lait/podka/services/AudioService;->j:Ljava/lang/String;

    const-string v1, "ch_title"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lait/podka/services/AudioService;->k:Ljava/lang/String;

    const-string v1, "enc_type"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v4, "video"

    invoke-virtual {v1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    iput-boolean v1, p0, Lait/podka/services/AudioService;->p:Z

    iput v8, p0, Lait/podka/services/AudioService;->m:I

    const-string v1, "enc_position"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    iget-boolean v0, p0, Lait/podka/services/AudioService;->p:Z

    if-eqz v0, :cond_db

    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lait/podka/video/VideoPlayer;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const-string v1, "enclosureID"

    invoke-virtual {v0, v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->startActivity(Landroid/content/Intent;)V

    const-string v0, ""

    iput-object v0, p0, Lait/podka/services/AudioService;->j:Ljava/lang/String;

    iput-object v0, p0, Lait/podka/services/AudioService;->l:Ljava/lang/String;

    iput-object v0, p0, Lait/podka/services/AudioService;->k:Ljava/lang/String;

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->reset()V

    goto/16 :goto_25

    :cond_db
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_102

    iput-object v2, p0, Lait/podka/services/AudioService;->l:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "\u2022 STREAM \u2022\n"

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lait/podka/services/AudioService;->j:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " / "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lait/podka/services/AudioService;->k:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lait/podka/services/AudioService;->j:Ljava/lang/String;

    :cond_102
    new-instance v0, Landroid/content/Intent;

    const-class v2, Lait/podka/Podka;

    invoke-direct {v0, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "redirect"

    invoke-virtual {v0, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const-string v2, "redirect_to"

    const/4 v3, 0x2

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    invoke-static {p0, v8, v0, v8}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iget-object v2, p0, Lait/podka/services/AudioService;->i:Landroid/app/Notification;

    iget-object v3, p0, Lait/podka/services/AudioService;->j:Ljava/lang/String;

    iget-object v4, p0, Lait/podka/services/AudioService;->k:Ljava/lang/String;

    invoke-virtual {v2, p0, v3, v4, v0}, Landroid/app/Notification;->setLatestEventInfo(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    :try_start_121
    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->reset()V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    iget-object v2, p0, Lait/podka/services/AudioService;->l:Ljava/lang/String;

    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->prepare()V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/16 v0, 0x392

    iget-object v1, p0, Lait/podka/services/AudioService;->i:Landroid/app/Notification;

    invoke-virtual {p0, v0, v1}, Lait/podka/services/AudioService;->startForeground(ILandroid/app/Notification;)V

    invoke-direct {p0}, Lait/podka/services/AudioService;->d()V
    :try_end_146
    .catch Ljava/lang/IllegalArgumentException; {:try_start_121 .. :try_end_146} :catch_148
    .catch Ljava/lang/IllegalStateException; {:try_start_121 .. :try_end_146} :catch_14e
    .catch Ljava/io/IOException; {:try_start_121 .. :try_end_146} :catch_154

    goto/16 :goto_25

    :catch_148
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    goto/16 :goto_25

    :catch_14e
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto/16 :goto_25

    :catch_154
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_25
.end method

.method static synthetic a(Lait/podka/services/AudioService;J)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lait/podka/services/AudioService;->a(J)V

    return-void
.end method

.method static synthetic a(Lait/podka/services/AudioService;)Z
    .registers 2

    iget-boolean v0, p0, Lait/podka/services/AudioService;->o:Z

    return v0
.end method

.method static synthetic b(Lait/podka/services/AudioService;)Landroid/media/MediaPlayer;
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    return-object v0
.end method

.method static synthetic b(Lait/podka/services/AudioService;J)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lait/podka/services/AudioService;->a(J)V

    return-void
.end method

.method static synthetic c(Lait/podka/services/AudioService;)Landroid/os/Handler;
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->c:Landroid/os/Handler;

    return-object v0
.end method

.method private d()V
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_11

    iget-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-nez v0, :cond_11

    iget-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->acquire()V

    :cond_11
    return-void
.end method

.method private e()V
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_11

    iget-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_11

    iget-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_11
    return-void
.end method

.method private f()V
    .registers 9

    const/4 v4, 0x0

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f080006

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f080007

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    iget-boolean v0, p0, Lait/podka/services/AudioService;->s:Z

    if-eqz v0, :cond_a1

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getDuration()I

    move-result v0

    :goto_2f
    int-to-long v3, v0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    long-to-float v0, v3

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getDuration()I

    move-result v5

    int-to-float v5, v5

    div-float/2addr v0, v5

    const/high16 v5, 0x42c80000    # 100.0f

    mul-float/2addr v0, v5

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    new-instance v5, Landroid/content/ContentValues;

    invoke-direct {v5}, Landroid/content/ContentValues;-><init>()V

    const-string v6, "enc_position"

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string v6, "enc_listened"

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/16 v6, 0x64

    if-ne v0, v6, :cond_7f

    if-eqz v1, :cond_7f

    const-string v1, "enc_queue"

    invoke-virtual {v5, v1}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    const-string v1, "enc_position"

    invoke-virtual {v5, v1}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    if-eqz v2, :cond_7f

    const-string v1, "enc_dlt"

    invoke-virtual {v5, v1}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lait/podka/services/AudioService;->l:Ljava/lang/String;

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    :cond_7f
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "_id = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-wide v1, Lait/podka/services/AudioService;->a:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v2, Lait/podka/database/e;->a:Landroid/net/Uri;

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v5, v0, v3}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    return-void

    :cond_a1
    invoke-virtual {p0}, Lait/podka/services/AudioService;->getCurrentPosition()I

    move-result v0

    goto :goto_2f
.end method


# virtual methods
.method public final a()V
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_10

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->reset()V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->stopForeground(Z)V

    invoke-direct {p0}, Lait/podka/services/AudioService;->e()V

    :cond_10
    return-void
.end method

.method public final b()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->j:Ljava/lang/String;

    return-object v0
.end method

.method public final c()Z
    .registers 2

    iget-boolean v0, p0, Lait/podka/services/AudioService;->n:Z

    return v0
.end method

.method public canPause()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public canSeekBackward()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public canSeekForward()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public getAudioSessionId()I
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getBufferPercentage()I
    .registers 2

    iget v0, p0, Lait/podka/services/AudioService;->m:I

    return v0
.end method

.method public getCurrentPosition()I
    .registers 3

    const/4 v0, 0x0

    iget-boolean v1, p0, Lait/podka/services/AudioService;->o:Z

    if-nez v1, :cond_6

    :cond_5
    :goto_5
    return v0

    :cond_6
    iget-object v1, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v1

    if-ltz v1, :cond_5

    move v0, v1

    goto :goto_5
.end method

.method public getDuration()I
    .registers 3

    const/4 v0, 0x0

    iget-boolean v1, p0, Lait/podka/services/AudioService;->o:Z

    if-nez v1, :cond_6

    :cond_5
    :goto_5
    return v0

    :cond_6
    iget-object v1, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v1

    if-ltz v1, :cond_5

    move v0, v1

    goto :goto_5
.end method

.method public isPlaying()Z
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v0

    return v0
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3

    iget-object v0, p0, Lait/podka/services/AudioService;->r:Landroid/os/IBinder;

    return-object v0
.end method

.method public onBufferingUpdate(Landroid/media/MediaPlayer;I)V
    .registers 3

    iput p2, p0, Lait/podka/services/AudioService;->m:I

    return-void
.end method

.method public onCompletion(Landroid/media/MediaPlayer;)V
    .registers 11

    const-wide/16 v6, -0x1

    const/4 v2, 0x0

    const/4 v8, 0x1

    iput-boolean v8, p0, Lait/podka/services/AudioService;->s:Z

    invoke-direct {p0}, Lait/podka/services/AudioService;->f()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/services/AudioService;->s:Z

    invoke-virtual {p0}, Lait/podka/services/AudioService;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v3, "enc_queue IS NOT NULL AND enc_queue != \'\'"

    const-string v5, "enc_queue ASC"

    move-object v4, v2

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    :cond_1b
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-nez v0, :cond_2d

    move-wide v0, v6

    :goto_22
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    cmp-long v2, v0, v6

    if-eqz v2, :cond_48

    invoke-direct {p0, v0, v1}, Lait/podka/services/AudioService;->a(J)V

    :goto_2c
    return-void

    :cond_2d
    const-string v0, "enc_queue"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    iget-wide v3, p0, Lait/podka/services/AudioService;->q:J

    cmp-long v0, v0, v3

    if-lez v0, :cond_1b

    const-string v0, "_id"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    goto :goto_22

    :cond_48
    invoke-virtual {p0, v8}, Lait/podka/services/AudioService;->stopForeground(Z)V

    invoke-direct {p0}, Lait/podka/services/AudioService;->e()V

    goto :goto_2c
.end method

.method public onCreate()V
    .registers 6

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "AudioService"

    const/16 v2, -0x10

    invoke-direct {v0, v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    new-instance v1, Lait/podka/services/b;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Lait/podka/services/b;-><init>(Lait/podka/services/AudioService;Landroid/os/Looper;)V

    iput-object v1, p0, Lait/podka/services/AudioService;->c:Landroid/os/Handler;

    new-instance v0, Landroid/media/MediaPlayer;

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    iput-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p0}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p0}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p0}, Landroid/media/MediaPlayer;->setOnInfoListener(Landroid/media/MediaPlayer$OnInfoListener;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p0}, Landroid/media/MediaPlayer;->setOnBufferingUpdateListener(Landroid/media/MediaPlayer$OnBufferingUpdateListener;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p0}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->e:Landroid/content/BroadcastReceiver;

    new-instance v1, Landroid/content/IntentFilter;

    const-string v2, "w003t"

    invoke-direct {v1, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0, v1}, Lait/podka/services/AudioService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    iput-object v0, p0, Lait/podka/services/AudioService;->g:Landroid/app/NotificationManager;

    new-instance v0, Landroid/app/Notification;

    const v1, 0x7f02000f

    const-string v2, "Podcast Playback"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/app/Notification;-><init>(ILjava/lang/CharSequence;J)V

    iput-object v0, p0, Lait/podka/services/AudioService;->i:Landroid/app/Notification;

    iget-object v0, p0, Lait/podka/services/AudioService;->i:Landroid/app/Notification;

    iget v1, v0, Landroid/app/Notification;->flags:I

    or-int/lit8 v1, v1, 0x2

    iput v1, v0, Landroid/app/Notification;->flags:I

    const-string v0, "power"

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    const/4 v1, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v0

    iput-object v0, p0, Lait/podka/services/AudioService;->f:Landroid/os/PowerManager$WakeLock;

    const-string v0, "phone"

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    if-eqz v0, :cond_96

    iget-object v1, p0, Lait/podka/services/AudioService;->b:Landroid/telephony/PhoneStateListener;

    const/16 v2, 0x20

    invoke-virtual {v0, v1, v2}, Landroid/telephony/TelephonyManager;->listen(Landroid/telephony/PhoneStateListener;I)V

    :cond_96
    return-void
.end method

.method public onDestroy()V
    .registers 4

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    iget-object v0, p0, Lait/podka/services/AudioService;->e:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    iget-object v0, p0, Lait/podka/services/AudioService;->g:Landroid/app/NotificationManager;

    invoke-virtual {v0}, Landroid/app/NotificationManager;->cancelAll()V

    const-string v0, "phone"

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    if-eqz v0, :cond_22

    iget-object v1, p0, Lait/podka/services/AudioService;->b:Landroid/telephony/PhoneStateListener;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/telephony/TelephonyManager;->listen(Landroid/telephony/PhoneStateListener;I)V

    :cond_22
    invoke-direct {p0}, Lait/podka/services/AudioService;->e()V

    return-void
.end method

.method public onError(Landroid/media/MediaPlayer;II)Z
    .registers 5

    const/4 v0, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->reset()V

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->stopForeground(Z)V

    invoke-direct {p0}, Lait/podka/services/AudioService;->e()V

    return v0
.end method

.method public onInfo(Landroid/media/MediaPlayer;II)Z
    .registers 6

    const/4 v1, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    packed-switch p2, :pswitch_data_12

    :goto_a
    return v1

    :pswitch_b
    iput-boolean v1, p0, Lait/podka/services/AudioService;->n:Z

    goto :goto_a

    :pswitch_e
    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/services/AudioService;->n:Z

    goto :goto_a

    :pswitch_data_12
    .packed-switch 0x2bd
        :pswitch_b
        :pswitch_e
    .end packed-switch
.end method

.method public onPrepared(Landroid/media/MediaPlayer;)V
    .registers 3

    const/4 v0, 0x1

    iput-boolean v0, p0, Lait/podka/services/AudioService;->o:Z

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 9

    const/4 v4, -0x1

    const-string v0, "action"

    invoke-virtual {p1, v0, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "enclosureID"

    const-wide/16 v2, -0x1

    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    if-eq v0, v4, :cond_24

    iget-object v3, p0, Lait/podka/services/AudioService;->c:Landroid/os/Handler;

    invoke-virtual {v3}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v3

    iput v0, v3, Landroid/os/Message;->arg1:I

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iput-object v0, v3, Landroid/os/Message;->obj:Ljava/lang/Object;

    iget-object v0, p0, Lait/podka/services/AudioService;->c:Landroid/os/Handler;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_24
    const/4 v0, 0x2

    return v0
.end method

.method public pause()V
    .registers 2

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->pause()V

    invoke-direct {p0}, Lait/podka/services/AudioService;->f()V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lait/podka/services/AudioService;->stopForeground(Z)V

    invoke-direct {p0}, Lait/podka/services/AudioService;->e()V

    return-void
.end method

.method public seekTo(I)V
    .registers 3

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->seekTo(I)V

    return-void
.end method

.method public start()V
    .registers 3

    iget-object v0, p0, Lait/podka/services/AudioService;->d:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    const/16 v0, 0x392

    iget-object v1, p0, Lait/podka/services/AudioService;->i:Landroid/app/Notification;

    invoke-virtual {p0, v0, v1}, Lait/podka/services/AudioService;->startForeground(ILandroid/app/Notification;)V

    invoke-direct {p0}, Lait/podka/services/AudioService;->d()V

    return-void
.end method
