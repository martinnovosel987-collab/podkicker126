###### Class ait.podka.services.c (ait.podka.services.c)
.class public final Lait/podka/services/c;
.super Landroid/os/Binder;


# instance fields
.field final synthetic a:Lait/podka/services/AudioService;


# direct methods
.method public constructor <init>(Lait/podka/services/AudioService;)V
    .registers 2

    iput-object p1, p0, Lait/podka/services/c;->a:Lait/podka/services/AudioService;

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lait/podka/services/AudioService;
    .registers 2

    iget-object v0, p0, Lait/podka/services/c;->a:Lait/podka/services/AudioService;

    return-object v0
.end method
