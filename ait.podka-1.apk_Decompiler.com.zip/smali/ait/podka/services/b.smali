###### Class ait.podka.services.b (ait.podka.services.b)
.class final Lait/podka/services/b;
.super Landroid/os/Handler;


# instance fields
.field final synthetic a:Lait/podka/services/AudioService;


# direct methods
.method public constructor <init>(Lait/podka/services/AudioService;Landroid/os/Looper;)V
    .registers 3

    iput-object p1, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .registers 5

    const-wide/16 v0, -0x1

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    if-eqz v2, :cond_e

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    :cond_e
    iget v2, p1, Landroid/os/Message;->arg1:I

    packed-switch v2, :pswitch_data_92

    :cond_13
    :goto_13
    return-void

    :pswitch_14
    iget-object v2, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-static {v2, v0, v1}, Lait/podka/services/AudioService;->a(Lait/podka/services/AudioService;J)V

    goto :goto_13

    :pswitch_1a
    iget-object v2, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-static {v2, v0, v1}, Lait/podka/services/AudioService;->b(Lait/podka/services/AudioService;J)V

    goto :goto_13

    :pswitch_20
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_13

    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->pause()V

    goto :goto_13

    :pswitch_2e
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_3c

    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->pause()V

    goto :goto_13

    :cond_3c
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-static {v0}, Lait/podka/services/AudioService;->a(Lait/podka/services/AudioService;)Z

    move-result v0

    if-eqz v0, :cond_13

    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->start()V

    goto :goto_13

    :pswitch_4a
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->canSeekForward()Z

    move-result v0

    if-eqz v0, :cond_13

    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-static {v0}, Lait/podka/services/AudioService;->b(Lait/podka/services/AudioService;)Landroid/media/MediaPlayer;

    move-result-object v0

    iget-object v1, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v1}, Lait/podka/services/AudioService;->getCurrentPosition()I

    move-result v1

    add-int/lit16 v1, v1, 0x3a98

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    goto :goto_13

    :pswitch_64
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->canSeekBackward()Z

    move-result v0

    if-eqz v0, :cond_13

    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-static {v0}, Lait/podka/services/AudioService;->b(Lait/podka/services/AudioService;)Landroid/media/MediaPlayer;

    move-result-object v0

    iget-object v1, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v1}, Lait/podka/services/AudioService;->getCurrentPosition()I

    move-result v1

    add-int/lit16 v1, v1, -0x3a98

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    goto :goto_13

    :pswitch_7e
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_13

    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->pause()V

    goto :goto_13

    :pswitch_8c
    iget-object v0, p0, Lait/podka/services/b;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->a()V

    goto :goto_13

    :pswitch_data_92
    .packed-switch 0x2
        :pswitch_14
        :pswitch_2e
        :pswitch_4a
        :pswitch_64
        :pswitch_8c
        :pswitch_20
        :pswitch_7e
        :pswitch_1a
    .end packed-switch
.end method
