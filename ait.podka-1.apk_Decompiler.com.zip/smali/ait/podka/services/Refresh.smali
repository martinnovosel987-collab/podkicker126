###### Class ait.podka.services.Refresh (ait.podka.services.Refresh)
.class public Lait/podka/services/Refresh;
.super Landroid/app/Service;


# instance fields
.field private volatile a:Landroid/os/Looper;

.field private volatile b:Lait/podka/services/e;

.field private c:Landroid/app/Notification;

.field private d:Landroid/support/v4/app/am;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method static synthetic a(Lait/podka/services/Refresh;)Landroid/app/Notification;
    .registers 2

    iget-object v0, p0, Lait/podka/services/Refresh;->c:Landroid/app/Notification;

    return-object v0
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3

    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()V
    .registers 7

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "PodcastUpdater"

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    iput-object v0, p0, Lait/podka/services/Refresh;->a:Landroid/os/Looper;

    new-instance v0, Lait/podka/services/e;

    iget-object v1, p0, Lait/podka/services/Refresh;->a:Landroid/os/Looper;

    invoke-direct {v0, p0, v1}, Lait/podka/services/e;-><init>(Lait/podka/services/Refresh;Landroid/os/Looper;)V

    iput-object v0, p0, Lait/podka/services/Refresh;->b:Lait/podka/services/e;

    new-instance v0, Landroid/support/v4/app/am;

    invoke-direct {v0, p0}, Landroid/support/v4/app/am;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/services/Refresh;->d:Landroid/support/v4/app/am;

    iget-object v0, p0, Lait/podka/services/Refresh;->d:Landroid/support/v4/app/am;

    iget-object v1, v0, Landroid/support/v4/app/am;->r:Landroid/app/Notification;

    const v2, 0x108007c

    iput v2, v1, Landroid/app/Notification;->icon:I

    const-string v1, "Podkicker refreshing."

    iput-object v1, v0, Landroid/support/v4/app/am;->b:Ljava/lang/CharSequence;

    iget-object v1, v0, Landroid/support/v4/app/am;->r:Landroid/app/Notification;

    iget v2, v1, Landroid/app/Notification;->flags:I

    or-int/lit8 v2, v2, 0x2

    iput v2, v1, Landroid/app/Notification;->flags:I

    const/4 v1, 0x1

    iput v1, v0, Landroid/support/v4/app/am;->j:I

    invoke-virtual {p0}, Lait/podka/services/Refresh;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v2, 0x0

    new-instance v3, Landroid/content/Intent;

    invoke-virtual {p0}, Lait/podka/services/Refresh;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-class v5, Lait/podka/Podka;

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v4, 0x10000000

    invoke-static {v1, v2, v3, v4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    iput-object v1, v0, Landroid/support/v4/app/am;->d:Landroid/app/PendingIntent;

    invoke-static {}, Landroid/support/v4/app/ai;->a()Landroid/support/v4/app/ao;

    move-result-object v1

    invoke-interface {v1, v0}, Landroid/support/v4/app/ao;->a(Landroid/support/v4/app/am;)Landroid/app/Notification;

    move-result-object v0

    iput-object v0, p0, Lait/podka/services/Refresh;->c:Landroid/app/Notification;

    return-void
.end method

.method public onDestroy()V
    .registers 2

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    iget-object v0, p0, Lait/podka/services/Refresh;->a:Landroid/os/Looper;

    invoke-virtual {v0}, Landroid/os/Looper;->quit()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 6

    const/4 v0, 0x0

    if-eqz p1, :cond_13

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    if-eqz v1, :cond_13

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "url"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_13
    iget-object v1, p0, Lait/podka/services/Refresh;->b:Lait/podka/services/e;

    invoke-virtual {v1}, Lait/podka/services/e;->obtainMessage()Landroid/os/Message;

    move-result-object v1

    iput p3, v1, Landroid/os/Message;->arg1:I

    if-eqz v0, :cond_1f

    iput-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    :cond_1f
    iget-object v0, p0, Lait/podka/services/Refresh;->b:Lait/podka/services/e;

    invoke-virtual {v0, v1}, Lait/podka/services/e;->sendMessage(Landroid/os/Message;)Z

    const/4 v0, 0x2

    return v0
.end method
