###### Class ait.podka.services.e (ait.podka.services.e)
.class final Lait/podka/services/e;
.super Landroid/os/Handler;


# instance fields
.field final synthetic a:Lait/podka/services/Refresh;


# direct methods
.method public constructor <init>(Lait/podka/services/Refresh;Landroid/os/Looper;)V
    .registers 3

    iput-object p1, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .registers 7

    const/4 v4, 0x1

    iget v0, p1, Landroid/os/Message;->arg1:I

    if-le v0, v4, :cond_6

    :goto_5
    return-void

    :cond_6
    :try_start_6
    iget-object v0, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-virtual {v0}, Lait/podka/services/Refresh;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "last_refresh_time"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    new-instance v1, Lait/podka/b/b;

    iget-object v0, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-virtual {v0}, Lait/podka/services/Refresh;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v1, v0}, Lait/podka/b/b;-><init>(Landroid/content/Context;)V

    iget-object v0, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    const/16 v2, 0x324

    iget-object v3, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-static {v3}, Lait/podka/services/Refresh;->a(Lait/podka/services/Refresh;)Landroid/app/Notification;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lait/podka/services/Refresh;->startForeground(ILandroid/app/Notification;)V

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    if-eqz v0, :cond_4f

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lait/podka/b/b;->b(Ljava/lang/String;)V
    :try_end_44
    .catchall {:try_start_6 .. :try_end_44} :catchall_53

    :goto_44
    iget-object v0, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-virtual {v0, v4}, Lait/podka/services/Refresh;->stopForeground(Z)V

    iget-object v0, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-virtual {v0}, Lait/podka/services/Refresh;->stopSelf()V

    goto :goto_5

    :cond_4f
    :try_start_4f
    invoke-virtual {v1}, Lait/podka/b/b;->a()V
    :try_end_52
    .catchall {:try_start_4f .. :try_end_52} :catchall_53

    goto :goto_44

    :catchall_53
    move-exception v0

    iget-object v1, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-virtual {v1, v4}, Lait/podka/services/Refresh;->stopForeground(Z)V

    iget-object v1, p0, Lait/podka/services/e;->a:Lait/podka/services/Refresh;

    invoke-virtual {v1}, Lait/podka/services/Refresh;->stopSelf()V

    throw v0
.end method
