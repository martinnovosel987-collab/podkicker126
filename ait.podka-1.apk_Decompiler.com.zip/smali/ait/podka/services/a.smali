###### Class ait.podka.services.a (ait.podka.services.a)
.class final Lait/podka/services/a;
.super Landroid/telephony/PhoneStateListener;


# instance fields
.field final synthetic a:Lait/podka/services/AudioService;

.field private b:Z


# direct methods
.method constructor <init>(Lait/podka/services/AudioService;)V
    .registers 3

    iput-object p1, p0, Lait/podka/services/a;->a:Lait/podka/services/AudioService;

    invoke-direct {p0}, Landroid/telephony/PhoneStateListener;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/services/a;->b:Z

    return-void
.end method


# virtual methods
.method public final onCallStateChanged(ILjava/lang/String;)V
    .registers 5

    const/4 v1, 0x1

    if-ne p1, v1, :cond_16

    iget-object v0, p0, Lait/podka/services/a;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_12

    iput-boolean v1, p0, Lait/podka/services/a;->b:Z

    iget-object v0, p0, Lait/podka/services/a;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->pause()V

    :cond_12
    :goto_12
    invoke-super {p0, p1, p2}, Landroid/telephony/PhoneStateListener;->onCallStateChanged(ILjava/lang/String;)V

    return-void

    :cond_16
    if-nez p1, :cond_25

    iget-boolean v0, p0, Lait/podka/services/a;->b:Z

    if-eqz v0, :cond_12

    iget-object v0, p0, Lait/podka/services/a;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->start()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/services/a;->b:Z

    goto :goto_12

    :cond_25
    const/4 v0, 0x2

    if-ne p1, v0, :cond_12

    iget-object v0, p0, Lait/podka/services/a;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_12

    iput-boolean v1, p0, Lait/podka/services/a;->b:Z

    iget-object v0, p0, Lait/podka/services/a;->a:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->pause()V

    goto :goto_12
.end method
