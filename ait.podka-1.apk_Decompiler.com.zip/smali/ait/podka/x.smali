###### Class ait.podka.x (ait.podka.x)
.class final Lait/podka/x;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/v;


# direct methods
.method constructor <init>(Lait/podka/v;)V
    .registers 2

    iput-object p1, p0, Lait/podka/x;->a:Lait/podka/v;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    const/4 v3, 0x0

    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const-string v1, "ch_ignorecache"

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    iget-object v1, p0, Lait/podka/x;->a:Lait/podka/v;

    invoke-static {v1}, Lait/podka/v;->a(Lait/podka/v;)Lait/podka/Prefs;

    move-result-object v1

    invoke-virtual {v1}, Lait/podka/Prefs;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v2, Lait/podka/database/d;->a:Landroid/net/Uri;

    invoke-virtual {v1, v2, v0, v3, v3}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    return-void
.end method
