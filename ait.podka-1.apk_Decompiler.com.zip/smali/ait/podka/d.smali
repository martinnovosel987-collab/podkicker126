###### Class ait.podka.d (ait.podka.d)
.class final Lait/podka/d;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/ExportFilesActivity;


# direct methods
.method private constructor <init>(Lait/podka/ExportFilesActivity;)V
    .registers 2

    iput-object p1, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/ExportFilesActivity;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/d;-><init>(Lait/podka/ExportFilesActivity;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 17

    new-instance v7, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "/Android/data/"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    invoke-virtual {v2}, Lait/podka/ExportFilesActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/files/podcasts/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v7, v0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x8

    if-ge v0, v1, :cond_c9

    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    const-string v2, "Podcasts/"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v0

    :goto_36
    invoke-virtual {v6}, Ljava/io/File;->toString()Ljava/lang/String;

    invoke-virtual {v6}, Ljava/io/File;->mkdir()Z

    const-string v0, ","

    invoke-virtual {v7}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "enc_filename IN ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v0, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    iget-object v0, v0, Lait/podka/ExportFilesActivity;->b:Landroid/content/ContentResolver;

    sget-object v1, Lait/podka/database/e;->a:Landroid/net/Uri;

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4

    const/16 v0, 0xf

    new-array v5, v0, [C

    const/4 v0, 0x0

    const/16 v1, 0x2f

    aput-char v1, v5, v0

    const/4 v0, 0x1

    const/16 v1, 0xa

    aput-char v1, v5, v0

    const/4 v0, 0x2

    const/16 v1, 0xd

    aput-char v1, v5, v0

    const/4 v0, 0x3

    const/16 v1, 0x9

    aput-char v1, v5, v0

    const/4 v0, 0x5

    const/16 v1, 0xc

    aput-char v1, v5, v0

    const/4 v0, 0x6

    const/16 v1, 0x60

    aput-char v1, v5, v0

    const/4 v0, 0x7

    const/16 v1, 0x3f

    aput-char v1, v5, v0

    const/16 v0, 0x8

    const/16 v1, 0x2a

    aput-char v1, v5, v0

    const/16 v0, 0x9

    const/16 v1, 0x5c

    aput-char v1, v5, v0

    const/16 v0, 0xa

    const/16 v1, 0x3c

    aput-char v1, v5, v0

    const/16 v0, 0xb

    const/16 v1, 0x3e

    aput-char v1, v5, v0

    const/16 v0, 0xc

    const/16 v1, 0x7c

    aput-char v1, v5, v0

    const/16 v0, 0xd

    const/16 v1, 0x22

    aput-char v1, v5, v0

    const/16 v0, 0xe

    const/16 v1, 0x3a

    aput-char v1, v5, v0

    :cond_b9
    const/4 v0, 0x1

    move v1, v0

    :cond_bb
    :goto_bb
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-nez v0, :cond_d2

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    :cond_c9
    sget-object v0, Landroid/os/Environment;->DIRECTORY_PODCASTS:Ljava/lang/String;

    invoke-static {v0}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    move-object v6, v0

    goto/16 :goto_36

    :cond_d2
    const-string v0, "enc_url"

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v0, "enc_filename"

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    const-string v0, "ch_title"

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    const-string v3, "_id"

    invoke-interface {v4, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v4, v3}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v9

    const/16 v3, 0x2f

    invoke-virtual {v2, v3}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v3

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v11

    invoke-virtual {v2, v3, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    const/16 v11, 0x1e

    if-lt v3, v11, :cond_119

    const/4 v3, 0x0

    const/16 v11, 0x1d

    invoke-virtual {v0, v3, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :cond_119
    invoke-static {v2}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    array-length v11, v5

    const/4 v2, 0x0

    move v14, v2

    move-object v2, v0

    move v0, v14

    :goto_122
    if-lt v0, v11, :cond_16a

    const/16 v0, 0x20

    const/16 v11, 0x5f

    invoke-virtual {v3, v0, v11}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x20

    const/16 v11, 0x5f

    invoke-virtual {v2, v3, v11}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v7, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v8

    if-eqz v8, :cond_bb

    const/4 v8, 0x1

    new-array v8, v8, [Ljava/lang/String;

    const/4 v11, 0x0

    aput-object v0, v8, v11

    invoke-virtual {p0, v8}, Lait/podka/d;->publishProgress([Ljava/lang/Object;)V

    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v6, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v8}, Ljava/io/File;->mkdirs()Z

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v8, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v0

    if-eqz v0, :cond_162

    iget-object v2, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    iget-object v2, v2, Lait/podka/ExportFilesActivity;->b:Landroid/content/ContentResolver;

    invoke-static {v2, v9, v10}, Lait/podka/database/a;->b(Landroid/content/ContentResolver;J)V

    :cond_162
    if-eqz v1, :cond_b9

    if-nez v0, :cond_b9

    const/4 v0, 0x0

    move v1, v0

    goto/16 :goto_bb

    :cond_16a
    aget-char v12, v5, v0

    const/16 v13, 0x5f

    invoke-virtual {v3, v12, v13}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v3

    const/16 v13, 0x5f

    invoke-virtual {v2, v12, v13}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_122
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 5

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_18

    iget-object v0, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    invoke-virtual {v0}, Lait/podka/ExportFilesActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Some files could not be moved"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_18
    iget-object v0, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    invoke-virtual {v0}, Lait/podka/ExportFilesActivity;->finish()V

    return-void
.end method

.method protected final varargs synthetic onProgressUpdate([Ljava/lang/Object;)V
    .registers 4

    check-cast p1, [Ljava/lang/String;

    iget-object v0, p0, Lait/podka/d;->a:Lait/podka/ExportFilesActivity;

    iget-object v0, v0, Lait/podka/ExportFilesActivity;->a:Landroid/widget/TextView;

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
