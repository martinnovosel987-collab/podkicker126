###### Class ait.podka.h (ait.podka.h)
.class final Lait/podka/h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/Notification;


# direct methods
.method constructor <init>(Lait/podka/Notification;)V
    .registers 2

    iput-object p1, p0, Lait/podka/h;->a:Lait/podka/Notification;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    const v2, 0x7f0b0004

    iget-object v0, p0, Lait/podka/h;->a:Lait/podka/Notification;

    invoke-virtual {v0, v2}, Lait/podka/Notification;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "When purchasing you will support the development and get a <font color=yellow>lifetime license</font> for a much better Podkicker"

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lait/podka/h;->a:Lait/podka/Notification;

    invoke-virtual {v0, v2}, Lait/podka/Notification;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lait/podka/h;->a:Lait/podka/Notification;

    const/high16 v2, 0x7f040000

    invoke-static {v1, v2}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->startAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method
