###### Class ait.podka.C0000r (ait.podka.r)
.class final Lait/podka/r;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/preference/Preference$OnPreferenceClickListener;


# instance fields
.field final synthetic a:Lait/podka/Prefs;


# direct methods
.method constructor <init>(Lait/podka/Prefs;)V
    .registers 2

    iput-object p1, p0, Lait/podka/r;->a:Lait/podka/Prefs;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onPreferenceClick(Landroid/preference/Preference;)Z
    .registers 6

    iget-object v0, p0, Lait/podka/r;->a:Lait/podka/Prefs;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    const-string v3, "market://details?id=com.podkicker"

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Lait/podka/Prefs;->startActivity(Landroid/content/Intent;)V

    const/4 v0, 0x1

    return v0
.end method
