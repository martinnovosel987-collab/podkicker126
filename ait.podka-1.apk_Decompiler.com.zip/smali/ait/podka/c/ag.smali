###### Class ait.podka.c.ag (ait.podka.c.ag)
.class final Lait/podka/c/ag;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field final synthetic a:Lait/podka/c/af;


# direct methods
.method constructor <init>(Lait/podka/c/af;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/ag;->a:Lait/podka/c/af;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .registers 5

    iget-object v0, p0, Lait/podka/c/ag;->a:Lait/podka/c/af;

    check-cast p2, Lait/podka/services/c;

    invoke-virtual {p2}, Lait/podka/services/c;->a()Lait/podka/services/AudioService;

    move-result-object v1

    invoke-static {v0, v1}, Lait/podka/c/af;->a(Lait/podka/c/af;Lait/podka/services/AudioService;)V

    iget-object v0, p0, Lait/podka/c/ag;->a:Lait/podka/c/af;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lait/podka/c/af;->a(Lait/podka/c/af;Z)V

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .registers 4

    iget-object v0, p0, Lait/podka/c/ag;->a:Lait/podka/c/af;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/af;->a(Lait/podka/c/af;Lait/podka/services/AudioService;)V

    iget-object v0, p0, Lait/podka/c/ag;->a:Lait/podka/c/af;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/af;->a(Lait/podka/c/af;Z)V

    return-void
.end method
