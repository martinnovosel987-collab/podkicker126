###### Class ait.podka.c.au (ait.podka.c.au)
.class final Lait/podka/c/au;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Observer;


# instance fields
.field final synthetic a:Lait/podka/c/at;


# direct methods
.method constructor <init>(Lait/podka/c/at;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/au;->a:Lait/podka/c/at;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final update(Ljava/util/Observable;Ljava/lang/Object;)V
    .registers 6

    iget-object v0, p0, Lait/podka/c/au;->a:Lait/podka/c/at;

    const/4 v1, 0x1

    new-array v1, v1, [Landroid/os/Message;

    const/4 v2, 0x0

    check-cast p2, Landroid/os/Message;

    aput-object p2, v1, v2

    invoke-static {v0, v1}, Lait/podka/c/at;->a(Lait/podka/c/at;[Ljava/lang/Object;)V

    return-void
.end method
