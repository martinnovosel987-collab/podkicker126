###### Class ait.podka.c.aj (ait.podka.c.aj)
.class final Lait/podka/c/aj;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field a:Ljava/lang/Runnable;

.field final synthetic b:Lait/podka/c/af;


# direct methods
.method private constructor <init>(Lait/podka/c/af;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/aj;->b:Lait/podka/c/af;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lait/podka/c/ak;

    invoke-direct {v0, p0}, Lait/podka/c/ak;-><init>(Lait/podka/c/aj;)V

    iput-object v0, p0, Lait/podka/c/aj;->a:Ljava/lang/Runnable;

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/af;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/aj;-><init>(Lait/podka/c/af;)V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/aj;->b:Lait/podka/c/af;

    invoke-static {v0}, Lait/podka/c/af;->b(Lait/podka/c/af;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lait/podka/c/aj;->a:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
