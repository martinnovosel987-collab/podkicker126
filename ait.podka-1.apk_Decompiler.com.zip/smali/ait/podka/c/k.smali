###### Class ait.podka.c.k (ait.podka.c.k)
.class final Lait/podka/c/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/i;

.field private final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Lait/podka/c/i;Landroid/content/Context;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/k;->a:Lait/podka/c/i;

    iput-object p2, p0, Lait/podka/c/k;->b:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lait/podka/c/l;

    iget-object v2, p0, Lait/podka/c/k;->b:Landroid/content/Context;

    invoke-direct {v1, p0, v2}, Lait/podka/c/l;-><init>(Lait/podka/c/k;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
