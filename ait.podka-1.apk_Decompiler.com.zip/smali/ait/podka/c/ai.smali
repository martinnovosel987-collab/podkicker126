###### Class ait.podka.c.ai (ait.podka.c.ai)
.class final Lait/podka/c/ai;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/af;

.field private final synthetic b:Landroid/content/ContentResolver;


# direct methods
.method constructor <init>(Lait/podka/c/af;Landroid/content/ContentResolver;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/ai;->a:Lait/podka/c/af;

    iput-object p2, p0, Lait/podka/c/ai;->b:Landroid/content/ContentResolver;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lait/podka/c/ai;->b:Landroid/content/ContentResolver;

    invoke-static {v0}, Lait/podka/database/a;->a(Landroid/content/ContentResolver;)V

    return-void
.end method
