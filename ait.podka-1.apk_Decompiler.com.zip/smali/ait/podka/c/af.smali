###### Class ait.podka.c.af (ait.podka.c.af)
.class public Lait/podka/c/af;
.super Landroid/support/v4/app/aa;

# interfaces
.implements Landroid/support/v4/app/ae;
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# instance fields
.field private Z:Landroid/widget/TextView;

.field private a:Ljava/util/concurrent/ScheduledExecutorService;

.field private aa:Landroid/widget/TextView;

.field private ab:Landroid/widget/SeekBar;

.field private ac:Landroid/widget/ImageButton;

.field private ad:Landroid/widget/ImageButton;

.field private ae:Landroid/widget/ImageButton;

.field private af:Lait/podka/a/s;

.field private ag:Z

.field private ah:Landroid/graphics/drawable/Drawable;

.field private ai:Landroid/graphics/drawable/Drawable;

.field private aj:Lait/podka/services/AudioService;

.field private ak:Landroid/content/ServiceConnection;

.field private al:Z

.field private j:Landroid/os/Handler;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/support/v4/app/aa;-><init>()V

    new-instance v0, Lait/podka/c/ag;

    invoke-direct {v0, p0}, Lait/podka/c/ag;-><init>(Lait/podka/c/af;)V

    iput-object v0, p0, Lait/podka/c/af;->ak:Landroid/content/ServiceConnection;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/c/af;->al:Z

    return-void
.end method

.method static synthetic a(Lait/podka/c/af;)V
    .registers 1

    invoke-direct {p0}, Lait/podka/c/af;->d()V

    return-void
.end method

.method static synthetic a(Lait/podka/c/af;Lait/podka/services/AudioService;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    return-void
.end method

.method static synthetic a(Lait/podka/c/af;Z)V
    .registers 2

    iput-boolean p1, p0, Lait/podka/c/af;->al:Z

    return-void
.end method

.method static synthetic b(Lait/podka/c/af;)Landroid/os/Handler;
    .registers 2

    iget-object v0, p0, Lait/podka/c/af;->j:Landroid/os/Handler;

    return-object v0
.end method

.method private d()V
    .registers 8

    iget-boolean v0, p0, Lait/podka/c/af;->al:Z

    if-nez v0, :cond_5

    :goto_4
    return-void

    :cond_5
    iget-object v0, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_76

    iget-object v0, p0, Lait/podka/c/af;->ad:Landroid/widget/ImageButton;

    iget-object v1, p0, Lait/podka/c/af;->ah:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_14
    iget-object v0, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v0}, Lait/podka/services/AudioService;->getCurrentPosition()I

    move-result v0

    iget-object v1, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v1}, Lait/podka/services/AudioService;->getDuration()I

    move-result v1

    iget-object v2, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v2}, Lait/podka/services/AudioService;->getBufferPercentage()I

    move-result v2

    iget-object v3, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v3}, Lait/podka/services/AudioService;->b()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lait/podka/c/af;->ab:Landroid/widget/SeekBar;

    invoke-virtual {v4, v0}, Landroid/widget/SeekBar;->setProgress(I)V

    iget-object v4, p0, Lait/podka/c/af;->ab:Landroid/widget/SeekBar;

    invoke-virtual {v4, v1}, Landroid/widget/SeekBar;->setMax(I)V

    iget-object v4, p0, Lait/podka/c/af;->ab:Landroid/widget/SeekBar;

    int-to-float v5, v1

    int-to-float v2, v2

    const/high16 v6, 0x42c80000    # 100.0f

    div-float/2addr v2, v6

    mul-float/2addr v2, v5

    float-to-int v2, v2

    invoke-virtual {v4, v2}, Landroid/widget/SeekBar;->setSecondaryProgress(I)V

    iget-object v2, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v2}, Lait/podka/services/AudioService;->c()Z

    move-result v2

    if-nez v2, :cond_7e

    new-instance v2, Ljava/lang/StringBuilder;

    int-to-long v4, v0

    invoke-static {v4, v5}, Lait/podka/d/b;->a(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, " | "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    int-to-long v1, v1

    invoke-static {v1, v2}, Lait/podka/d/b;->a(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lait/podka/c/af;->Z:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_70
    iget-object v0, p0, Lait/podka/c/af;->aa:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4

    :cond_76
    iget-object v0, p0, Lait/podka/c/af;->ad:Landroid/widget/ImageButton;

    iget-object v1, p0, Lait/podka/c/af;->ai:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_14

    :cond_7e
    iget-object v0, p0, Lait/podka/c/af;->Z:Landroid/widget/TextView;

    const-string v1, "buffering..."

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_70
.end method


# virtual methods
.method public final a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 7

    const/4 v1, 0x0

    const v0, 0x7f030006

    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v2

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    const v3, 0x7f0b0031

    invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_a0

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getVisibility()I

    move-result v0

    if-nez v0, :cond_a0

    const/4 v0, 0x1

    :goto_1c
    iput-boolean v0, p0, Lait/podka/c/af;->ag:Z

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lait/podka/c/af;->j:Landroid/os/Handler;

    const v0, 0x7f0b0003

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lait/podka/c/af;->ac:Landroid/widget/ImageButton;

    const v0, 0x7f0b0006

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lait/podka/c/af;->ad:Landroid/widget/ImageButton;

    const v0, 0x7f0b000f

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lait/podka/c/af;->ae:Landroid/widget/ImageButton;

    const v0, 0x7f0b0032

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/SeekBar;

    iput-object v0, p0, Lait/podka/c/af;->ab:Landroid/widget/SeekBar;

    const v0, 0x7f0b0002

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/c/af;->Z:Landroid/widget/TextView;

    const v0, 0x7f0b0004

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/c/af;->aa:Landroid/widget/TextView;

    iget-object v0, p0, Lait/podka/c/af;->Z:Landroid/widget/TextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x1080024

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/af;->ai:Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x1080023

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/af;->ah:Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, Lait/podka/c/af;->ac:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lait/podka/c/af;->ad:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lait/podka/c/af;->ae:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lait/podka/c/af;->ab:Landroid/widget/SeekBar;

    invoke-virtual {v0, p0}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    return-object v2

    :cond_a0
    move v0, v1

    goto/16 :goto_1c
.end method

.method public final a()V
    .registers 3

    invoke-super {p0}, Landroid/support/v4/app/aa;->a()V

    iget-object v0, p0, Lait/podka/c/af;->a:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    iget-boolean v0, p0, Lait/podka/c/af;->al:Z

    if-eqz v0, :cond_16

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    iget-object v1, p0, Lait/podka/c/af;->ak:Landroid/content/ServiceConnection;

    invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lait/podka/c/af;->al:Z

    :cond_16
    return-void
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 4

    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/os/Bundle;)V

    new-instance v0, Lait/podka/a/s;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lait/podka/a/s;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/c/af;->af:Lait/podka/a/s;

    iget-object v0, p0, Lait/podka/c/af;->af:Lait/podka/a/s;

    invoke-virtual {p0, v0}, Lait/podka/c/af;->a(Landroid/widget/ListAdapter;)V

    iget-boolean v0, p0, Lait/podka/c/af;->ag:Z

    if-nez v0, :cond_28

    invoke-virtual {p0}, Lait/podka/c/af;->r()Landroid/support/v4/app/ad;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p0}, Landroid/support/v4/app/ad;->a(ILandroid/support/v4/app/ae;)Landroid/support/v4/content/f;

    invoke-virtual {p0}, Lait/podka/c/af;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnCreateContextMenuListener(Landroid/view/View$OnCreateContextMenuListener;)V

    :cond_28
    return-void
.end method

.method public final a(Landroid/view/View;IJ)V
    .registers 8

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lait/podka/services/AudioService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "action"

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v1, "enclosureID"

    invoke-virtual {v0, v1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1, v0}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void
.end method

.method public final synthetic a(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroid/database/Cursor;

    iget-object v0, p0, Lait/podka/c/af;->af:Lait/podka/a/s;

    invoke-virtual {v0, p1}, Lait/podka/a/s;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final a(Landroid/view/MenuItem;)Z
    .registers 7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    invoke-interface {p1}, Landroid/view/MenuItem;->getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    check-cast v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lait/podka/services/AudioService;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v3

    sparse-switch v3, :sswitch_data_72

    :goto_27
    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/view/MenuItem;)Z

    move-result v0

    return v0

    :sswitch_2c
    iget-wide v2, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v1, v2, v3}, Lait/podka/database/a;->a(Landroid/content/ContentResolver;J)V

    goto :goto_27

    :sswitch_32
    const-string v1, "action"

    const/4 v3, 0x2

    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v1, "enclosureID"

    iget-wide v3, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-virtual {v2, v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_27

    :sswitch_45
    iget-wide v2, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v2, v3, v1}, Lait/podka/database/a;->b(JLandroid/content/ContentResolver;)V

    goto :goto_27

    :sswitch_4b
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lait/podka/c/ah;

    invoke-direct {v3, p0, v0, v1}, Lait/podka/c/ah;-><init>(Lait/podka/c/af;Landroid/widget/AdapterView$AdapterContextMenuInfo;Landroid/content/ContentResolver;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    goto :goto_27

    :sswitch_59
    const-string v0, "action"

    const/4 v3, 0x7

    invoke-virtual {v2, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Lait/podka/c/ai;

    invoke-direct {v2, p0, v1}, Lait/podka/c/ai;-><init>(Lait/podka/c/af;Landroid/content/ContentResolver;)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto :goto_27

    :sswitch_data_72
    .sparse-switch
        0x57 -> :sswitch_32
        0x58 -> :sswitch_45
        0x59 -> :sswitch_59
        0x68 -> :sswitch_4b
        0x72 -> :sswitch_2c
    .end sparse-switch
.end method

.method public final a_()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/af;->af:Lait/podka/a/s;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lait/podka/a/s;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final b(I)Landroid/support/v4/content/f;
    .registers 9

    const/4 v3, 0x0

    new-instance v0, Landroid/support/v4/content/c;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    sget-object v2, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v4, "enc_queue IS NOT NULL AND enc_queue != \'\'"

    const-string v6, "enc_queue ASC"

    move-object v5, v3

    invoke-direct/range {v0 .. v6}, Landroid/support/v4/content/c;-><init>(Landroid/content/Context;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public final b()V
    .registers 8

    invoke-super {p0}, Landroid/support/v4/app/aa;->b()V

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v2}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lait/podka/services/AudioService;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v2, p0, Lait/podka/c/af;->ak:Landroid/content/ServiceConnection;

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/app/FragmentActivity;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/af;->a:Ljava/util/concurrent/ScheduledExecutorService;

    iget-object v0, p0, Lait/podka/c/af;->a:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lait/podka/c/aj;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lait/podka/c/aj;-><init>(Lait/podka/c/af;B)V

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0xfa

    sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface/range {v0 .. v6}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 5

    new-instance v0, Landroid/content/Intent;

    const-string v1, "w003t"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v1

    sparse-switch v1, :sswitch_data_2c

    :goto_e
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1, v0}, Landroid/support/v4/app/FragmentActivity;->sendBroadcast(Landroid/content/Intent;)V

    invoke-direct {p0}, Lait/podka/c/af;->d()V

    return-void

    :sswitch_17
    const-string v1, "action"

    const/4 v2, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_e

    :sswitch_1e
    const-string v1, "action"

    const/4 v2, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_e

    :sswitch_25
    const-string v1, "action"

    const/4 v2, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_e

    :sswitch_data_2c
    .sparse-switch
        0x7f0b0003 -> :sswitch_17
        0x7f0b0006 -> :sswitch_1e
        0x7f0b000f -> :sswitch_25
    .end sparse-switch
.end method

.method public onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .registers 7

    const/4 v2, 0x0

    const-string v0, "Playlist"

    invoke-interface {p1, v0}, Landroid/view/ContextMenu;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/ContextMenu;

    const/16 v0, 0x57

    const-string v1, "Play"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x58

    const-string v1, "Remove"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x68

    const-string v1, "Remove & Delete"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x72

    const-string v1, "Reset position"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x59

    const-string v1, "Clear Playlist"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    return-void
.end method

.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 5

    if-eqz p3, :cond_a

    iget-object v0, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    if-eqz v0, :cond_a

    iget-boolean v0, p0, Lait/podka/c/af;->al:Z

    if-nez v0, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    iget-object v0, p0, Lait/podka/c/af;->aj:Lait/podka/services/AudioService;

    invoke-virtual {v0, p2}, Lait/podka/services/AudioService;->seekTo(I)V

    goto :goto_a
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method
