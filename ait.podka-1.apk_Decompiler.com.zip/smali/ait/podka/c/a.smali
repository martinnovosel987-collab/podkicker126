###### Class ait.podka.c.a (ait.podka.c.a)
.class public Lait/podka/c/a;
.super Landroid/support/v4/app/Fragment;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private Z:J

.field a:Landroid/widget/TextView;

.field private aa:Z

.field private ab:I

.field b:Landroid/widget/TextView;

.field c:Landroid/widget/TextView;

.field d:Landroid/widget/TextView;

.field e:Landroid/widget/ImageView;

.field f:Landroid/widget/Button;

.field g:Landroid/widget/Button;

.field h:Landroid/widget/Button;

.field private i:J

.field private j:J


# direct methods
.method public constructor <init>()V
    .registers 3

    const-wide/16 v0, 0x0

    invoke-direct {p0}, Landroid/support/v4/app/Fragment;-><init>()V

    iput-wide v0, p0, Lait/podka/c/a;->i:J

    iput-wide v0, p0, Lait/podka/c/a;->j:J

    iput-wide v0, p0, Lait/podka/c/a;->Z:J

    const/4 v0, 0x0

    iput v0, p0, Lait/podka/c/a;->ab:I

    return-void
.end method

.method static synthetic a(Lait/podka/c/a;)J
    .registers 3

    iget-wide v0, p0, Lait/podka/c/a;->i:J

    return-wide v0
.end method

.method static synthetic a(Lait/podka/c/a;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 7

    const/4 v0, 0x0

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    if-nez v1, :cond_6

    :cond_5
    :goto_5
    return-object v0

    :cond_6
    new-instance v1, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "/Android/data/"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v4}, Landroid/support/v4/app/FragmentActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/cache/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    new-instance v2, Ljava/io/File;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    goto :goto_5
.end method

.method static synthetic a(Lait/podka/c/a;I)V
    .registers 2

    iput p1, p0, Lait/podka/c/a;->ab:I

    return-void
.end method

.method static synthetic a(Lait/podka/c/a;J)V
    .registers 3

    iput-wide p1, p0, Lait/podka/c/a;->Z:J

    return-void
.end method

.method static synthetic a(Lait/podka/c/a;Z)V
    .registers 3

    iget-object v0, p0, Lait/podka/c/a;->f:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setClickable(Z)V

    iget-object v0, p0, Lait/podka/c/a;->h:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setClickable(Z)V

    iget-object v0, p0, Lait/podka/c/a;->g:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setClickable(Z)V

    return-void
.end method

.method static synthetic b(Lait/podka/c/a;)J
    .registers 3

    iget-wide v0, p0, Lait/podka/c/a;->j:J

    return-wide v0
.end method

.method static synthetic b(Lait/podka/c/a;J)V
    .registers 3

    iput-wide p1, p0, Lait/podka/c/a;->j:J

    return-void
.end method

.method static synthetic c(Lait/podka/c/a;)J
    .registers 3

    iget-wide v0, p0, Lait/podka/c/a;->Z:J

    return-wide v0
.end method

.method static synthetic d(Lait/podka/c/a;)Z
    .registers 2

    iget-boolean v0, p0, Lait/podka/c/a;->aa:Z

    return v0
.end method

.method static synthetic e(Lait/podka/c/a;)I
    .registers 2

    iget v0, p0, Lait/podka/c/a;->ab:I

    return v0
.end method


# virtual methods
.method public final a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 5

    const v0, 0x7f030004

    const/4 v1, 0x0

    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    const v0, 0x7f0b0002

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/c/a;->a:Landroid/widget/TextView;

    const v0, 0x7f0b0004

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/c/a;->b:Landroid/widget/TextView;

    const v0, 0x7f0b000c

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/c/a;->d:Landroid/widget/TextView;

    const v0, 0x7f0b0005

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/c/a;->c:Landroid/widget/TextView;

    const v0, 0x7f0b000d

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lait/podka/c/a;->e:Landroid/widget/ImageView;

    const v0, 0x7f0b000f

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lait/podka/c/a;->f:Landroid/widget/Button;

    const v0, 0x7f0b000e

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lait/podka/c/a;->h:Landroid/widget/Button;

    const v0, 0x7f0b0010

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lait/podka/c/a;->g:Landroid/widget/Button;

    iget-object v0, p0, Lait/podka/c/a;->f:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lait/podka/c/a;->h:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lait/podka/c/a;->g:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v1
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 6

    const/4 v1, 0x0

    invoke-super {p0, p1}, Landroid/support/v4/app/Fragment;->a(Landroid/os/Bundle;)V

    invoke-virtual {p0, v1}, Lait/podka/c/a;->a(Z)V

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "id"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v2

    iput-wide v2, p0, Lait/podka/c/a;->i:J

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    const v2, 0x7f0b0031

    invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_30

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_30

    const/4 v0, 0x1

    :goto_23
    iput-boolean v0, p0, Lait/podka/c/a;->aa:Z

    new-instance v0, Lait/podka/c/b;

    invoke-direct {v0, p0, v1}, Lait/podka/c/b;-><init>(Lait/podka/c/a;B)V

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lait/podka/c/b;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void

    :cond_30
    move v0, v1

    goto :goto_23
.end method

.method public onClick(Landroid/view/View;)V
    .registers 9

    const v6, 0x7f0b0031

    const v5, 0x7f0b002f

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    sparse-switch v0, :sswitch_data_f0

    :goto_d
    :sswitch_d
    return-void

    :sswitch_e
    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/s;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v2}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "action"

    const/4 v3, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "id"

    iget-wide v3, p0, Lait/podka/c/a;->i:J

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    iget-boolean v1, p0, Lait/podka/c/a;->aa:Z

    if-eqz v1, :cond_46

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v6, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_d

    :cond_46
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v5, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const-string v1, "entries"

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_d

    :sswitch_5a
    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/a;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v2}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "id"

    iget-wide v3, p0, Lait/podka/c/a;->Z:J

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->c()V

    iget-boolean v1, p0, Lait/podka/c/a;->aa:Z

    if-eqz v1, :cond_90

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v6, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto/16 :goto_d

    :cond_90
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v5, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const-string v1, "channeldetails"

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto/16 :goto_d

    :sswitch_a5
    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/a;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v2}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "id"

    iget-wide v3, p0, Lait/podka/c/a;->j:J

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->c()V

    iget-boolean v1, p0, Lait/podka/c/a;->aa:Z

    if-eqz v1, :cond_db

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v6, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto/16 :goto_d

    :cond_db
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v5, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const-string v1, "channeldetails"

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto/16 :goto_d

    :sswitch_data_f0
    .sparse-switch
        0x7f0b0006 -> :sswitch_d
        0x7f0b000e -> :sswitch_5a
        0x7f0b000f -> :sswitch_e
        0x7f0b0010 -> :sswitch_a5
    .end sparse-switch
.end method
