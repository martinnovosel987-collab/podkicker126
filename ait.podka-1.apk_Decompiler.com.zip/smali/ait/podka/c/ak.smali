###### Class ait.podka.c.ak (ait.podka.c.ak)
.class final Lait/podka/c/ak;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/aj;


# direct methods
.method constructor <init>(Lait/podka/c/aj;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/ak;->a:Lait/podka/c/aj;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lait/podka/c/ak;->a:Lait/podka/c/aj;

    iget-object v0, v0, Lait/podka/c/aj;->b:Lait/podka/c/af;

    invoke-static {v0}, Lait/podka/c/af;->a(Lait/podka/c/af;)V

    return-void
.end method
