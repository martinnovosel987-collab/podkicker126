###### Class ait.podka.c.al (ait.podka.c.al)
.class public Lait/podka/c/al;
.super Landroid/support/v4/app/aa;

# interfaces
.implements Landroid/support/v4/app/ae;


# instance fields
.field private a:Lait/podka/a/s;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/app/aa;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 6

    const v0, 0x7f03000f

    const/4 v1, 0x0

    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    const v0, 0x7f0b0002

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_17

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    :cond_17
    return-object v1
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 4

    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lait/podka/c/al;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnCreateContextMenuListener(Landroid/view/View$OnCreateContextMenuListener;)V

    new-instance v0, Lait/podka/a/s;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lait/podka/a/s;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/c/al;->a:Lait/podka/a/s;

    iget-object v0, p0, Lait/podka/c/al;->a:Lait/podka/a/s;

    invoke-virtual {p0, v0}, Lait/podka/c/al;->a(Landroid/widget/ListAdapter;)V

    invoke-virtual {p0}, Lait/podka/c/al;->r()Landroid/support/v4/app/ad;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p0}, Landroid/support/v4/app/ad;->a(ILandroid/support/v4/app/ae;)Landroid/support/v4/content/f;

    return-void
.end method

.method public final a(Landroid/view/View;IJ)V
    .registers 8

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lait/podka/services/AudioService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "action"

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v1, "enclosureID"

    invoke-virtual {v0, v1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1, v0}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void
.end method

.method public final synthetic a(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroid/database/Cursor;

    iget-object v0, p0, Lait/podka/c/al;->a:Lait/podka/a/s;

    invoke-virtual {v0, p1}, Lait/podka/a/s;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final a(Landroid/view/MenuItem;)Z
    .registers 7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    invoke-interface {p1}, Landroid/view/MenuItem;->getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    check-cast v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lait/podka/services/AudioService;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v3

    sparse-switch v3, :sswitch_data_72

    :goto_27
    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/view/MenuItem;)Z

    move-result v0

    return v0

    :sswitch_2c
    iget-wide v2, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v1, v2, v3}, Lait/podka/database/a;->a(Landroid/content/ContentResolver;J)V

    goto :goto_27

    :sswitch_32
    const-string v1, "action"

    const/4 v3, 0x2

    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v1, "enclosureID"

    iget-wide v3, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-virtual {v2, v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_27

    :sswitch_45
    iget-wide v2, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v2, v3, v1}, Lait/podka/database/a;->b(JLandroid/content/ContentResolver;)V

    goto :goto_27

    :sswitch_4b
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lait/podka/c/am;

    invoke-direct {v3, p0, v0, v1}, Lait/podka/c/am;-><init>(Lait/podka/c/al;Landroid/widget/AdapterView$AdapterContextMenuInfo;Landroid/content/ContentResolver;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    goto :goto_27

    :sswitch_59
    const-string v0, "action"

    const/4 v3, 0x7

    invoke-virtual {v2, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Lait/podka/c/an;

    invoke-direct {v2, p0, v1}, Lait/podka/c/an;-><init>(Lait/podka/c/al;Landroid/content/ContentResolver;)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto :goto_27

    :sswitch_data_72
    .sparse-switch
        0x60 -> :sswitch_32
        0x61 -> :sswitch_45
        0x62 -> :sswitch_59
        0x69 -> :sswitch_4b
        0x73 -> :sswitch_2c
    .end sparse-switch
.end method

.method public final a_()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/al;->a:Lait/podka/a/s;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lait/podka/a/s;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final b(I)Landroid/support/v4/content/f;
    .registers 9

    const/4 v3, 0x0

    new-instance v0, Landroid/support/v4/content/c;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    sget-object v2, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v4, "enc_queue IS NOT NULL AND enc_queue != \'\'"

    const-string v6, "enc_queue ASC"

    move-object v5, v3

    invoke-direct/range {v0 .. v6}, Landroid/support/v4/content/c;-><init>(Landroid/content/Context;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .registers 7

    const/4 v2, 0x0

    const-string v0, "Playlist"

    invoke-interface {p1, v0}, Landroid/view/ContextMenu;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/ContextMenu;

    const/16 v0, 0x60

    const-string v1, "Play"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x61

    const-string v1, "Remove"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x69

    const-string v1, "Remove & Delete"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x73

    const-string v1, "Reset position"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x62

    const-string v1, "Clear Playlist"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    return-void
.end method
