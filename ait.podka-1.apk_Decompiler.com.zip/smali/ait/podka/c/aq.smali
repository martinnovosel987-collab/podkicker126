###### Class ait.podka.c.aq (ait.podka.c.aq)
.class final Lait/podka/c/aq;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field final synthetic a:Lait/podka/c/ap;

.field private b:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lait/podka/c/ap;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/aq;->a:Lait/podka/c/ap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private a(Ljava/io/File;)V
    .registers 8

    if-eqz p1, :cond_18

    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_18

    invoke-virtual {p1}, Ljava/io/File;->isHidden()Z

    move-result v0

    if-nez v0, :cond_18

    invoke-virtual {p1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_18

    array-length v2, v1

    const/4 v0, 0x0

    :goto_16
    if-lt v0, v2, :cond_19

    :cond_18
    return-void

    :cond_19
    aget-object v3, v1, v0

    if-eqz v3, :cond_34

    invoke-virtual {v3}, Ljava/io/File;->isHidden()Z

    move-result v4

    if-nez v4, :cond_34

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "opml"

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_34

    iget-object v4, p0, Lait/podka/c/aq;->b:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_34
    invoke-direct {p0, v3}, Lait/podka/c/aq;->a(Ljava/io/File;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_16
.end method


# virtual methods
.method public final synthetic call()Ljava/lang/Object;
    .registers 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lait/podka/c/aq;->b:Ljava/util/ArrayList;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v0

    invoke-static {}, Landroid/os/Environment;->getRootDirectory()Ljava/io/File;

    move-result-object v1

    if-eqz v0, :cond_14

    invoke-direct {p0, v0}, Lait/podka/c/aq;->a(Ljava/io/File;)V

    :cond_14
    if-eqz v1, :cond_19

    invoke-direct {p0, v1}, Lait/podka/c/aq;->a(Ljava/io/File;)V

    :cond_19
    iget-object v0, p0, Lait/podka/c/aq;->b:Ljava/util/ArrayList;

    return-object v0
.end method
