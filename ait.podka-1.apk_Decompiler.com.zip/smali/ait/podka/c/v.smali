###### Class ait.podka.c.v (ait.podka.c.v)
.class final Lait/podka/c/v;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/s;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lait/podka/c/s;Landroid/app/Activity;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/v;->a:Lait/podka/c/s;

    iput-object p2, p0, Lait/podka/c/v;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 8

    iget-object v0, p0, Lait/podka/c/v;->a:Lait/podka/c/s;

    invoke-static {v0}, Lait/podka/c/s;->a(Lait/podka/c/s;)Lait/podka/a/m;

    move-result-object v1

    monitor-enter v1

    :try_start_7
    iget-object v0, p0, Lait/podka/c/v;->b:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v2, p0, Lait/podka/c/v;->a:Lait/podka/c/s;

    invoke-static {v2}, Lait/podka/c/s;->a(Lait/podka/c/s;)Lait/podka/a/m;

    move-result-object v2

    invoke-virtual {v2}, Lait/podka/a/m;->a()Ljava/util/Set;

    move-result-object v2

    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const-string v4, "enc_listened"

    const/16 v5, 0x64

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    sget-object v4, Lait/podka/database/e;->a:Landroid/net/Uri;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "enc_parent IN ("

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, ","

    invoke-static {v6, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, ")"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    invoke-virtual {v0, v4, v3, v2, v5}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    monitor-exit v1
    :try_end_49
    .catchall {:try_start_7 .. :try_end_49} :catchall_4a

    return-void

    :catchall_4a
    move-exception v0

    monitor-exit v1

    throw v0
.end method
