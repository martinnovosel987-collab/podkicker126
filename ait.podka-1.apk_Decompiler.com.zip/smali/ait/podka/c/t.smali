###### Class ait.podka.c.t (ait.podka.c.t)
.class final Lait/podka/c/t;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/s;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/AdapterView$AdapterContextMenuInfo;


# direct methods
.method constructor <init>(Lait/podka/c/s;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V
    .registers 4

    iput-object p1, p0, Lait/podka/c/t;->a:Lait/podka/c/s;

    iput-object p2, p0, Lait/podka/c/t;->b:Landroid/app/Activity;

    iput-object p3, p0, Lait/podka/c/t;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    iget-object v0, p0, Lait/podka/c/t;->b:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Lait/podka/c/t;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v1, v1, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const-string v4, "enc_listened"

    const/16 v5, 0x64

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    sget-object v4, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v5, "enc_parent = ?"

    const/4 v6, 0x1

    new-array v6, v6, [Ljava/lang/String;

    const/4 v7, 0x0

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v6, v7

    invoke-virtual {v0, v4, v3, v5, v6}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    return-void
.end method
