###### Class ait.podka.c.at (ait.podka.c.at)
.class final Lait/podka/c/at;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/c/ap;


# direct methods
.method private constructor <init>(Lait/podka/c/ap;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/ap;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/at;-><init>(Lait/podka/c/ap;)V

    return-void
.end method

.method static synthetic a(Lait/podka/c/at;[Ljava/lang/Object;)V
    .registers 2

    invoke-virtual {p0, p1}, Lait/podka/c/at;->publishProgress([Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, [Ljava/lang/String;

    new-instance v0, Lait/podka/b/b;

    iget-object v1, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    invoke-virtual {v1}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lait/podka/b/b;-><init>(Landroid/content/Context;)V

    new-instance v1, Lait/podka/c/au;

    invoke-direct {v1, p0}, Lait/podka/c/au;-><init>(Lait/podka/c/at;)V

    invoke-virtual {v0, v1}, Lait/podka/b/b;->addObserver(Ljava/util/Observer;)V

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-virtual {v0, v1}, Lait/podka/b/b;->a(Ljava/lang/String;)V

    invoke-virtual {v0}, Lait/podka/b/b;->deleteObservers()V

    const/4 v0, 0x0

    return-object v0
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Z)V

    return-void
.end method

.method protected final onPreExecute()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Z)V

    return-void
.end method

.method protected final varargs synthetic onProgressUpdate([Ljava/lang/Object;)V
    .registers 6

    check-cast p1, [Landroid/os/Message;

    const/4 v0, 0x0

    aget-object v1, p1, v0

    iget-object v0, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    if-eqz v0, :cond_28

    iget v0, v1, Landroid/os/Message;->what:I

    if-eqz v0, :cond_16

    iget v0, v1, Landroid/os/Message;->what:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_28

    :cond_16
    iget-object v0, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v2

    iget-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    invoke-static {v2, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_28
    iget-object v2, p0, Lait/podka/c/at;->a:Lait/podka/c/ap;

    iget-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-static {v2, v0}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/os/Message;->recycle()V

    return-void
.end method
