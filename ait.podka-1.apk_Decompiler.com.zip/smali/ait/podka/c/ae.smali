###### Class ait.podka.c.ae (ait.podka.c.ae)
.class final Lait/podka/c/ae;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/c/ab;

.field private b:J

.field private c:J

.field private d:I

.field private e:Ljava/util/Set;


# direct methods
.method private constructor <init>(Lait/podka/c/ab;)V
    .registers 4

    const-wide/16 v0, 0x0

    iput-object p1, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-wide v0, p0, Lait/podka/c/ae;->b:J

    iput-wide v0, p0, Lait/podka/c/ae;->c:J

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/ab;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/ae;-><init>(Lait/podka/c/ab;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-virtual {v0}, Lait/podka/c/ab;->p()Z

    move-result v0

    if-nez v0, :cond_e

    :cond_d
    :goto_d
    return-object v2

    :cond_e
    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-virtual {v0}, Lait/podka/c/ab;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v7

    invoke-virtual {v7}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-static {v0}, Lait/podka/database/a;->b(Landroid/content/ContentResolver;)Ljava/util/Set;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/ae;->e:Ljava/util/Set;

    const-string v3, "_id = ?"

    new-array v4, v9, [Ljava/lang/String;

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-wide v0, v0, Lait/podka/c/ab;->a:J

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v4, v8

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "_id"

    aput-object v1, v0, v8

    const-string v1, "ent_pubtime"

    aput-object v1, v0, v9

    const-string v1, "ent_title"

    aput-object v1, v0, v10

    const-string v1, "ent_description"

    aput-object v1, v0, v11

    invoke-virtual {v7}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/f;->a:Landroid/net/Uri;

    move-object v5, v2

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v6

    if-eqz v6, :cond_d

    invoke-interface {v6}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_d

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget v0, v0, Lait/podka/c/ab;->j:I

    if-ne v0, v10, :cond_90

    const-string v3, "ch_title = ?"

    new-array v4, v9, [Ljava/lang/String;

    const-string v0, "ch_title"

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v4, v8

    :cond_68
    :goto_68
    const-string v5, "ent_pubtime DESC"

    new-array v2, v11, [Ljava/lang/String;

    const-string v0, "_id"

    aput-object v0, v2, v8

    const-string v0, "ent_pubtime"

    aput-object v0, v2, v9

    const-string v0, "ch_title"

    aput-object v0, v2, v10

    sget-object v0, Lait/podka/database/f;->a:Landroid/net/Uri;

    invoke-virtual {v7}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/f;->a:Landroid/net/Uri;

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    :goto_84
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-nez v0, :cond_99

    :goto_8a
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    move-object v2, v6

    goto/16 :goto_d

    :cond_90
    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget v0, v0, Lait/podka/c/ab;->j:I

    if-ne v0, v9, :cond_68

    move-object v4, v2

    move-object v3, v2

    goto :goto_68

    :cond_99
    invoke-interface {v2, v8}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    iget-object v3, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-wide v3, v3, Lait/podka/c/ab;->a:J

    cmp-long v0, v0, v3

    if-eqz v0, :cond_ac

    invoke-interface {v2, v8}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    iput-wide v0, p0, Lait/podka/c/ae;->c:J

    goto :goto_84

    :cond_ac
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-eqz v0, :cond_c1

    invoke-interface {v2, v8}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    :goto_b6
    iput-wide v0, p0, Lait/podka/c/ae;->b:J

    invoke-interface {v2}, Landroid/database/Cursor;->getPosition()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lait/podka/c/ae;->d:I

    goto :goto_8a

    :cond_c1
    const-wide/16 v0, 0x0

    goto :goto_b6
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 10

    const-wide/16 v6, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    check-cast p1, Landroid/database/Cursor;

    if-eqz p1, :cond_10

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-virtual {v0}, Lait/podka/c/ab;->p()Z

    move-result v0

    if-nez v0, :cond_11

    :cond_10
    :goto_10
    return-void

    :cond_11
    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-wide v3, p0, Lait/podka/c/ae;->c:J

    iput-wide v3, v0, Lait/podka/c/ab;->h:J

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-wide v3, p0, Lait/podka/c/ae;->b:J

    iput-wide v3, v0, Lait/podka/c/ab;->i:J

    iget-wide v3, p0, Lait/podka/c/ae;->c:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    iget-wide v3, p0, Lait/podka/c/ae;->b:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    const-string v0, "ent_title"

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-object v3, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-object v3, v3, Lait/podka/c/ab;->b:Landroid/widget/TextView;

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v3, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-object v3, v3, Lait/podka/c/ab;->c:Landroid/widget/TextView;

    const-string v4, "ent_description"

    invoke-interface {p1, v4}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v4

    invoke-interface {p1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    iget-object v3, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-static {v3, v1}, Lait/podka/c/ab;->a(Lait/podka/c/ab;Z)V

    if-eqz v0, :cond_ab

    iget-object v3, p0, Lait/podka/c/ae;->e:Ljava/util/Set;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v3, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ab

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-object v0, v0, Lait/podka/c/ab;->e:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V

    :goto_6a
    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-object v3, v0, Lait/podka/c/ab;->f:Landroid/widget/Button;

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-wide v4, v0, Lait/podka/c/ab;->i:J

    cmp-long v0, v4, v6

    if-eqz v0, :cond_b3

    move v0, v1

    :goto_77
    invoke-virtual {v3, v0}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-object v0, v0, Lait/podka/c/ab;->g:Landroid/widget/Button;

    iget-object v3, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-wide v3, v3, Lait/podka/c/ab;->h:J

    cmp-long v3, v3, v6

    if-eqz v3, :cond_b5

    :goto_86
    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-static {v0}, Lait/podka/c/ab;->a(Lait/podka/c/ab;)Z

    move-result v0

    if-eqz v0, :cond_10

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    invoke-virtual {v0}, Lait/podka/c/ab;->n()Landroid/support/v4/app/m;

    move-result-object v0

    const v1, 0x7f0b002f

    invoke-virtual {v0, v1}, Landroid/support/v4/app/m;->a(I)Landroid/support/v4/app/Fragment;

    move-result-object v0

    instance-of v1, v0, Lait/podka/c/s;

    if-eqz v1, :cond_10

    check-cast v0, Lait/podka/c/s;

    iget v1, p0, Lait/podka/c/ae;->d:I

    invoke-virtual {v0, v1}, Lait/podka/c/s;->a(I)V

    goto/16 :goto_10

    :cond_ab
    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    iget-object v0, v0, Lait/podka/c/ab;->e:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    goto :goto_6a

    :cond_b3
    move v0, v2

    goto :goto_77

    :cond_b5
    move v1, v2

    goto :goto_86
.end method

.method protected final onPreExecute()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/ae;->a:Lait/podka/c/ab;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/ab;->a(Lait/podka/c/ab;Z)V

    return-void
.end method
