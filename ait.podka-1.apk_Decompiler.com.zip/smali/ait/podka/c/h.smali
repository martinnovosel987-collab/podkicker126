###### Class ait.podka.c.h (ait.podka.c.h)
.class final Lait/podka/c/h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/g;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lait/podka/c/g;Landroid/app/Activity;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/h;->a:Lait/podka/c/g;

    iput-object p2, p0, Lait/podka/c/h;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/c/h;->b:Landroid/app/Activity;

    const-string v1, "Podcast deleted"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
