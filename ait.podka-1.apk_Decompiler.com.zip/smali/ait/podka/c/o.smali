###### Class ait.podka.c.o (ait.podka.c.o)
.class final Lait/podka/c/o;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/i;


# direct methods
.method constructor <init>(Lait/podka/c/i;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/o;->a:Lait/podka/c/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget-object v0, p0, Lait/podka/c/o;->a:Lait/podka/c/i;

    invoke-virtual {v0}, Lait/podka/c/i;->d()V

    return-void
.end method
