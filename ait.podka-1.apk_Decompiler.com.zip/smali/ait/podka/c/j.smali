###### Class ait.podka.c.j (ait.podka.c.j)
.class final Lait/podka/c/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/i;

.field private final synthetic b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

.field private final synthetic c:Lait/podka/a/l;


# direct methods
.method constructor <init>(Lait/podka/c/i;Landroid/widget/AdapterView$AdapterContextMenuInfo;Lait/podka/a/l;)V
    .registers 4

    iput-object p1, p0, Lait/podka/c/j;->a:Lait/podka/c/i;

    iput-object p2, p0, Lait/podka/c/j;->b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iput-object p3, p0, Lait/podka/c/j;->c:Lait/podka/a/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/c/j;->a:Lait/podka/c/i;

    invoke-virtual {v0}, Lait/podka/c/i;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Lait/podka/c/j;->b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v1, v1, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v0, v1, v2}, Lait/podka/database/a;->b(Landroid/content/ContentResolver;J)V

    :try_start_11
    iget-object v0, p0, Lait/podka/c/j;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->r:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    sput v0, Lait/podka/download/a;->b:I

    new-instance v0, Ljava/io/File;

    sget-object v1, Lait/podka/Podka;->g:Ljava/io/File;

    iget-object v2, p0, Lait/podka/c/j;->c:Lait/podka/a/l;

    iget-object v2, v2, Lait/podka/a/l;->r:Ljava/lang/String;

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    new-instance v0, Ljava/io/File;

    sget-object v1, Lait/podka/Podka;->f:Ljava/io/File;

    iget-object v2, p0, Lait/podka/c/j;->c:Lait/podka/a/l;

    iget-object v2, v2, Lait/podka/a/l;->r:Ljava/lang/String;

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_3b} :catch_3c

    :goto_3b
    return-void

    :catch_3c
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_3b
.end method
