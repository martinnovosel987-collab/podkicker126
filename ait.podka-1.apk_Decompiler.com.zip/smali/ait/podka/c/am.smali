###### Class ait.podka.c.am (ait.podka.c.am)
.class final Lait/podka/c/am;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/al;

.field private final synthetic b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

.field private final synthetic c:Landroid/content/ContentResolver;


# direct methods
.method constructor <init>(Lait/podka/c/al;Landroid/widget/AdapterView$AdapterContextMenuInfo;Landroid/content/ContentResolver;)V
    .registers 4

    iput-object p1, p0, Lait/podka/c/am;->a:Lait/podka/c/al;

    iput-object p2, p0, Lait/podka/c/am;->b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iput-object p3, p0, Lait/podka/c/am;->c:Landroid/content/ContentResolver;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/c/am;->b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v0, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    iget-object v2, p0, Lait/podka/c/am;->c:Landroid/content/ContentResolver;

    invoke-static {v0, v1, v2}, Lait/podka/database/a;->b(JLandroid/content/ContentResolver;)V

    iget-object v0, p0, Lait/podka/c/am;->c:Landroid/content/ContentResolver;

    iget-object v1, p0, Lait/podka/c/am;->b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v1, v1, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v0, v1, v2}, Lait/podka/database/a;->b(Landroid/content/ContentResolver;J)V

    iget-object v0, p0, Lait/podka/c/am;->c:Landroid/content/ContentResolver;

    iget-object v1, p0, Lait/podka/c/am;->b:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v1, v1, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-static {v0, v1, v2}, Lait/podka/database/a;->c(Landroid/content/ContentResolver;J)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/io/File;

    sget-object v2, Lait/podka/Podka;->g:Ljava/io/File;

    invoke-direct {v1, v2, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    return-void
.end method
