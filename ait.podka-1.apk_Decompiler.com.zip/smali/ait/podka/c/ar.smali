###### Class ait.podka.c.ar (ait.podka.c.ar)
.class final Lait/podka/c/ar;
.super Landroid/os/AsyncTask;


# instance fields
.field a:Landroid/support/v4/app/FragmentActivity;

.field final synthetic b:Lait/podka/c/ap;


# direct methods
.method private constructor <init>(Lait/podka/c/ap;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/ap;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/ar;-><init>(Lait/podka/c/ap;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    new-instance v2, Lait/podka/b/b;

    iget-object v0, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v2, v0}, Lait/podka/b/b;-><init>(Landroid/content/Context;)V

    iget-object v0, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    invoke-static {v0}, Lait/podka/c/ap;->b(Lait/podka/c/ap;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1d
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_25

    const/4 v0, 0x0

    return-object v0

    :cond_25
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v1, 0x1

    new-array v4, v1, [Ljava/lang/String;

    const/4 v5, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v1, "subscribing:\n"

    invoke-direct {v6, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v4, v5

    invoke-virtual {p0, v4}, Lait/podka/c/ar;->publishProgress([Ljava/lang/Object;)V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    invoke-virtual {v2, v1}, Lait/podka/b/b;->c(Ljava/lang/String;)V

    goto :goto_1d
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 6

    iget-object v0, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Z)V

    iget-object v0, p0, Lait/podka/c/ar;->a:Landroid/support/v4/app/FragmentActivity;

    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lait/podka/c/ar;->a:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v2}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lait/podka/services/Refresh;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void
.end method

.method protected final onPreExecute()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Z)V

    iget-object v0, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/ar;->a:Landroid/support/v4/app/FragmentActivity;

    return-void
.end method

.method protected final varargs synthetic onProgressUpdate([Ljava/lang/Object;)V
    .registers 4

    check-cast p1, [Ljava/lang/String;

    iget-object v0, p0, Lait/podka/c/ar;->b:Lait/podka/c/ap;

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Ljava/lang/String;)V

    return-void
.end method
