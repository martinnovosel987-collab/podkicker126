###### Class ait.podka.c.u (ait.podka.c.u)
.class final Lait/podka/c/u;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/s;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lait/podka/c/s;Landroid/app/Activity;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/u;->a:Lait/podka/c/s;

    iput-object p2, p0, Lait/podka/c/u;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    const/4 v3, 0x0

    new-instance v0, Lait/podka/c/aa;

    iget-object v1, p0, Lait/podka/c/u;->a:Lait/podka/c/s;

    invoke-direct {v0, v1, v3}, Lait/podka/c/aa;-><init>(Lait/podka/c/s;B)V

    const/4 v1, 0x1

    new-array v1, v1, [Landroid/content/ContentResolver;

    iget-object v2, p0, Lait/podka/c/u;->b:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lait/podka/c/aa;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
