###### Class ait.podka.c.av (ait.podka.c.av)
.class public final Lait/podka/c/av;
.super Landroid/support/v4/app/d;


# instance fields
.field final synthetic a:Lait/podka/c/ap;


# direct methods
.method public constructor <init>(Lait/podka/c/ap;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/av;->a:Lait/podka/c/ap;

    invoke-direct {p0}, Landroid/support/v4/app/d;-><init>()V

    return-void
.end method

.method static synthetic a(Lait/podka/c/av;)Lait/podka/c/ap;
    .registers 2

    iget-object v0, p0, Lait/podka/c/av;->a:Lait/podka/c/ap;

    return-object v0
.end method


# virtual methods
.method public final d()Landroid/app/Dialog;
    .registers 4

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lait/podka/c/av;->a(Z)V

    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Found a total of "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lait/podka/c/av;->a:Lait/podka/c/ap;

    invoke-static {v2}, Lait/podka/c/ap;->b(Lait/podka/c/ap;)Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " feeds in OPML-files on your device. Do you want to import?"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Yes"

    new-instance v2, Lait/podka/c/aw;

    invoke-direct {v2, p0}, Lait/podka/c/aw;-><init>(Lait/podka/c/av;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "No"

    new-instance v2, Lait/podka/c/ax;

    invoke-direct {v2, p0}, Lait/podka/c/ax;-><init>(Lait/podka/c/av;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    return-object v0
.end method
