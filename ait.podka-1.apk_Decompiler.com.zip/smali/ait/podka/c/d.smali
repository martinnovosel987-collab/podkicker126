###### Class ait.podka.c.d (ait.podka.c.d)
.class final Lait/podka/c/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/c;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/AdapterView$AdapterContextMenuInfo;


# direct methods
.method constructor <init>(Lait/podka/c/c;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V
    .registers 4

    iput-object p1, p0, Lait/podka/c/d;->a:Lait/podka/c/c;

    iput-object p2, p0, Lait/podka/c/d;->b:Landroid/app/Activity;

    iput-object p3, p0, Lait/podka/c/d;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    const/4 v4, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lait/podka/c/d;->b:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v5, "_id"

    aput-object v5, v2, v3

    const-string v3, "ch_feedlink"

    aput-object v3, v2, v7

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "_id = "

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, p0, Lait/podka/c/d;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v5, v5, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move-object v5, v4

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    invoke-interface {v0, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    iget-object v0, p0, Lait/podka/c/d;->b:Landroid/app/Activity;

    new-instance v2, Lait/podka/c/e;

    invoke-direct {v2, p0, v1}, Lait/podka/c/e;-><init>(Lait/podka/c/d;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method
