###### Class ait.podka.c.aa (ait.podka.c.aa)
.class final Lait/podka/c/aa;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/c/s;

.field private b:Ljava/util/Map;

.field private c:Ljava/util/Set;


# direct methods
.method private constructor <init>(Lait/podka/c/s;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/aa;->a:Lait/podka/c/s;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/s;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/aa;-><init>(Lait/podka/c/s;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    const/4 v6, 0x0

    const/4 v5, 0x0

    check-cast p1, [Landroid/content/ContentResolver;

    aget-object v0, p1, v5

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const-string v2, "ait.podka.database.PodcastProvider"

    invoke-virtual {v0, v2}, Landroid/content/ContentResolver;->acquireContentProviderClient(Ljava/lang/String;)Landroid/content/ContentProviderClient;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/ContentProviderClient;->getLocalContentProvider()Landroid/content/ContentProvider;

    move-result-object v0

    check-cast v0, Lait/podka/database/PodcastProvider;

    invoke-virtual {v0}, Lait/podka/database/PodcastProvider;->a()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const-string v3, "select enc_parent as parent, AVG(enc_listened) as average from enclosure group by parent having average >= 1"

    invoke-virtual {v0, v3, v6}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    :goto_21
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3

    if-nez v3, :cond_38

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    invoke-virtual {v2}, Landroid/content/ContentProviderClient;->release()Z

    iput-object v1, p0, Lait/podka/c/aa;->b:Ljava/util/Map;

    aget-object v0, p1, v5

    invoke-static {v0}, Lait/podka/database/a;->b(Landroid/content/ContentResolver;)Ljava/util/Set;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/aa;->c:Ljava/util/Set;

    return-object v6

    :cond_38
    invoke-interface {v0, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v4, 0x1

    invoke-interface {v0, v4}, Landroid/database/Cursor;->getInt(I)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_21
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lait/podka/c/aa;->a:Lait/podka/c/s;

    invoke-static {v0}, Lait/podka/c/s;->a(Lait/podka/c/s;)Lait/podka/a/m;

    move-result-object v0

    iget-object v1, p0, Lait/podka/c/aa;->c:Ljava/util/Set;

    invoke-virtual {v0, v1}, Lait/podka/a/m;->a(Ljava/util/Set;)V

    iget-object v0, p0, Lait/podka/c/aa;->a:Lait/podka/c/s;

    invoke-static {v0}, Lait/podka/c/s;->a(Lait/podka/c/s;)Lait/podka/a/m;

    move-result-object v0

    iget-object v1, p0, Lait/podka/c/aa;->b:Ljava/util/Map;

    invoke-virtual {v0, v1}, Lait/podka/a/m;->a(Ljava/util/Map;)V

    :try_start_16
    iget-object v0, p0, Lait/podka/c/aa;->a:Lait/podka/c/s;

    invoke-static {v0}, Lait/podka/c/s;->a(Lait/podka/c/s;)Lait/podka/a/m;

    move-result-object v0

    invoke-virtual {v0}, Lait/podka/a/m;->notifyDataSetChanged()V
    :try_end_1f
    .catch Ljava/lang/IllegalStateException; {:try_start_16 .. :try_end_1f} :catch_20

    :goto_1f
    return-void

    :catch_20
    move-exception v0

    goto :goto_1f
.end method
