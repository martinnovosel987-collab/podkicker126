###### Class ait.podka.c.e (ait.podka.c.e)
.class final Lait/podka/c/e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/d;

.field private final synthetic b:Ljava/lang/String;


# direct methods
.method constructor <init>(Lait/podka/c/d;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/e;->a:Lait/podka/c/d;

    iput-object p2, p0, Lait/podka/c/e;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.SEND"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "text/plain"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "android.intent.extra.TEXT"

    iget-object v2, p0, Lait/podka/c/e;->b:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v1, p0, Lait/podka/c/e;->a:Lait/podka/c/d;

    iget-object v1, v1, Lait/podka/c/d;->a:Lait/podka/c/c;

    const-string v2, "Share with"

    invoke-static {v0, v2}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v1, v0}, Lait/podka/c/c;->a(Landroid/content/Intent;)V

    return-void
.end method
