###### Class ait.podka.c.c (ait.podka.c.c)
.class public Lait/podka/c/c;
.super Landroid/support/v4/app/aa;

# interfaces
.implements Landroid/support/v4/app/ae;


# static fields
.field static final a:[Ljava/lang/String;


# instance fields
.field private Z:I

.field private aa:I

.field private ab:Z

.field private j:Lait/podka/a/e;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "_id"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "ch_title"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "ch_imageurl"

    aput-object v2, v0, v1

    sput-object v0, Lait/podka/c/c;->a:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/app/aa;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 1

    invoke-super {p0}, Landroid/support/v4/app/aa;->a()V

    return-void
.end method

.method public final a(I)V
    .registers 4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x8

    if-lt v0, v1, :cond_d

    invoke-virtual {p0}, Lait/podka/c/c;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/ListView;->smoothScrollToPosition(I)V

    :cond_d
    iput p1, p0, Lait/podka/c/c;->Z:I

    return-void
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lait/podka/c/c;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnCreateContextMenuListener(Landroid/view/View$OnCreateContextMenuListener;)V

    new-instance v0, Lait/podka/a/e;

    iget-object v3, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-direct {v0, v3}, Lait/podka/a/e;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/c/c;->j:Lait/podka/a/e;

    iget-object v0, p0, Lait/podka/c/c;->j:Lait/podka/a/e;

    invoke-virtual {p0, v0}, Lait/podka/c/c;->a(Landroid/widget/ListAdapter;)V

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    const v3, 0x7f0b0031

    invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_56

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_56

    move v0, v1

    :goto_2c
    iput-boolean v0, p0, Lait/podka/c/c;->ab:Z

    invoke-virtual {p0}, Lait/podka/c/c;->G()Landroid/widget/ListView;

    move-result-object v0

    iget v3, p0, Lait/podka/c/c;->Z:I

    iget v4, p0, Lait/podka/c/c;->aa:I

    invoke-virtual {v0, v3, v4}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    invoke-virtual {p0, v2}, Lait/podka/c/c;->a(Z)V

    invoke-virtual {p0}, Lait/podka/c/c;->r()Landroid/support/v4/app/ad;

    move-result-object v0

    invoke-virtual {v0, v2, p0}, Landroid/support/v4/app/ad;->a(ILandroid/support/v4/app/ae;)Landroid/support/v4/content/f;

    invoke-virtual {p0}, Lait/podka/c/c;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setFastScrollEnabled(Z)V

    iget-boolean v0, p0, Lait/podka/c/c;->ab:Z

    if-eqz v0, :cond_55

    invoke-virtual {p0}, Lait/podka/c/c;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setChoiceMode(I)V

    :cond_55
    return-void

    :cond_56
    move v0, v2

    goto :goto_2c
.end method

.method public final a(Landroid/view/View;IJ)V
    .registers 9

    iput p2, p0, Lait/podka/c/c;->Z:I

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    iput v0, p0, Lait/podka/c/c;->aa:I

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/s;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v2}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "action"

    const/4 v3, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "id"

    invoke-virtual {v1, v2, p3, p4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    iget-boolean v1, p0, Lait/podka/c/c;->ab:Z

    if-eqz v1, :cond_41

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    const v2, 0x7f0b0031

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    :goto_40
    return-void

    :cond_41
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    const v2, 0x7f0b002f

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const-string v1, "entries"

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_40
.end method

.method public final synthetic a(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroid/database/Cursor;

    iget-object v0, p0, Lait/podka/c/c;->j:Lait/podka/a/e;

    invoke-virtual {v0, p1}, Lait/podka/a/e;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final a(Landroid/view/MenuItem;)Z
    .registers 8

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    invoke-interface {p1}, Landroid/view/MenuItem;->getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    check-cast v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v2

    sparse-switch v2, :sswitch_data_9c

    :goto_16
    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/view/MenuItem;)Z

    move-result v0

    return v0

    :sswitch_1b
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lait/podka/c/a;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    invoke-static {v1, v2, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v1

    iget-object v2, v1, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v3, "id"

    iget-wide v4, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    iget-boolean v0, p0, Lait/podka/c/c;->ab:Z

    if-eqz v0, :cond_4e

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v0

    const v2, 0x7f0b0031

    invoke-virtual {v0, v2, v1}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_16

    :cond_4e
    iget-object v0, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v0

    const v2, 0x7f0b002f

    invoke-virtual {v0, v2, v1}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const-string v1, "channeldetails"

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_16

    :sswitch_65
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lait/podka/c/d;

    invoke-direct {v3, p0, v1, v0}, Lait/podka/c/d;-><init>(Lait/podka/c/c;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    goto :goto_16

    :sswitch_73
    new-instance v2, Landroid/app/AlertDialog$Builder;

    iget-object v3, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-direct {v2, v3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v3, "Delete podcast?"

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const-string v3, "No"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const-string v3, "Yes"

    new-instance v4, Lait/podka/c/f;

    invoke-direct {v4, p0, v1, v0}, Lait/podka/c/f;-><init>(Lait/podka/c/c;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V

    invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    goto/16 :goto_16

    nop

    :sswitch_data_9c
    .sparse-switch
        0x51 -> :sswitch_65
        0x52 -> :sswitch_73
        0x71 -> :sswitch_1b
    .end sparse-switch
.end method

.method public final a_()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/c;->j:Lait/podka/a/e;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lait/podka/a/e;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final b(I)Landroid/support/v4/content/f;
    .registers 9

    const/4 v4, 0x0

    new-instance v0, Landroid/support/v4/content/c;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    sget-object v2, Lait/podka/database/d;->a:Landroid/net/Uri;

    sget-object v3, Lait/podka/c/c;->a:[Ljava/lang/String;

    const-string v6, "ch_title"

    move-object v5, v4

    invoke-direct/range {v0 .. v6}, Landroid/support/v4/content/c;-><init>(Landroid/content/Context;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v1, 0x1f4

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/content/c;->a(J)V

    return-object v0
.end method

.method public final b()V
    .registers 1

    invoke-super {p0}, Landroid/support/v4/app/aa;->b()V

    return-void
.end method

.method public final b(Landroid/os/Bundle;)V
    .registers 2

    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->b(Landroid/os/Bundle;)V

    return-void
.end method

.method public onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .registers 7

    const/4 v2, 0x0

    const/16 v0, 0x51

    const-string v1, "Share"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x71

    const-string v1, "Info"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x52

    const-string v1, "Delete"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    return-void
.end method
