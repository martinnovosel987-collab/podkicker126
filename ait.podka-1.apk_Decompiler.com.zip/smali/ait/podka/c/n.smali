###### Class ait.podka.c.n (ait.podka.c.n)
.class final Lait/podka/c/n;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/i;


# direct methods
.method constructor <init>(Lait/podka/c/i;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/n;->a:Lait/podka/c/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    iget-object v0, p0, Lait/podka/c/n;->a:Lait/podka/c/i;

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Lait/podka/c/i;->a(I)V

    return-void
.end method
