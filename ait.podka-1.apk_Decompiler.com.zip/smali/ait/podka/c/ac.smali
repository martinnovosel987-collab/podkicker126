###### Class ait.podka.c.ac (ait.podka.c.ac)
.class final Lait/podka/c/ac;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/ab;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lait/podka/c/ab;Landroid/app/Activity;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/ac;->a:Lait/podka/c/ab;

    iput-object p2, p0, Lait/podka/c/ac;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Lait/podka/c/ac;->a:Lait/podka/c/ab;

    iget-wide v0, v0, Lait/podka/c/ab;->a:J

    iget-object v2, p0, Lait/podka/c/ac;->b:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lait/podka/database/a;->a(JLandroid/content/ContentResolver;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    if-gtz v1, :cond_21

    iget-object v0, p0, Lait/podka/c/ac;->b:Landroid/app/Activity;

    new-instance v1, Lait/podka/c/ad;

    iget-object v2, p0, Lait/podka/c/ac;->b:Landroid/app/Activity;

    invoke-direct {v1, p0, v2}, Lait/podka/c/ad;-><init>(Lait/podka/c/ac;Landroid/app/Activity;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_20
    return-void

    :cond_21
    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lait/podka/c/ac;->b:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lait/podka/services/AudioService;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "action"

    const/16 v3, 0x9

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v2, "enclosureID"

    invoke-static {v0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    iget-object v0, p0, Lait/podka/c/ac;->b:Landroid/app/Activity;

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_20
.end method
