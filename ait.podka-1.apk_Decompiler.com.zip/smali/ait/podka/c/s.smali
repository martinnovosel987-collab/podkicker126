###### Class ait.podka.c.s (ait.podka.c.s)
.class public Lait/podka/c/s;
.super Landroid/support/v4/app/aa;

# interfaces
.implements Landroid/support/v4/app/ae;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "NewApi"
    }
.end annotation


# static fields
.field private static final j:[Ljava/lang/String;


# instance fields
.field private Z:I

.field private a:Lait/podka/a/m;

.field private aa:J

.field private ab:I

.field private ac:I

.field private ad:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "_id"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "ent_title"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "ent_pubtime"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "ent_parent"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "ch_title"

    aput-object v2, v0, v1

    sput-object v0, Lait/podka/c/s;->j:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/support/v4/app/aa;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lait/podka/c/s;->Z:I

    return-void
.end method

.method static synthetic a(Lait/podka/c/s;)Lait/podka/a/m;
    .registers 2

    iget-object v0, p0, Lait/podka/c/s;->a:Lait/podka/a/m;

    return-object v0
.end method


# virtual methods
.method public final a()V
    .registers 1

    invoke-super {p0}, Landroid/support/v4/app/aa;->a()V

    return-void
.end method

.method public final a(I)V
    .registers 4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x8

    if-lt v0, v1, :cond_d

    invoke-virtual {p0}, Lait/podka/c/s;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/ListView;->smoothScrollToPosition(I)V

    :cond_d
    iput p1, p0, Lait/podka/c/s;->ab:I

    return-void
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/os/Bundle;)V

    new-instance v0, Lait/podka/a/m;

    iget-object v3, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v0, v3}, Lait/podka/a/m;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/c/s;->a:Lait/podka/a/m;

    invoke-virtual {p0}, Lait/podka/c/s;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnCreateContextMenuListener(Landroid/view/View$OnCreateContextMenuListener;)V

    iget-object v0, p0, Lait/podka/c/s;->a:Lait/podka/a/m;

    invoke-virtual {p0, v0}, Lait/podka/c/s;->a(Landroid/widget/ListAdapter;)V

    new-instance v0, Lait/podka/c/aa;

    invoke-direct {v0, p0, v2}, Lait/podka/c/aa;-><init>(Lait/podka/c/s;B)V

    new-array v3, v1, [Landroid/content/ContentResolver;

    iget-object v4, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v4}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    aput-object v4, v3, v2

    invoke-virtual {v0, v3}, Lait/podka/c/aa;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    const v3, 0x7f0b0031

    invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_63

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_63

    move v0, v1

    :goto_42
    iput-boolean v0, p0, Lait/podka/c/s;->ad:Z

    invoke-virtual {p0}, Lait/podka/c/s;->G()Landroid/widget/ListView;

    move-result-object v0

    iget v3, p0, Lait/podka/c/s;->ab:I

    iget v4, p0, Lait/podka/c/s;->ac:I

    invoke-virtual {v0, v3, v4}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    invoke-virtual {p0, v2}, Lait/podka/c/s;->a(Z)V

    invoke-virtual {p0}, Lait/podka/c/s;->G()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setFastScrollEnabled(Z)V

    invoke-virtual {p0}, Lait/podka/c/s;->r()Landroid/support/v4/app/ad;

    move-result-object v0

    iget v1, p0, Lait/podka/c/s;->Z:I

    invoke-virtual {v0, v1, p0}, Landroid/support/v4/app/ad;->a(ILandroid/support/v4/app/ae;)Landroid/support/v4/content/f;

    return-void

    :cond_63
    move v0, v2

    goto :goto_42
.end method

.method public final a(Landroid/view/View;IJ)V
    .registers 9

    iput p2, p0, Lait/podka/c/s;->ab:I

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    iput v0, p0, Lait/podka/c/s;->ac:I

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    const-class v1, Lait/podka/c/ab;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v2}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "id"

    invoke-virtual {v1, v2, p3, p4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    iget-object v1, v0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v2, "action"

    iget v3, p0, Lait/podka/c/s;->Z:I

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    iget-boolean v1, p0, Lait/podka/c/s;->ad:Z

    if-eqz v1, :cond_3e

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    const v2, 0x7f0b0031

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    :goto_3d
    return-void

    :cond_3e
    iget-object v1, p0, Landroid/support/v4/app/Fragment;->C:Landroid/support/v4/app/o;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    const v2, 0x7f0b002f

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const-string v1, "entrydetails"

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_3d
.end method

.method public final synthetic a(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroid/database/Cursor;

    iget-object v0, p0, Lait/podka/c/s;->a:Lait/podka/a/m;

    invoke-virtual {v0, p1}, Lait/podka/a/m;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final a(Landroid/view/MenuItem;)Z
    .registers 11

    const-wide/16 v7, 0x12c

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    invoke-interface {p1}, Landroid/view/MenuItem;->getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    check-cast v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v2

    sparse-switch v2, :sswitch_data_9a

    :goto_18
    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->a(Landroid/view/MenuItem;)Z

    move-result v0

    return v0

    :sswitch_1d
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lait/podka/c/t;

    invoke-direct {v3, p0, v1, v0}, Lait/podka/c/t;-><init>(Lait/podka/c/s;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v2, Lait/podka/c/u;

    invoke-direct {v2, p0, v1}, Lait/podka/c/u;-><init>(Lait/podka/c/s;Landroid/app/Activity;)V

    invoke-virtual {v0, v2, v7, v8}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_18

    :sswitch_38
    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Lait/podka/c/v;

    invoke-direct {v2, p0, v1}, Lait/podka/c/v;-><init>(Lait/podka/c/s;Landroid/app/Activity;)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v2, Lait/podka/c/w;

    invoke-direct {v2, p0, v1}, Lait/podka/c/w;-><init>(Lait/podka/c/s;Landroid/app/Activity;)V

    invoke-virtual {v0, v2, v7, v8}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_18

    :sswitch_53
    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lait/podka/download/DownloadService;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v3, "action"

    const/4 v4, 0x1

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v3

    const-string v4, "id"

    iget-wide v5, v0, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v1, v2}, Landroid/app/Activity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v2, Lait/podka/c/x;

    invoke-direct {v2, p0, v1}, Lait/podka/c/x;-><init>(Lait/podka/c/s;Landroid/app/Activity;)V

    invoke-virtual {v0, v2, v7, v8}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_18

    :sswitch_7f
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lait/podka/c/y;

    invoke-direct {v3, p0, v0, v1}, Lait/podka/c/y;-><init>(Lait/podka/c/s;Landroid/widget/AdapterView$AdapterContextMenuInfo;Landroid/app/Activity;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    check-cast v0, Lait/podka/Podka;

    invoke-virtual {v0}, Lait/podka/Podka;->b()Lait/podka/menu/PodkaMenu;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Lait/podka/menu/PodkaMenu;->a(I)V

    goto :goto_18

    nop

    :sswitch_data_9a
    .sparse-switch
        0x55 -> :sswitch_53
        0x56 -> :sswitch_7f
        0x67 -> :sswitch_1d
        0x70 -> :sswitch_38
    .end sparse-switch
.end method

.method public final a_()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/s;->a:Lait/podka/a/m;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lait/podka/a/m;->b(Landroid/database/Cursor;)Landroid/database/Cursor;

    return-void
.end method

.method public final b(I)Landroid/support/v4/content/f;
    .registers 9

    const/4 v5, 0x0

    const-string v6, " ent_pubtime DESC"

    packed-switch p1, :pswitch_data_3c

    move-object v4, v5

    :goto_7
    new-instance v0, Landroid/support/v4/content/c;

    iget-object v1, p0, Landroid/support/v4/app/Fragment;->D:Landroid/support/v4/app/FragmentActivity;

    sget-object v2, Lait/podka/database/f;->a:Landroid/net/Uri;

    sget-object v3, Lait/podka/c/s;->j:[Ljava/lang/String;

    invoke-direct/range {v0 .. v6}, Landroid/support/v4/content/c;-><init>(Landroid/content/Context;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/content/c;->a(J)V

    return-object v0

    :pswitch_18
    const-string v4, "ent_parent = ?"

    const/4 v0, 0x1

    new-array v5, v0, [Ljava/lang/String;

    const/4 v0, 0x0

    iget-wide v1, p0, Lait/podka/c/s;->aa:J

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v5, v0

    goto :goto_7

    :pswitch_27
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, " LIMIT 200"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    move-object v4, v5

    goto :goto_7

    :pswitch_data_3c
    .packed-switch 0x1
        :pswitch_27
        :pswitch_18
    .end packed-switch
.end method

.method public final b()V
    .registers 1

    invoke-super {p0}, Landroid/support/v4/app/aa;->b()V

    return-void
.end method

.method public final b(Landroid/os/Bundle;)V
    .registers 4

    invoke-super {p0, p1}, Landroid/support/v4/app/aa;->b(Landroid/os/Bundle;)V

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v1, "action"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lait/podka/c/s;->Z:I

    iget-object v0, p0, Landroid/support/v4/app/Fragment;->r:Landroid/os/Bundle;

    const-string v1, "id"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    iput-wide v0, p0, Lait/podka/c/s;->aa:J

    return-void
.end method

.method public onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .registers 7

    const/4 v2, 0x0

    const/16 v0, 0x55

    const-string v1, "Download"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x56

    const-string v1, "Stream"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x67

    const-string v1, "Mark as listened"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v0, 0x70

    const-string v1, "Mark all as listened"

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/ContextMenu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    return-void
.end method
