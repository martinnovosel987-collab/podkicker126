###### Class ait.podka.c.m (ait.podka.c.m)
.class final Lait/podka/c/m;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/i;


# direct methods
.method constructor <init>(Lait/podka/c/i;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/m;->a:Lait/podka/c/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    iget-object v0, p0, Lait/podka/c/m;->a:Lait/podka/c/i;

    const/16 v1, 0x5f

    invoke-virtual {v0, v1}, Lait/podka/c/i;->a(I)V

    return-void
.end method
