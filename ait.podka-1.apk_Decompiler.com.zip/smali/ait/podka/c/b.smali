###### Class ait.podka.c.b (ait.podka.c.b)
.class final Lait/podka/c/b;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/c/a;

.field private b:Landroid/graphics/Bitmap;

.field private c:J

.field private d:J


# direct methods
.method private constructor <init>(Lait/podka/c/a;)V
    .registers 4

    const-wide/16 v0, 0x0

    iput-object p1, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-wide v0, p0, Lait/podka/c/b;->c:J

    iput-wide v0, p0, Lait/podka/c/b;->d:J

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/a;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/b;-><init>(Lait/podka/c/a;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    const/4 v7, 0x1

    const/4 v10, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-virtual {v0}, Lait/podka/c/a;->p()Z

    move-result v0

    if-nez v0, :cond_c

    :cond_b
    :goto_b
    return-object v2

    :cond_c
    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-virtual {v0}, Lait/podka/c/a;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v6

    const-string v3, "_id = ?"

    new-array v4, v7, [Ljava/lang/String;

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v0}, Lait/podka/c/a;->a(Lait/podka/c/a;)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v4, v10

    invoke-virtual {v6}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    move-object v5, v2

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v9

    invoke-interface {v9}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_b

    const-string v0, "ch_imageurl"

    invoke-interface {v9, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v9, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_53

    iget-object v1, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lait/podka/c/a;->a(Lait/podka/c/a;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lait/podka/c/b;->b:Landroid/graphics/Bitmap;

    :cond_53
    invoke-virtual {v6}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    sget-object v4, Lait/podka/database/d;->a:Landroid/net/Uri;

    const/4 v0, 0x2

    new-array v5, v0, [Ljava/lang/String;

    const-string v0, "_id"

    aput-object v0, v5, v10

    const-string v0, "ch_title"

    aput-object v0, v5, v7

    const-string v8, "ch_title ASC"

    move-object v6, v2

    move-object v7, v2

    invoke-virtual/range {v3 .. v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    :goto_6c
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-nez v0, :cond_77

    :goto_72
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    move-object v2, v9

    goto :goto_b

    :cond_77
    invoke-interface {v2, v10}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    iget-object v3, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v3}, Lait/podka/c/a;->a(Lait/podka/c/a;)J

    move-result-wide v3

    cmp-long v0, v0, v3

    if-eqz v0, :cond_8c

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    iput-wide v0, p0, Lait/podka/c/b;->d:J

    goto :goto_6c

    :cond_8c
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-eqz v0, :cond_a4

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    :goto_96
    iput-wide v0, p0, Lait/podka/c/b;->c:J

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-interface {v2}, Landroid/database/Cursor;->getPosition()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-static {v0, v1}, Lait/podka/c/a;->a(Lait/podka/c/a;I)V

    goto :goto_72

    :cond_a4
    const-wide/16 v0, 0x0

    goto :goto_96
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 10

    const-wide/16 v6, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    check-cast p1, Landroid/database/Cursor;

    if-eqz p1, :cond_a7

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-wide v3, p0, Lait/podka/c/b;->d:J

    invoke-static {v0, v3, v4}, Lait/podka/c/a;->a(Lait/podka/c/a;J)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-wide v3, p0, Lait/podka/c/b;->c:J

    invoke-static {v0, v3, v4}, Lait/podka/c/a;->b(Lait/podka/c/a;J)V

    iget-wide v3, p0, Lait/podka/c/b;->d:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    iget-wide v3, p0, Lait/podka/c/b;->c:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    const-string v0, "ch_title"

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-object v3, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-object v3, v3, Lait/podka/c/a;->a:Landroid/widget/TextView;

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-object v0, v0, Lait/podka/c/a;->b:Landroid/widget/TextView;

    const-string v3, "ch_description"

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-object v0, v0, Lait/podka/c/a;->d:Landroid/widget/TextView;

    const-string v3, "ch_weblink"

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-object v0, v0, Lait/podka/c/a;->e:Landroid/widget/ImageView;

    iget-object v3, p0, Lait/podka/c/b;->b:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v0, v1}, Lait/podka/c/a;->a(Lait/podka/c/a;Z)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-object v3, v0, Lait/podka/c/a;->g:Landroid/widget/Button;

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v0}, Lait/podka/c/a;->b(Lait/podka/c/a;)J

    move-result-wide v4

    cmp-long v0, v4, v6

    if-eqz v0, :cond_a8

    move v0, v1

    :goto_73
    invoke-virtual {v3, v0}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    iget-object v0, v0, Lait/podka/c/a;->h:Landroid/widget/Button;

    iget-object v3, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v3}, Lait/podka/c/a;->c(Lait/podka/c/a;)J

    move-result-wide v3

    cmp-long v3, v3, v6

    if-eqz v3, :cond_aa

    :goto_84
    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v0}, Lait/podka/c/a;->d(Lait/podka/c/a;)Z

    move-result v0

    if-eqz v0, :cond_a7

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-virtual {v0}, Lait/podka/c/a;->n()Landroid/support/v4/app/m;

    move-result-object v0

    const v1, 0x7f0b002f

    invoke-virtual {v0, v1}, Landroid/support/v4/app/m;->a(I)Landroid/support/v4/app/Fragment;

    move-result-object v0

    check-cast v0, Lait/podka/c/c;

    iget-object v1, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    invoke-static {v1}, Lait/podka/c/a;->e(Lait/podka/c/a;)I

    move-result v1

    invoke-virtual {v0, v1}, Lait/podka/c/c;->a(I)V

    :cond_a7
    return-void

    :cond_a8
    move v0, v2

    goto :goto_73

    :cond_aa
    move v1, v2

    goto :goto_84
.end method

.method protected final onPreExecute()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/b;->a:Lait/podka/c/a;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/a;->a(Lait/podka/c/a;Z)V

    return-void
.end method
