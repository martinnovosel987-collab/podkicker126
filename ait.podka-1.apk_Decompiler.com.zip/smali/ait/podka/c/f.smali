###### Class ait.podka.c.f (ait.podka.c.f)
.class final Lait/podka/c/f;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/c;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/AdapterView$AdapterContextMenuInfo;


# direct methods
.method constructor <init>(Lait/podka/c/c;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V
    .registers 4

    iput-object p1, p0, Lait/podka/c/f;->a:Lait/podka/c/c;

    iput-object p2, p0, Lait/podka/c/f;->b:Landroid/app/Activity;

    iput-object p3, p0, Lait/podka/c/f;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 7

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lait/podka/c/g;

    iget-object v2, p0, Lait/podka/c/f;->b:Landroid/app/Activity;

    iget-object v3, p0, Lait/podka/c/f;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    invoke-direct {v1, p0, v2, v3}, Lait/podka/c/g;-><init>(Lait/podka/c/f;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
