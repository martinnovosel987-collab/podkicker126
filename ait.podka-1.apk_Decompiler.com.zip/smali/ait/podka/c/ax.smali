###### Class ait.podka.c.ax (ait.podka.c.ax)
.class final Lait/podka/c/ax;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/av;


# direct methods
.method constructor <init>(Lait/podka/c/av;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/ax;->a:Lait/podka/c/av;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    return-void
.end method
