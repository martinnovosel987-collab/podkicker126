###### Class ait.podka.c.g (ait.podka.c.g)
.class final Lait/podka/c/g;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/f;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/AdapterView$AdapterContextMenuInfo;


# direct methods
.method constructor <init>(Lait/podka/c/f;Landroid/app/Activity;Landroid/widget/AdapterView$AdapterContextMenuInfo;)V
    .registers 4

    iput-object p1, p0, Lait/podka/c/g;->a:Lait/podka/c/f;

    iput-object p2, p0, Lait/podka/c/g;->b:Landroid/app/Activity;

    iput-object p3, p0, Lait/podka/c/g;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    const/4 v5, 0x0

    iget-object v0, p0, Lait/podka/c/g;->b:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lait/podka/c/g;->c:Landroid/widget/AdapterView$AdapterContextMenuInfo;

    iget-wide v3, v3, Landroid/widget/AdapterView$AdapterContextMenuInfo;->id:J

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/net/Uri;->withAppendedPath(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1, v5, v5}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I

    iget-object v0, p0, Lait/podka/c/g;->b:Landroid/app/Activity;

    new-instance v1, Lait/podka/c/h;

    iget-object v2, p0, Lait/podka/c/g;->b:Landroid/app/Activity;

    invoke-direct {v1, p0, v2}, Lait/podka/c/h;-><init>(Lait/podka/c/g;Landroid/app/Activity;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method
