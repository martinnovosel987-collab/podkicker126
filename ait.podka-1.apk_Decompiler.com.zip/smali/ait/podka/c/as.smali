###### Class ait.podka.c.as (ait.podka.c.as)
.class final Lait/podka/c/as;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/c/ap;


# direct methods
.method private constructor <init>(Lait/podka/c/ap;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/c/ap;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/c/as;-><init>(Lait/podka/c/ap;)V

    return-void
.end method

.method private varargs a()Ljava/lang/Void;
    .registers 7

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Lait/podka/b/i;

    iget-object v1, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-virtual {v1}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lait/podka/b/i;-><init>(Landroid/content/Context;)V

    new-array v0, v3, [Ljava/lang/String;

    const-string v1, "searching for opml-files..."

    aput-object v1, v0, v2

    invoke-virtual {p0, v0}, Lait/podka/c/as;->publishProgress([Ljava/lang/Object;)V

    :try_start_1a
    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-static {v0}, Lait/podka/c/ap;->a(Lait/podka/c/ap;)Ljava/util/concurrent/Future;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "found "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " files"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    invoke-virtual {p0, v1}, Lait/podka/c/as;->publishProgress([Ljava/lang/Object;)V

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_4c
    :goto_4c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_7c

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "found "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-static {v3}, Lait/podka/c/ap;->b(Lait/podka/c/ap;)Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Map;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " feeds"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-virtual {p0, v0}, Lait/podka/c/as;->publishProgress([Ljava/lang/Object;)V

    :goto_7a
    const/4 v0, 0x0

    return-object v0

    :cond_7c
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/File;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "parsing "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-virtual {p0, v2}, Lait/podka/c/as;->publishProgress([Ljava/lang/Object;)V

    invoke-static {v0}, Lait/podka/b/i;->a(Ljava/io/File;)Ljava/util/Map;

    move-result-object v0

    if-eqz v0, :cond_4c

    iget-object v2, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-static {v2}, Lait/podka/c/ap;->b(Lait/podka/c/ap;)Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2, v0}, Ljava/util/Map;->putAll(Ljava/util/Map;)V
    :try_end_ad
    .catch Ljava/lang/InterruptedException; {:try_start_1a .. :try_end_ad} :catch_ae
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1a .. :try_end_ad} :catch_b3

    goto :goto_4c

    :catch_ae
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_7a

    :catch_b3
    move-exception v0

    invoke-virtual {v0}, Ljava/util/concurrent/ExecutionException;->printStackTrace()V

    goto :goto_7a
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-direct {p0}, Lait/podka/c/as;->a()Ljava/lang/Void;

    move-result-object v0

    return-object v0
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 5

    const/4 v2, 0x1

    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-static {v0, v2}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Z)V

    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-static {v0}, Lait/podka/c/ap;->b(Lait/podka/c/ap;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    if-lez v0, :cond_2d

    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->p()Z

    move-result v0

    if-eqz v0, :cond_2d

    new-instance v0, Lait/podka/c/av;

    iget-object v1, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-direct {v0, v1}, Lait/podka/c/av;-><init>(Lait/podka/c/ap;)V

    iget-object v1, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-virtual {v1}, Lait/podka/c/ap;->n()Landroid/support/v4/app/m;

    move-result-object v1

    const-string v2, "dialog"

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/d;->a(Landroid/support/v4/app/m;Ljava/lang/String;)V

    :cond_2c
    :goto_2c
    return-void

    :cond_2d
    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    if-eqz v0, :cond_2c

    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    invoke-virtual {v0}, Lait/podka/c/ap;->l()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f080002

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_2c
.end method

.method protected final onPreExecute()V
    .registers 3

    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Z)V

    return-void
.end method

.method protected final varargs synthetic onProgressUpdate([Ljava/lang/Object;)V
    .registers 4

    check-cast p1, [Ljava/lang/String;

    iget-object v0, p0, Lait/podka/c/as;->a:Lait/podka/c/ap;

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-static {v0, v1}, Lait/podka/c/ap;->a(Lait/podka/c/ap;Ljava/lang/String;)V

    return-void
.end method
