###### Class ait.podka.c.z (ait.podka.c.z)
.class final Lait/podka/c/z;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/c/y;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lait/podka/c/y;Landroid/app/Activity;)V
    .registers 3

    iput-object p1, p0, Lait/podka/c/z;->a:Lait/podka/c/y;

    iput-object p2, p0, Lait/podka/c/z;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/c/z;->b:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Could not stream podcast, unknown error."

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
