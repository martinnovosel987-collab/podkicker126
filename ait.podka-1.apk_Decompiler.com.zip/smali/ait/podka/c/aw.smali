###### Class ait.podka.c.aw (ait.podka.c.aw)
.class final Lait/podka/c/aw;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/c/av;


# direct methods
.method constructor <init>(Lait/podka/c/av;)V
    .registers 2

    iput-object p1, p0, Lait/podka/c/aw;->a:Lait/podka/c/av;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    const/4 v2, 0x0

    new-instance v0, Lait/podka/c/ar;

    iget-object v1, p0, Lait/podka/c/aw;->a:Lait/podka/c/av;

    invoke-static {v1}, Lait/podka/c/av;->a(Lait/podka/c/av;)Lait/podka/c/ap;

    move-result-object v1

    invoke-direct {v0, v1, v2}, Lait/podka/c/ar;-><init>(Lait/podka/c/ap;B)V

    new-array v1, v2, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lait/podka/c/ar;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
