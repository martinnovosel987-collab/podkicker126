###### Class ait.podka.l (ait.podka.l)
.class final Lait/podka/l;
.super Lcom/google/android/maps/ItemizedOverlay;


# instance fields
.field final synthetic a:Lait/podka/PodMap;

.field private b:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Lait/podka/PodMap;Landroid/graphics/drawable/Drawable;)V
    .registers 4

    iput-object p1, p0, Lait/podka/l;->a:Lait/podka/PodMap;

    invoke-static {p2}, Lait/podka/l;->boundCenterBottom(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/android/maps/ItemizedOverlay;-><init>(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lait/podka/l;->b:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;)V
    .registers 3

    iget-object v0, p0, Lait/podka/l;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0}, Lait/podka/l;->populate()V

    return-void
.end method

.method protected final createItem(I)Lcom/google/android/maps/OverlayItem;
    .registers 3

    iget-object v0, p0, Lait/podka/l;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/maps/OverlayItem;

    return-object v0
.end method

.method protected final onTap(I)Z
    .registers 6

    iget-object v0, p0, Lait/podka/l;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/maps/OverlayItem;

    invoke-virtual {v0}, Lcom/google/android/maps/OverlayItem;->getPoint()Lcom/google/android/maps/GeoPoint;

    move-result-object v0

    iget-object v1, p0, Lait/podka/l;->a:Lait/podka/PodMap;

    invoke-static {v1, v0}, Lait/podka/PodMap;->a(Lait/podka/PodMap;Lcom/google/android/maps/GeoPoint;)Ljava/util/Set;

    move-result-object v0

    if-eqz v0, :cond_2c

    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lait/podka/l;->a:Lait/podka/PodMap;

    const-class v3, Lait/podka/PodMapList;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const-string v0, "ids"

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putStringArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    iget-object v0, p0, Lait/podka/l;->a:Lait/podka/PodMap;

    invoke-virtual {v0, v1}, Lait/podka/PodMap;->startActivity(Landroid/content/Intent;)V

    :cond_2c
    const/4 v0, 0x1

    return v0
.end method

.method public final onTap(Lcom/google/android/maps/GeoPoint;Lcom/google/android/maps/MapView;)Z
    .registers 4

    iget-object v0, p0, Lait/podka/l;->a:Lait/podka/PodMap;

    invoke-static {v0}, Lait/podka/PodMap;->a(Lait/podka/PodMap;)Lcom/google/android/maps/MapController;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/google/android/maps/MapController;->animateTo(Lcom/google/android/maps/GeoPoint;)V

    invoke-super {p0, p1, p2}, Lcom/google/android/maps/ItemizedOverlay;->onTap(Lcom/google/android/maps/GeoPoint;Lcom/google/android/maps/MapView;)Z

    move-result v0

    return v0
.end method

.method public final size()I
    .registers 2

    iget-object v0, p0, Lait/podka/l;->b:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method
