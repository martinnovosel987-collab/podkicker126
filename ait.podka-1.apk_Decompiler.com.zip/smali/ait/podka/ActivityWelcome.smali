###### Class ait.podka.ActivityWelcome (ait.podka.ActivityWelcome)
.class public Lait/podka/ActivityWelcome;
.super Landroid/app/Activity;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method final a()V
    .registers 2

    const/16 v0, 0x888

    invoke-virtual {p0, v0}, Lait/podka/ActivityWelcome;->setResult(I)V

    invoke-virtual {p0}, Lait/podka/ActivityWelcome;->finish()V

    return-void
.end method

.method final b()V
    .registers 2

    const/16 v0, 0x999

    invoke-virtual {p0, v0}, Lait/podka/ActivityWelcome;->setResult(I)V

    invoke-virtual {p0}, Lait/podka/ActivityWelcome;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 6

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const v0, 0x7f030002

    invoke-virtual {p0, v0}, Lait/podka/ActivityWelcome;->setContentView(I)V

    const v0, 0x7f0b0008

    invoke-virtual {p0, v0}, Lait/podka/ActivityWelcome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    :try_start_12
    new-instance v1, Ljava/util/Scanner;

    invoke-virtual {p0}, Lait/podka/ActivityWelcome;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v2

    const-string v3, "eula.txt"

    invoke-virtual {v2, v3}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/util/Scanner;-><init>(Ljava/io/InputStream;)V

    const-string v2, "\\A"

    invoke-virtual {v1, v2}, Ljava/util/Scanner;->useDelimiter(Ljava/lang/String;)Ljava/util/Scanner;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Scanner;->next()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_32
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_32} :catch_51

    :goto_32
    const v0, 0x7f0b0006

    invoke-virtual {p0, v0}, Lait/podka/ActivityWelcome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lait/podka/b;

    invoke-direct {v1, p0}, Lait/podka/b;-><init>(Lait/podka/ActivityWelcome;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f0b0003

    invoke-virtual {p0, v0}, Lait/podka/ActivityWelcome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lait/podka/c;

    invoke-direct {v1, p0}, Lait/podka/c;-><init>(Lait/podka/ActivityWelcome;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    :catch_51
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_32
.end method
