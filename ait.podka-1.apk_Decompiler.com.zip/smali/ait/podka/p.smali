###### Class ait.podka.p (ait.podka.p)
.class final Lait/podka/p;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/preference/Preference$OnPreferenceClickListener;


# instance fields
.field final synthetic a:Lait/podka/Prefs;


# direct methods
.method constructor <init>(Lait/podka/Prefs;)V
    .registers 2

    iput-object p1, p0, Lait/podka/p;->a:Lait/podka/Prefs;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic a(Lait/podka/p;)Lait/podka/Prefs;
    .registers 2

    iget-object v0, p0, Lait/podka/p;->a:Lait/podka/Prefs;

    return-object v0
.end method


# virtual methods
.method public final onPreferenceClick(Landroid/preference/Preference;)Z
    .registers 5

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lait/podka/q;

    invoke-direct {v1, p0}, Lait/podka/q;-><init>(Lait/podka/p;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    iget-object v0, p0, Lait/podka/p;->a:Lait/podka/Prefs;

    invoke-virtual {v0}, Lait/podka/Prefs;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "backup saved"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const/4 v0, 0x1

    return v0
.end method
