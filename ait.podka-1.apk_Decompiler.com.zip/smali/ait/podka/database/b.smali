###### Class ait.podka.database.b (ait.podka.database.b)
.class public final Lait/podka/database/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private a:Ljava/util/Locale;

.field private b:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    iput-object v0, p0, Lait/podka/database/b;->a:Ljava/util/Locale;

    iput-object p1, p0, Lait/podka/database/b;->b:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    const-string v0, "sv"

    iget-object v1, p0, Lait/podka/database/b;->a:Ljava/util/Locale;

    invoke-virtual {v1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_25

    new-instance v0, Lait/podka/b/b;

    iget-object v1, p0, Lait/podka/database/b;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Lait/podka/b/b;-><init>(Landroid/content/Context;)V

    const-string v1, "http://feeds.feedburner.com/filipochfredrik/podcast"

    invoke-virtual {v0, v1}, Lait/podka/b/b;->a(Ljava/lang/String;)V

    const-string v1, "http://alexosigge.libsyn.com/rss"

    invoke-virtual {v0, v1}, Lait/podka/b/b;->a(Ljava/lang/String;)V

    const-string v1, "http://varvet.libsyn.com/rss"

    invoke-virtual {v0, v1}, Lait/podka/b/b;->a(Ljava/lang/String;)V

    :goto_24
    return-void

    :cond_25
    new-instance v0, Lait/podka/b/b;

    iget-object v1, p0, Lait/podka/database/b;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Lait/podka/b/b;-><init>(Landroid/content/Context;)V

    const-string v1, "http://downloads.bbc.co.uk/podcasts/worldservice/globalnews/rss.xml"

    invoke-virtual {v0, v1}, Lait/podka/b/b;->a(Ljava/lang/String;)V

    const-string v1, "http://www.discovery.com/radio/xml/hsw_podcast.xml"

    invoke-virtual {v0, v1}, Lait/podka/b/b;->a(Ljava/lang/String;)V

    goto :goto_24
.end method
