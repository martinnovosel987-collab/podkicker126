###### Class ait.podka.database.f (ait.podka.database.f)
.class public final Lait/podka/database/f;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/provider/BaseColumns;


# static fields
.field public static final a:Landroid/net/Uri;

.field public static final b:Landroid/net/Uri;

.field public static final c:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "content://ait.podka.database.PodcastProvider/entry"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/f;->a:Landroid/net/Uri;

    const-string v0, "content://ait.podka.database.PodcastProvider/entry/vacuum"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/f;->b:Landroid/net/Uri;

    const-string v0, "content://ait.podka.database.PodcastProvider/entry/"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/f;->c:Landroid/net/Uri;

    return-void
.end method
