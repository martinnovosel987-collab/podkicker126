###### Class ait.podka.database.e (ait.podka.database.e)
.class public final Lait/podka/database/e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/provider/BaseColumns;


# static fields
.field public static final a:Landroid/net/Uri;

.field public static final b:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "content://ait.podka.database.PodcastProvider/enclosure"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/e;->a:Landroid/net/Uri;

    const-string v0, "content://ait.podka.database.PodcastProvider/enclosure/"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/e;->b:Landroid/net/Uri;

    return-void
.end method
