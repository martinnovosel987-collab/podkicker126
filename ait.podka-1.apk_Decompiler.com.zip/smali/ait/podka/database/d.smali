###### Class ait.podka.database.d (ait.podka.database.d)
.class public final Lait/podka/database/d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/provider/BaseColumns;


# static fields
.field public static final a:Landroid/net/Uri;

.field public static final b:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "content://ait.podka.database.PodcastProvider/channel"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/d;->a:Landroid/net/Uri;

    const-string v0, "content://ait.podka.database.PodcastProvider/channel/"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lait/podka/database/d;->b:Landroid/net/Uri;

    return-void
.end method
