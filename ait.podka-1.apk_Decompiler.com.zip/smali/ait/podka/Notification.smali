###### Class ait.podka.Notification (ait.podka.Notification)
.class public Lait/podka/Notification;
.super Landroid/app/Activity;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 6

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const v0, 0x7f030001

    invoke-virtual {p0, v0}, Lait/podka/Notification;->setContentView(I)V

    const v0, 0x7f0b0003

    invoke-virtual {p0, v0}, Lait/podka/Notification;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lait/podka/g;

    invoke-direct {v1, p0}, Lait/podka/g;-><init>(Lait/podka/Notification;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f0b0002

    invoke-virtual {p0, v0}, Lait/podka/Notification;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "We have lowered the price of <font color=yellow>Podkicker Pro</font> to only <font color=yellow>$0.99</font> so that everyone can afford it!"

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lait/podka/h;

    invoke-direct {v1, p0}, Lait/podka/h;-><init>(Lait/podka/Notification;)V

    const-wide/16 v2, 0x7d0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lait/podka/i;

    invoke-direct {v1, p0}, Lait/podka/i;-><init>(Lait/podka/Notification;)V

    const-wide/16 v2, 0xce4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .registers 4

    invoke-virtual {p0}, Lait/podka/Notification;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const/high16 v1, 0x7f0a0000

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 v0, 0x1

    return v0
.end method
