###### Class ait.podka.Prefs (ait.podka.Prefs)
.class public Lait/podka/Prefs;
.super Landroid/preference/PreferenceActivity;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/preference/PreferenceActivity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 11

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/preference/PreferenceActivity;->onCreate(Landroid/os/Bundle;)V

    const/high16 v0, 0x7f050000

    invoke-virtual {p0, v0}, Lait/podka/Prefs;->addPreferencesFromResource(I)V

    const-string v0, "settings"

    invoke-virtual {p0, v0}, Lait/podka/Prefs;->setTitle(Ljava/lang/CharSequence;)V

    const-string v0, "backup"

    invoke-virtual {p0, v0}, Lait/podka/Prefs;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    new-instance v3, Lait/podka/p;

    invoke-direct {v3, p0}, Lait/podka/p;-><init>(Lait/podka/Prefs;)V

    invoke-virtual {v0, v3}, Landroid/preference/Preference;->setOnPreferenceClickListener(Landroid/preference/Preference$OnPreferenceClickListener;)V

    const-string v0, "upgrade"

    invoke-virtual {p0, v0}, Lait/podka/Prefs;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    new-instance v3, Lait/podka/r;

    invoke-direct {v3, p0}, Lait/podka/r;-><init>(Lait/podka/Prefs;)V

    invoke-virtual {v0, v3}, Landroid/preference/Preference;->setOnPreferenceClickListener(Landroid/preference/Preference$OnPreferenceClickListener;)V

    const-string v0, "clear_image_cache"

    invoke-virtual {p0, v0}, Lait/podka/Prefs;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v0

    new-instance v3, Lait/podka/s;

    invoke-direct {v3, p0}, Lait/podka/s;-><init>(Lait/podka/Prefs;)V

    invoke-virtual {v0, v3}, Landroid/preference/Preference;->setOnPreferenceClickListener(Landroid/preference/Preference$OnPreferenceClickListener;)V

    const-string v0, "clear_episodes"

    invoke-virtual {p0, v0}, Lait/podka/Prefs;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v8

    new-instance v0, Lait/podka/u;

    invoke-virtual {p0}, Lait/podka/Prefs;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    invoke-direct {v0, p0, v3, v8}, Lait/podka/u;-><init>(Lait/podka/Prefs;Landroid/content/ContentResolver;Landroid/preference/Preference;)V

    sget-object v3, Lait/podka/database/e;->a:Landroid/net/Uri;

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/String;

    const-string v5, "count(*)"

    aput-object v5, v4, v1

    move-object v5, v2

    move-object v6, v2

    move-object v7, v2

    invoke-virtual/range {v0 .. v7}, Lait/podka/u;->startQuery(ILjava/lang/Object;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Lait/podka/v;

    invoke-direct {v0, p0, v8}, Lait/podka/v;-><init>(Lait/podka/Prefs;Landroid/preference/Preference;)V

    invoke-virtual {v8, v0}, Landroid/preference/Preference;->setOnPreferenceClickListener(Landroid/preference/Preference$OnPreferenceClickListener;)V

    return-void
.end method
