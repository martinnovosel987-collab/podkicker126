###### Class ait.podka.Podka (ait.podka.Podka)
.class public Lait/podka/Podka;
.super Landroid/support/v4/app/FragmentActivity;

# interfaces
.implements Lait/podka/menu/a;
.implements Landroid/support/v4/app/n;


# static fields
.field private static C:Ljava/lang/reflect/Method;

.field private static D:Ljava/lang/reflect/Method;

.field public static a:Ljava/lang/String;

.field public static b:I

.field public static c:Ljava/lang/String;

.field public static d:Ljava/lang/String;

.field public static e:Ljava/lang/String;

.field public static f:Ljava/io/File;

.field public static g:Ljava/io/File;


# instance fields
.field private A:Landroid/content/ComponentName;

.field private B:Lcom/google/ads/AdView;

.field private E:I

.field private final u:I

.field private v:Landroid/support/v4/app/m;

.field private w:Lait/podka/menu/PodkaMenu;

.field private x:Z

.field private y:Landroid/content/SharedPreferences;

.field private z:Landroid/media/AudioManager;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    :try_start_0
    sget-object v0, Lait/podka/Podka;->C:Ljava/lang/reflect/Method;

    if-nez v0, :cond_16

    const-class v0, Landroid/media/AudioManager;

    const-string v1, "registerMediaButtonEventReceiver"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Class;

    const/4 v3, 0x0

    const-class v4, Landroid/content/ComponentName;

    aput-object v4, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    sput-object v0, Lait/podka/Podka;->C:Ljava/lang/reflect/Method;

    :cond_16
    sget-object v0, Lait/podka/Podka;->D:Ljava/lang/reflect/Method;

    if-nez v0, :cond_2c

    const-class v0, Landroid/media/AudioManager;

    const-string v1, "unregisterMediaButtonEventReceiver"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Class;

    const/4 v3, 0x0

    const-class v4, Landroid/content/ComponentName;

    aput-object v4, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    sput-object v0, Lait/podka/Podka;->D:Ljava/lang/reflect/Method;
    :try_end_2c
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_2c} :catch_2d

    :cond_2c
    :goto_2c
    return-void

    :catch_2d
    move-exception v0

    goto :goto_2c
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/support/v4/app/FragmentActivity;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lait/podka/Podka;->u:I

    return-void
.end method

.method private f()Z
    .registers 6

    const/4 v4, 0x0

    const/16 v3, 0x8

    const/4 v1, 0x0

    const/4 v0, 0x1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v3, :cond_16

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2, v4}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    if-eqz v2, :cond_4e

    move v2, v0

    :goto_14
    if-eqz v2, :cond_26

    :cond_16
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-ge v2, v3, :cond_4d

    const-string v2, "mounted"

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4d

    :cond_26
    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const-string v3, "This application can not start without access to some external storage"

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lait/podka/o;

    invoke-direct {v3, p0}, Lait/podka/o;-><init>(Lait/podka/Podka;)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/app/AlertDialog;->setCanceledOnTouchOutside(Z)V

    invoke-virtual {v2}, Landroid/app/AlertDialog;->show()V

    move v0, v1

    :cond_4d
    return v0

    :cond_4e
    move v2, v1

    goto :goto_14
.end method


# virtual methods
.method public final a()V
    .registers 3

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->e()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_25

    iget v0, p0, Lait/podka/Podka;->E:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_25

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    invoke-virtual {v0}, Lait/podka/menu/PodkaMenu;->a()V

    :cond_13
    :goto_13
    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->e()I

    move-result v0

    iput v0, p0, Lait/podka/Podka;->E:I

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->e()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    return-void

    :cond_25
    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->e()I

    move-result v0

    if-nez v0, :cond_13

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    invoke-virtual {v0}, Lait/podka/menu/PodkaMenu;->b()V

    goto :goto_13
.end method

.method public final a(II)V
    .registers 9

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    :try_start_3
    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->d()V

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v2

    packed-switch p2, :pswitch_data_d4

    :goto_11
    packed-switch p1, :pswitch_data_de

    :cond_14
    :goto_14
    :pswitch_14
    return-void

    :pswitch_15
    const v0, 0x7f040002

    invoke-virtual {v2, v0}, Landroid/support/v4/app/z;->a(I)Landroid/support/v4/app/z;
    :try_end_1b
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_1b} :catch_1c

    goto :goto_11

    :catch_1c
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_14

    :pswitch_21
    const v0, 0x7f040003

    :try_start_24
    invoke-virtual {v2, v0}, Landroid/support/v4/app/z;->a(I)Landroid/support/v4/app/z;

    goto :goto_11

    :pswitch_28
    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/c;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v1

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v3, Lait/podka/c/ao;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    :goto_44
    const v3, 0x7f0b002f

    invoke-virtual {v2, v3, v1}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    invoke-virtual {v2}, Landroid/support/v4/app/z;->b()I

    iget-boolean v1, p0, Lait/podka/Podka;->x:Z

    if-eqz v1, :cond_14

    iget-object v1, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    const v2, 0x7f0b0031

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->b()I

    goto :goto_14

    :pswitch_62
    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/s;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v0

    const-string v3, "action"

    const/4 v4, 0x1

    invoke-virtual {v0, v3, v4}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v0

    const-string v3, "id"

    const-wide/16 v4, 0x0

    invoke-virtual {v0, v3, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v3, Lait/podka/c/ao;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    goto :goto_44

    :pswitch_99
    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/af;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v1

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v3, Lait/podka/c/al;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    goto :goto_44

    :pswitch_b6
    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/i;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v1

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v3, Lait/podka/c/ao;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    :try_end_d1
    .catch Ljava/lang/IllegalStateException; {:try_start_24 .. :try_end_d1} :catch_1c

    move-result-object v0

    goto/16 :goto_44

    :pswitch_data_d4
    .packed-switch 0x1
        :pswitch_15
        :pswitch_21
        :pswitch_14
    .end packed-switch

    :pswitch_data_de
    .packed-switch 0x0
        :pswitch_28
        :pswitch_62
        :pswitch_99
        :pswitch_b6
    .end packed-switch
.end method

.method public final b()Lait/podka/menu/PodkaMenu;
    .registers 2

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    return-object v0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 8

    const/4 v3, 0x1

    const/4 v2, 0x0

    packed-switch p1, :pswitch_data_40

    :cond_5
    :goto_5
    return-void

    :pswitch_6
    if-eqz p2, :cond_c

    const/16 v0, 0x999

    if-ne p2, v0, :cond_1d

    :cond_c
    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Eula rejected"

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lait/podka/Podka;->finish()V

    goto :goto_5

    :cond_1d
    const/16 v0, 0x888

    if-ne p2, v0, :cond_5

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Eula accepted"

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0, v2}, Lait/podka/Podka;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "eula"

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_5

    :pswitch_data_40
    .packed-switch 0xea
        :pswitch_6
    .end packed-switch
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 10

    const v7, 0x7f0b0031

    const v6, 0x7f0b002f

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    invoke-direct {p0}, Lait/podka/Podka;->f()Z

    move-result v0

    if-nez v0, :cond_1c

    :goto_1b
    return-void

    :cond_1c
    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lait/podka/e;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lait/podka/Podka;->a:Ljava/lang/String;

    invoke-static {v0}, Lait/podka/e;->b(Landroid/content/Context;)I

    move-result v3

    sput v3, Lait/podka/Podka;->b:I

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lait/podka/Podka;->c:Ljava/lang/String;

    const/high16 v3, 0x7f080000

    invoke-virtual {v0, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v4, Lait/podka/Podka;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lait/podka/Podka;->d:Ljava/lang/String;

    sput-object v0, Lait/podka/Podka;->e:Ljava/lang/String;

    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "/Android/data/"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v5, Lait/podka/Podka;->c:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/files/podcasts/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    sput-object v0, Lait/podka/Podka;->g:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "/Android/data/"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v5, Lait/podka/Podka;->c:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/cache/podparts/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    sput-object v0, Lait/podka/Podka;->f:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    const-string v0, "audio"

    invoke-virtual {p0, v0}, Lait/podka/Podka;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    iput-object v0, p0, Lait/podka/Podka;->z:Landroid/media/AudioManager;

    new-instance v0, Landroid/content/ComponentName;

    invoke-virtual {p0}, Lait/podka/Podka;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const-class v4, Lait/podka/receivers/RemoteControlReceiver;

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/Podka;->A:Landroid/content/ComponentName;

    const v0, 0x7f030010

    invoke-virtual {p0, v0}, Lait/podka/Podka;->setContentView(I)V

    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    const-string v3, "istime"

    invoke-interface {v0, v3}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_135

    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "istime"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-interface {v0, v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :cond_dd
    :goto_dd
    invoke-virtual {p0, v7}, Lait/podka/Podka;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_160

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_160

    move v0, v1

    :goto_ea
    iput-boolean v0, p0, Lait/podka/Podka;->x:Z

    iget-object v0, p0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iput-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->d()V

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0, p0}, Landroid/support/v4/app/m;->a(Landroid/support/v4/app/n;)V

    const v0, 0x7f0b002d

    invoke-virtual {p0, v0}, Lait/podka/Podka;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lait/podka/menu/PodkaMenu;

    iput-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    invoke-virtual {v0, p0}, Lait/podka/menu/PodkaMenu;->setOnMenuItemClickedListener(Lait/podka/menu/a;)V

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    const-string v3, "Channels"

    invoke-virtual {v0, v3}, Lait/podka/menu/PodkaMenu;->a(Ljava/lang/String;)V

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    const-string v3, "New"

    invoke-virtual {v0, v3}, Lait/podka/menu/PodkaMenu;->a(Ljava/lang/String;)V

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    const-string v3, "Player"

    invoke-virtual {v0, v3}, Lait/podka/menu/PodkaMenu;->a(Ljava/lang/String;)V

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    const-string v3, "Downloads"

    invoke-virtual {v0, v3}, Lait/podka/menu/PodkaMenu;->a(Ljava/lang/String;)V

    if-eqz p1, :cond_162

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    const-string v2, "last_active_section"

    invoke-virtual {p1, v2, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    invoke-virtual {v0, v1}, Lait/podka/menu/PodkaMenu;->a(I)V

    goto/16 :goto_1b

    :cond_135
    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    const-string v3, "prooffer_shown"

    invoke-interface {v0, v3}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_dd

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0xf

    if-lt v0, v3, :cond_dd

    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "prooffer_shown"

    invoke-interface {v0, v3, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    new-instance v0, Landroid/content/Intent;

    const-class v3, Lait/podka/Notification;

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_dd

    :cond_160
    move v0, v2

    goto :goto_ea

    :cond_162
    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    const-string v3, "showchangelog"

    const/4 v4, -0x1

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    sget v3, Lait/podka/Podka;->b:I

    if-eq v0, v3, :cond_181

    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "showchangelog"

    sget v3, Lait/podka/Podka;->b:I

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move v2, v1

    :cond_181
    if-eqz v2, :cond_1dc

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v2, Lait/podka/c/ao;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v2, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lait/podka/c/ao;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v2

    invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v3

    const-string v4, "showlog"

    invoke-virtual {v3, v4, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    iget-boolean v1, p0, Lait/podka/Podka;->x:Z

    if-eqz v1, :cond_1cd

    iget-object v1, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v7, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0, v6, v2}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto/16 :goto_1b

    :cond_1cd
    iget-object v1, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v1}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v1

    invoke-virtual {v1, v6, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto/16 :goto_1b

    :cond_1dc
    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    invoke-virtual {v0, v1}, Lait/podka/menu/PodkaMenu;->a(I)V

    goto/16 :goto_1b
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .registers 4

    invoke-virtual {p0}, Lait/podka/Podka;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const v1, 0x7f0a0001

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 v0, 0x1

    return v0
.end method

.method public onDestroy()V
    .registers 6

    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->onDestroy()V

    :try_start_3
    sget-object v0, Lait/podka/Podka;->D:Ljava/lang/reflect/Method;

    if-nez v0, :cond_8

    :goto_7
    return-void

    :cond_8
    sget-object v0, Lait/podka/Podka;->D:Ljava/lang/reflect/Method;

    iget-object v1, p0, Lait/podka/Podka;->z:Landroid/media/AudioManager;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lait/podka/Podka;->A:Landroid/content/ComponentName;

    aput-object v4, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_17
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3 .. :try_end_17} :catch_18
    .catch Ljava/lang/IllegalAccessException; {:try_start_3 .. :try_end_17} :catch_30
    .catch Ljava/lang/NullPointerException; {:try_start_3 .. :try_end_17} :catch_40

    goto :goto_7

    :catch_18
    move-exception v0

    move-object v1, v0

    invoke-virtual {v1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    instance-of v2, v0, Ljava/lang/RuntimeException;

    if-eqz v2, :cond_25

    check-cast v0, Ljava/lang/RuntimeException;

    throw v0

    :cond_25
    instance-of v2, v0, Ljava/lang/Error;

    if-eqz v2, :cond_2c

    check-cast v0, Ljava/lang/Error;

    throw v0

    :cond_2c
    invoke-virtual {v1}, Ljava/lang/reflect/InvocationTargetException;->printStackTrace()V

    goto :goto_7

    :catch_30
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "unexpected "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    goto :goto_7

    :catch_40
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/NullPointerException;->printStackTrace()V

    goto :goto_7
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .registers 2

    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onNewIntent(Landroid/content/Intent;)V

    invoke-virtual {p0, p1}, Lait/podka/Podka;->setIntent(Landroid/content/Intent;)V

    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .registers 6

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    packed-switch v0, :pswitch_data_74

    :goto_7
    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v0

    return v0

    :pswitch_c
    iget-boolean v0, p0, Lait/podka/Podka;->x:Z

    if-eqz v0, :cond_2f

    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v0

    const v1, 0x7f0b0031

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lait/podka/c/ap;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_7

    :cond_2f
    iget-object v0, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v0}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v0

    const v1, 0x7f0b002f

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lait/podka/c/ap;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/app/z;->a(Ljava/lang/String;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I

    goto :goto_7

    :pswitch_53
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lait/podka/About;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startActivity(Landroid/content/Intent;)V

    goto :goto_7

    :pswitch_5e
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lait/podka/services/Refresh;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_7

    :pswitch_69
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lait/podka/Prefs;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startActivity(Landroid/content/Intent;)V

    goto :goto_7

    :pswitch_data_74
    .packed-switch 0x7f0b003d
        :pswitch_c
        :pswitch_5e
        :pswitch_69
        :pswitch_53
    .end packed-switch
.end method

.method protected onResume()V
    .registers 8

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->onResume()V

    invoke-direct {p0}, Lait/podka/Podka;->f()Z

    move-result v0

    if-nez v0, :cond_c

    :cond_b
    :goto_b
    return-void

    :cond_c
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lait/podka/download/DownloadService;

    invoke-direct {v0, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lait/podka/services/AudioService;

    invoke-direct {v0, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :try_start_28
    sget-object v0, Lait/podka/Podka;->C:Ljava/lang/reflect/Method;
    :try_end_2a
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_28 .. :try_end_2a} :catch_137
    .catch Ljava/lang/IllegalAccessException; {:try_start_28 .. :try_end_2a} :catch_150
    .catch Ljava/lang/NullPointerException; {:try_start_28 .. :try_end_2a} :catch_161

    if-nez v0, :cond_126

    :goto_2c
    :try_start_2c
    invoke-virtual {p0}, Lait/podka/Podka;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lait/podka/Podka;->getIntent()Landroid/content/Intent;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {p0}, Lait/podka/Podka;->getIntent()Landroid/content/Intent;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object v4

    if-eqz v0, :cond_167

    const-string v5, "android.intent.action.VIEW"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_167

    invoke-virtual {p0}, Lait/podka/Podka;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v5, Lait/podka/c/ap;

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Landroid/os/Bundle;

    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v5, v6}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v5

    const-string v6, "url"

    invoke-virtual {v3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v6, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v3

    const-string v5, "type"

    invoke-virtual {v3, v5, v4}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    iget-object v3, p0, Lait/podka/Podka;->v:Landroid/support/v4/app/m;

    invoke-virtual {v3}, Landroid/support/v4/app/m;->a()Landroid/support/v4/app/z;

    move-result-object v3

    const v4, 0x7f0b002f

    invoke-virtual {v3, v4, v0}, Landroid/support/v4/app/z;->a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/z;->a()I
    :try_end_87
    .catch Ljava/lang/IllegalStateException; {:try_start_2c .. :try_end_87} :catch_186

    :cond_87
    :goto_87
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const-wide/32 v5, 0x36ee80

    sub-long/2addr v3, v5

    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    const-string v5, "refresh_on_startup"

    invoke-interface {v0, v5, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_af

    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    const-string v5, "last_refresh_time"

    invoke-interface {v0, v5, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v5

    cmp-long v0, v5, v3

    if-gtz v0, :cond_af

    new-instance v0, Landroid/content/Intent;

    const-class v3, Lait/podka/services/Refresh;

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lait/podka/Podka;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_af
    iget-object v0, p0, Lait/podka/Podka;->y:Landroid/content/SharedPreferences;

    const-string v3, "istime"

    const-wide/16 v4, 0x0

    invoke-interface {v0, v3, v4, v5}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    sub-long v3, v5, v3

    const-wide/32 v5, 0x5265c00

    div-long/2addr v3, v5

    long-to-int v0, v3

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "days installed "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    const/4 v3, 0x2

    if-le v0, v3, :cond_189

    new-instance v3, Ljava/util/Random;

    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    const/16 v4, 0x1e

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    if-ge v3, v0, :cond_189

    move v0, v1

    :goto_e3
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "show ad "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "show ad "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    if-eqz v0, :cond_b

    new-instance v0, Lcom/google/ads/AdView;

    sget-object v1, Lcom/google/ads/g;->a:Lcom/google/ads/g;

    const-string v2, "a150683a5c8a2a6"

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/AdView;-><init>(Landroid/app/Activity;Lcom/google/ads/g;Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/Podka;->B:Lcom/google/ads/AdView;

    iget-object v0, p0, Lait/podka/Podka;->B:Lcom/google/ads/AdView;

    new-instance v1, Lcom/google/ads/d;

    invoke-direct {v1}, Lcom/google/ads/d;-><init>()V

    invoke-virtual {v0, v1}, Lcom/google/ads/AdView;->a(Lcom/google/ads/d;)V

    const v0, 0x7f0b002e

    invoke-virtual {p0, v0}, Lait/podka/Podka;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lait/podka/Podka;->B:Lcom/google/ads/AdView;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto/16 :goto_b

    :cond_126
    :try_start_126
    sget-object v0, Lait/podka/Podka;->C:Ljava/lang/reflect/Method;

    iget-object v3, p0, Lait/podka/Podka;->z:Landroid/media/AudioManager;

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    iget-object v6, p0, Lait/podka/Podka;->A:Landroid/content/ComponentName;

    aput-object v6, v4, v5

    invoke-virtual {v0, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_135
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_126 .. :try_end_135} :catch_137
    .catch Ljava/lang/IllegalAccessException; {:try_start_126 .. :try_end_135} :catch_150
    .catch Ljava/lang/NullPointerException; {:try_start_126 .. :try_end_135} :catch_161

    goto/16 :goto_2c

    :catch_137
    move-exception v0

    move-object v3, v0

    invoke-virtual {v3}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    instance-of v4, v0, Ljava/lang/RuntimeException;

    if-eqz v4, :cond_144

    check-cast v0, Ljava/lang/RuntimeException;

    throw v0

    :cond_144
    instance-of v4, v0, Ljava/lang/Error;

    if-eqz v4, :cond_14b

    check-cast v0, Ljava/lang/Error;

    throw v0

    :cond_14b
    invoke-virtual {v3}, Ljava/lang/reflect/InvocationTargetException;->printStackTrace()V

    goto/16 :goto_2c

    :catch_150
    move-exception v0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "unexpected "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    goto/16 :goto_2c

    :catch_161
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/NullPointerException;->printStackTrace()V

    goto/16 :goto_2c

    :cond_167
    :try_start_167
    invoke-virtual {p0}, Lait/podka/Podka;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v3, "redirect"

    const/4 v4, 0x0

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_87

    invoke-virtual {p0}, Lait/podka/Podka;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v3, "redirect_to"

    const/4 v4, 0x0

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    iget-object v3, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    invoke-virtual {v3, v0}, Lait/podka/menu/PodkaMenu;->a(I)V
    :try_end_184
    .catch Ljava/lang/IllegalStateException; {:try_start_167 .. :try_end_184} :catch_186

    goto/16 :goto_87

    :catch_186
    move-exception v0

    goto/16 :goto_87

    :cond_189
    move v0, v2

    goto/16 :goto_e3
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 4

    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onSaveInstanceState(Landroid/os/Bundle;)V

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    if-eqz v0, :cond_15

    iget-object v0, p0, Lait/podka/Podka;->w:Lait/podka/menu/PodkaMenu;

    invoke-virtual {v0}, Lait/podka/menu/PodkaMenu;->c()I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_15

    const-string v1, "last_active_section"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    :cond_15
    return-void
.end method
