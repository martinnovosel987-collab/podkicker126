###### Class ait.podka.u (ait.podka.u)
.class final Lait/podka/u;
.super Landroid/content/AsyncQueryHandler;


# instance fields
.field final synthetic a:Lait/podka/Prefs;

.field private final synthetic b:Landroid/preference/Preference;


# direct methods
.method constructor <init>(Lait/podka/Prefs;Landroid/content/ContentResolver;Landroid/preference/Preference;)V
    .registers 4

    iput-object p1, p0, Lait/podka/u;->a:Lait/podka/Prefs;

    iput-object p3, p0, Lait/podka/u;->b:Landroid/preference/Preference;

    invoke-direct {p0, p2}, Landroid/content/AsyncQueryHandler;-><init>(Landroid/content/ContentResolver;)V

    return-void
.end method


# virtual methods
.method protected final onQueryComplete(ILjava/lang/Object;Landroid/database/Cursor;)V
    .registers 8

    invoke-super {p0, p1, p2, p3}, Landroid/content/AsyncQueryHandler;->onQueryComplete(ILjava/lang/Object;Landroid/database/Cursor;)V

    invoke-interface {p3}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_28

    const/4 v0, 0x0

    invoke-interface {p3, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    iget-object v1, p0, Lait/podka/u;->b:Landroid/preference/Preference;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Remove all "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " episodes from cache."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    :cond_28
    invoke-interface {p3}, Landroid/database/Cursor;->close()V

    return-void
.end method
