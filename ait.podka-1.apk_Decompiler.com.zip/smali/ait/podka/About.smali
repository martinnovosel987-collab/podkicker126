###### Class ait.podka.About (ait.podka.About)
.class public Lait/podka/About;
.super Landroid/support/v4/app/FragmentActivity;


# instance fields
.field private a:Lait/podka/a;

.field private b:Landroid/support/v4/view/ViewPager;

.field private c:Lcom/google/ads/AdView;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/app/FragmentActivity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onCreate(Landroid/os/Bundle;)V

    const/high16 v0, 0x7f030000

    invoke-virtual {p0, v0}, Lait/podka/About;->setContentView(I)V

    new-instance v0, Lait/podka/a;

    iget-object v1, p0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    invoke-direct {v0, p0, v1}, Lait/podka/a;-><init>(Lait/podka/About;Landroid/support/v4/app/m;)V

    iput-object v0, p0, Lait/podka/About;->a:Lait/podka/a;

    const/high16 v0, 0x7f0b0000

    invoke-virtual {p0, v0}, Lait/podka/About;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v4/view/ViewPager;

    iput-object v0, p0, Lait/podka/About;->b:Landroid/support/v4/view/ViewPager;

    iget-object v0, p0, Lait/podka/About;->b:Landroid/support/v4/view/ViewPager;

    iget-object v1, p0, Lait/podka/About;->a:Lait/podka/a;

    invoke-virtual {v0, v1}, Landroid/support/v4/view/ViewPager;->setAdapter(Landroid/support/v4/view/aa;)V

    iget-object v0, p0, Lait/podka/About;->b:Landroid/support/v4/view/ViewPager;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/support/v4/view/ViewPager;->setCurrentItem(I)V

    new-instance v0, Lcom/google/ads/AdView;

    sget-object v1, Lcom/google/ads/g;->a:Lcom/google/ads/g;

    const-string v2, "a14df515d674492"

    invoke-direct {v0, p0, v1, v2}, Lcom/google/ads/AdView;-><init>(Landroid/app/Activity;Lcom/google/ads/g;Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/About;->c:Lcom/google/ads/AdView;

    const v0, 0x7f0b0001

    invoke-virtual {p0, v0}, Lait/podka/About;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lait/podka/About;->c:Lcom/google/ads/AdView;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    iget-object v0, p0, Lait/podka/About;->c:Lcom/google/ads/AdView;

    new-instance v1, Lcom/google/ads/d;

    invoke-direct {v1}, Lcom/google/ads/d;-><init>()V

    invoke-virtual {v0, v1}, Lcom/google/ads/AdView;->a(Lcom/google/ads/d;)V

    return-void
.end method

.method public onDestroy()V
    .registers 2

    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->onDestroy()V

    iget-object v0, p0, Lait/podka/About;->c:Lcom/google/ads/AdView;

    invoke-virtual {v0}, Lcom/google/ads/AdView;->a()V

    return-void
.end method
