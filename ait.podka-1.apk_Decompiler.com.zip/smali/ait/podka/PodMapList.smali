###### Class ait.podka.PodMapList (ait.podka.PodMapList)
.class public Lait/podka/PodMapList;
.super Landroid/app/ListActivity;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/ListActivity;-><init>()V

    return-void
.end method

.method private a()Lorg/json/JSONObject;
    .registers 6

    invoke-virtual {p0}, Lait/podka/PodMapList;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "ids"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const-string v1, ","

    invoke-static {v1, v0}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Lorg/apache/http/message/BasicNameValuePair;

    const-string v4, "a"

    invoke-direct {v3, v4, v0}, Lorg/apache/http/message/BasicNameValuePair;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v0, Lorg/apache/http/impl/client/DefaultHttpClient;

    invoke-direct {v0}, Lorg/apache/http/impl/client/DefaultHttpClient;-><init>()V

    :try_start_25
    new-instance v3, Lorg/apache/http/client/entity/UrlEncodedFormEntity;

    const-string v4, "utf-8"

    invoke-direct {v3, v1, v4}, Lorg/apache/http/client/entity/UrlEncodedFormEntity;-><init>(Ljava/util/List;Ljava/lang/String;)V

    new-instance v1, Lorg/apache/http/client/methods/HttpPost;

    const-string v4, "http://www.podkicker.com/recommendations/maptwo.php"

    invoke-direct {v1, v4}, Lorg/apache/http/client/methods/HttpPost;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Lorg/apache/http/client/methods/HttpPost;->setEntity(Lorg/apache/http/HttpEntity;)V

    const-string v3, "User-Agent"

    sget-object v4, Lait/podka/Podka;->d:Ljava/lang/String;

    invoke-virtual {v1, v3, v4}, Lorg/apache/http/client/methods/HttpPost;->setHeader(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v1}, Landroid/net/http/AndroidHttpClient;->modifyRequestToAcceptGzipResponse(Lorg/apache/http/HttpRequest;)V

    invoke-interface {v0, v1}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;

    move-result-object v0

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-interface {v0}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    move-result-object v0

    invoke-static {v0}, Landroid/net/http/AndroidHttpClient;->getUngzippedContent(Lorg/apache/http/HttpEntity;)Ljava/io/InputStream;

    move-result-object v0

    invoke-direct {v3, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/16 v0, 0x2000

    invoke-direct {v1, v3, v0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_58
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_58} :catch_93
    .catchall {:try_start_25 .. :try_end_58} :catchall_91

    :try_start_58
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x800

    new-array v2, v2, [C

    :goto_61
    invoke-virtual {v1, v2}, Ljava/io/BufferedReader;->read([C)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_78

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_74
    .catch Ljava/lang/Exception; {:try_start_58 .. :try_end_74} :catch_7d
    .catchall {:try_start_58 .. :try_end_74} :catchall_7f

    :try_start_74
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_77
    .catch Ljava/io/IOException; {:try_start_74 .. :try_end_77} :catch_87

    :goto_77
    return-object v2

    :cond_78
    const/4 v4, 0x0

    :try_start_79
    invoke-virtual {v0, v2, v4, v3}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;
    :try_end_7c
    .catch Ljava/lang/Exception; {:try_start_79 .. :try_end_7c} :catch_7d
    .catchall {:try_start_79 .. :try_end_7c} :catchall_7f

    goto :goto_61

    :catch_7d
    move-exception v0

    :goto_7e
    :try_start_7e
    throw v0
    :try_end_7f
    .catchall {:try_start_7e .. :try_end_7f} :catchall_7f

    :catchall_7f
    move-exception v0

    move-object v2, v1

    :goto_81
    if-eqz v2, :cond_86

    :try_start_83
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_86
    .catch Ljava/io/IOException; {:try_start_83 .. :try_end_86} :catch_8c

    :cond_86
    :goto_86
    throw v0

    :catch_87
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_77

    :catch_8c
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_86

    :catchall_91
    move-exception v0

    goto :goto_81

    :catch_93
    move-exception v0

    move-object v1, v2

    goto :goto_7e
.end method

.method static synthetic a(Lait/podka/PodMapList;)Lorg/json/JSONObject;
    .registers 2

    invoke-direct {p0}, Lait/podka/PodMapList;->a()Lorg/json/JSONObject;

    move-result-object v0

    return-object v0
.end method

.method static synthetic a(Lait/podka/PodMapList;Ljava/util/List;)V
    .registers 6

    const/4 v3, 0x6

    new-array v0, v3, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "info"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "title"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "description"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "image_url"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "category"

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const-string v2, "url"

    aput-object v2, v0, v1

    new-array v1, v3, [I

    fill-array-data v1, :array_30

    new-instance v2, Lait/podka/a/o;

    invoke-direct {v2, p0, p1, v0, v1}, Lait/podka/a/o;-><init>(Landroid/content/Context;Ljava/util/List;[Ljava/lang/String;[I)V

    invoke-virtual {p0, v2}, Lait/podka/PodMapList;->setListAdapter(Landroid/widget/ListAdapter;)V

    return-void

    nop

    :array_30
    .array-data 4
        0x7f0b0002
        0x7f0b0004
        0x7f0b0005
        0x7f0b000d
        0x7f0b000c
        0x7f0b0003
    .end array-data
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 4

    const/4 v1, 0x0

    invoke-super {p0, p1}, Landroid/app/ListActivity;->onCreate(Landroid/os/Bundle;)V

    new-instance v0, Lait/podka/m;

    invoke-direct {v0, p0, v1}, Lait/podka/m;-><init>(Lait/podka/PodMapList;B)V

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lait/podka/m;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
