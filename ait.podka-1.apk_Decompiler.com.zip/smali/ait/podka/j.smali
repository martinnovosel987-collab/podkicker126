###### Class ait.podka.j (ait.podka.j)
.class final Lait/podka/j;
.super Landroid/os/AsyncTask;


# instance fields
.field a:Landroid/app/ProgressDialog;

.field final synthetic b:Lait/podka/PodMap;


# direct methods
.method private constructor <init>(Lait/podka/PodMap;)V
    .registers 2

    iput-object p1, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/PodMap;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/j;-><init>(Lait/podka/PodMap;)V

    return-void
.end method

.method static synthetic a(Lait/podka/j;)Lait/podka/PodMap;
    .registers 2

    iget-object v0, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    return-object v0
.end method

.method private varargs a()Ljava/util/List;
    .registers 3

    :try_start_0
    iget-object v0, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    iget-object v1, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-static {}, Lait/podka/PodMap;->a()Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v0, v1}, Lait/podka/PodMap;->a(Lait/podka/PodMap;Lorg/json/JSONObject;)Ljava/util/List;
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_b} :catch_d

    move-result-object v0

    :goto_c
    return-object v0

    :catch_d
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v0, 0x0

    goto :goto_c
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-direct {p0}, Lait/podka/j;->a()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 6

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, Lait/podka/j;->a:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V

    if-nez p1, :cond_2e

    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "Could not establish connection with server"

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "ok"

    new-instance v3, Lait/podka/k;

    invoke-direct {v3, p0}, Lait/podka/k;-><init>(Lait/podka/j;)V

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    :goto_2d
    return-void

    :cond_2e
    iget-object v0, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-virtual {v0}, Lait/podka/PodMap;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f020011

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    new-instance v1, Lait/podka/l;

    iget-object v2, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-direct {v1, v2, v0}, Lait/podka/l;-><init>(Lait/podka/PodMap;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, p1}, Lait/podka/l;->a(Ljava/util/List;)V

    iget-object v0, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-static {v0}, Lait/podka/PodMap;->b(Lait/podka/PodMap;)Lcom/google/android/maps/MapView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/maps/MapView;->getOverlays()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    invoke-static {v0}, Lait/podka/PodMap;->b(Lait/podka/PodMap;)Lcom/google/android/maps/MapView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/maps/MapView;->invalidate()V

    goto :goto_2d
.end method

.method protected final onPreExecute()V
    .registers 5

    const/4 v3, 0x1

    iget-object v0, p0, Lait/podka/j;->b:Lait/podka/PodMap;

    const/4 v1, 0x0

    const-string v2, "Searching for geotagged podcasts."

    invoke-static {v0, v1, v2, v3, v3}, Landroid/app/ProgressDialog;->show(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZZ)Landroid/app/ProgressDialog;

    move-result-object v0

    iput-object v0, p0, Lait/podka/j;->a:Landroid/app/ProgressDialog;

    return-void
.end method
