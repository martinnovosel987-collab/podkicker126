###### Class ait.podka.a (ait.podka.a)
.class final Lait/podka/a;
.super Landroid/support/v4/app/v;


# instance fields
.field final synthetic a:Lait/podka/About;


# direct methods
.method public constructor <init>(Lait/podka/About;Landroid/support/v4/app/m;)V
    .registers 3

    iput-object p1, p0, Lait/podka/a;->a:Lait/podka/About;

    invoke-direct {p0, p2}, Landroid/support/v4/app/v;-><init>(Landroid/support/v4/app/m;)V

    return-void
.end method


# virtual methods
.method public final a(I)Ljava/lang/CharSequence;
    .registers 3

    packed-switch p1, :pswitch_data_12

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0}, Ljava/lang/String;-><init>()V

    :goto_8
    return-object v0

    :pswitch_9
    const-string v0, "Help"

    goto :goto_8

    :pswitch_c
    const-string v0, "Changes"

    goto :goto_8

    :pswitch_f
    const-string v0, "Upgrade"

    goto :goto_8

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_9
        :pswitch_c
        :pswitch_f
    .end packed-switch
.end method

.method public final b(I)Landroid/support/v4/app/Fragment;
    .registers 6

    const/4 v3, 0x1

    iget-object v0, p0, Lait/podka/a;->a:Lait/podka/About;

    invoke-virtual {v0}, Lait/podka/About;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lait/podka/c/ao;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-static {v0, v1, v2}, Landroid/support/v4/app/Fragment;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;

    move-result-object v0

    packed-switch p1, :pswitch_data_38

    :goto_19
    return-object v0

    :pswitch_1a
    invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v1

    const-string v2, "showdoc"

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    goto :goto_19

    :pswitch_24
    invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v1

    const-string v2, "showlog"

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    goto :goto_19

    :pswitch_2e
    invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->k()Landroid/os/Bundle;

    move-result-object v1

    const-string v2, "showupgrade"

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    goto :goto_19

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_24
        :pswitch_2e
    .end packed-switch
.end method
