###### Class ait.podka.z (ait.podka.z)
.class final Lait/podka/z;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/UpdateRecommendationsActivity;


# direct methods
.method private constructor <init>(Lait/podka/UpdateRecommendationsActivity;)V
    .registers 2

    iput-object p1, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/UpdateRecommendationsActivity;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/z;-><init>(Lait/podka/UpdateRecommendationsActivity;)V

    return-void
.end method

.method private varargs a()Lorg/json/JSONObject;
    .registers 3

    :try_start_0
    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    iget-object v1, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    invoke-static {v1}, Lait/podka/UpdateRecommendationsActivity;->a(Lait/podka/UpdateRecommendationsActivity;)Ljava/util/List;

    move-result-object v1

    invoke-static {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->a(Lait/podka/UpdateRecommendationsActivity;Ljava/util/List;)Lorg/json/JSONObject;
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_b} :catch_d

    move-result-object v0

    :goto_c
    return-object v0

    :catch_d
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v0, 0x0

    goto :goto_c
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-direct {p0}, Lait/podka/z;->a()Lorg/json/JSONObject;

    move-result-object v0

    return-object v0
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 5

    const/4 v2, 0x1

    check-cast p1, Lorg/json/JSONObject;

    if-nez p1, :cond_36

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0003

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setClickable(Z)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0006

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setClickable(Z)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0009

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    invoke-static {v0}, Lait/podka/UpdateRecommendationsActivity;->b(Lait/podka/UpdateRecommendationsActivity;)V

    :goto_35
    return-void

    :cond_36
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    invoke-virtual {v1}, Lait/podka/UpdateRecommendationsActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lait/podka/PodSubscriberActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "json"

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v1, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    invoke-virtual {v1, v0}, Lait/podka/UpdateRecommendationsActivity;->startActivity(Landroid/content/Intent;)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    invoke-virtual {v0}, Lait/podka/UpdateRecommendationsActivity;->finish()V

    goto :goto_35
.end method

.method protected final onPreExecute()V
    .registers 4

    const/4 v2, 0x0

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0003

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setClickable(Z)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0006

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setClickable(Z)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0002

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lait/podka/z;->a:Lait/podka/UpdateRecommendationsActivity;

    const v1, 0x7f0b0009

    invoke-virtual {v0, v1}, Lait/podka/UpdateRecommendationsActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    invoke-virtual {v0, v2}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method
