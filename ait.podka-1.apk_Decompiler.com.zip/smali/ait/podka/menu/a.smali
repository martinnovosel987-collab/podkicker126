###### Class ait.podka.menu.a (ait.podka.menu.a)
.class public interface abstract Lait/podka/menu/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(II)V
.end method
