###### Class ait.podka.menu.PodkaMenu (ait.podka.menu.PodkaMenu)
.class public Lait/podka/menu/PodkaMenu;
.super Landroid/widget/HorizontalScrollView;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field a:I

.field b:I

.field private c:I

.field private d:I

.field private e:Lait/podka/menu/a;

.field private f:Landroid/view/LayoutInflater;

.field private g:Ljava/util/List;

.field private h:Landroid/graphics/Typeface;

.field private i:I


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .registers 4

    const/4 v1, -0x1

    invoke-direct {p0, p1}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    iput-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    iput v1, p0, Lait/podka/menu/PodkaMenu;->a:I

    iput v1, p0, Lait/podka/menu/PodkaMenu;->i:I

    const/4 v0, 0x0

    iput v0, p0, Lait/podka/menu/PodkaMenu;->b:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5

    const/4 v1, -0x1

    invoke-direct {p0, p1, p2}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    iput-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    iput v1, p0, Lait/podka/menu/PodkaMenu;->a:I

    iput v1, p0, Lait/podka/menu/PodkaMenu;->i:I

    const/4 v0, 0x0

    iput v0, p0, Lait/podka/menu/PodkaMenu;->b:I

    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    iput-object v0, p0, Lait/podka/menu/PodkaMenu;->f:Landroid/view/LayoutInflater;

    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->f:Landroid/view/LayoutInflater;

    const v1, 0x7f030014

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    const/4 v0, 0x0

    iput-object v0, p0, Lait/podka/menu/PodkaMenu;->h:Landroid/graphics/Typeface;

    return-void
.end method

.method private a(Landroid/view/View;)V
    .registers 8

    const/4 v1, 0x1

    const/high16 v5, 0x41200000    # 10.0f

    invoke-virtual {p1}, Landroid/view/View;->isSelected()Z

    move-result v0

    if-nez v0, :cond_f

    invoke-direct {p0}, Lait/podka/menu/PodkaMenu;->d()V

    invoke-virtual {p1, v1}, Landroid/view/View;->setSelected(Z)V

    :cond_f
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget v0, p0, Lait/podka/menu/PodkaMenu;->i:I

    if-le v2, v0, :cond_34

    const/4 v0, 0x2

    :goto_1e
    iget-object v1, p0, Lait/podka/menu/PodkaMenu;->e:Lait/podka/menu/a;

    if-eqz v1, :cond_27

    iget-object v1, p0, Lait/podka/menu/PodkaMenu;->e:Lait/podka/menu/a;

    invoke-interface {v1, v2, v0}, Lait/podka/menu/a;->a(II)V

    :cond_27
    iget v0, p0, Lait/podka/menu/PodkaMenu;->d:I

    if-eqz v0, :cond_31

    iget v0, p0, Lait/podka/menu/PodkaMenu;->d:I

    iget v1, p0, Lait/podka/menu/PodkaMenu;->c:I

    if-ge v0, v1, :cond_3c

    :cond_31
    :goto_31
    iput v2, p0, Lait/podka/menu/PodkaMenu;->i:I

    return-void

    :cond_34
    iget v0, p0, Lait/podka/menu/PodkaMenu;->i:I

    if-ge v2, v0, :cond_3a

    move v0, v1

    goto :goto_1e

    :cond_3a
    const/4 v0, 0x3

    goto :goto_1e

    :cond_3c
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v0

    invoke-virtual {p0}, Lait/podka/menu/PodkaMenu;->getScrollX()I

    move-result v1

    sub-int/2addr v0, v1

    iget v1, p0, Lait/podka/menu/PodkaMenu;->c:I

    sub-int/2addr v1, v0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    sub-int/2addr v1, v3

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v3

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v4

    div-int/lit8 v4, v4, 0x2

    add-int/2addr v3, v4

    if-ge v1, v0, :cond_92

    int-to-float v0, v3

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    int-to-float v3, v3

    iget v4, p0, Lait/podka/menu/PodkaMenu;->d:I

    int-to-float v4, v4

    div-float/2addr v3, v4

    mul-float/2addr v1, v3

    add-float/2addr v0, v1

    float-to-int v0, v0

    :goto_68
    iget v1, p0, Lait/podka/menu/PodkaMenu;->d:I

    iget v3, p0, Lait/podka/menu/PodkaMenu;->c:I

    sub-int/2addr v1, v3

    int-to-float v0, v0

    iget v3, p0, Lait/podka/menu/PodkaMenu;->d:I

    int-to-float v3, v3

    div-float/2addr v0, v3

    mul-float/2addr v0, v5

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    int-to-float v0, v0

    div-float/2addr v0, v5

    const v3, 0x3dcccccd    # 0.1f

    cmpg-float v3, v0, v3

    if-gtz v3, :cond_81

    const/4 v0, 0x0

    :cond_81
    const v3, 0x3f666666    # 0.9f

    cmpl-float v3, v0, v3

    if-ltz v3, :cond_8a

    const/high16 v0, 0x3f800000    # 1.0f

    :cond_8a
    int-to-float v1, v1

    mul-float/2addr v0, v1

    float-to-int v0, v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lait/podka/menu/PodkaMenu;->smoothScrollTo(II)V

    goto :goto_31

    :cond_92
    int-to-float v0, v3

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    int-to-float v3, v3

    iget v4, p0, Lait/podka/menu/PodkaMenu;->d:I

    int-to-float v4, v4

    div-float/2addr v3, v4

    mul-float/2addr v1, v3

    sub-float/2addr v0, v1

    float-to-int v0, v0

    goto :goto_68
.end method

.method private d()V
    .registers 4

    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_d

    return-void

    :cond_d
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setSelected(Z)V

    goto :goto_6
.end method


# virtual methods
.method public final a()V
    .registers 2

    const/4 v0, -0x1

    iput v0, p0, Lait/podka/menu/PodkaMenu;->i:I

    invoke-virtual {p0}, Lait/podka/menu/PodkaMenu;->c()I

    move-result v0

    iput v0, p0, Lait/podka/menu/PodkaMenu;->a:I

    invoke-direct {p0}, Lait/podka/menu/PodkaMenu;->d()V

    return-void
.end method

.method public final a(I)V
    .registers 3

    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    if-eqz v0, :cond_d

    invoke-direct {p0, v0}, Lait/podka/menu/PodkaMenu;->a(Landroid/view/View;)V

    :cond_d
    return-void
.end method

.method public final a(Ljava/lang/String;)V
    .registers 5

    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->f:Landroid/view/LayoutInflater;

    const v1, 0x7f030015

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iget-object v1, p0, Lait/podka/menu/PodkaMenu;->h:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v1, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    iget-object v1, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lait/podka/menu/PodkaMenu;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method public final b()V
    .registers 3

    invoke-virtual {p0}, Lait/podka/menu/PodkaMenu;->c()I

    move-result v0

    if-gez v0, :cond_19

    iget v0, p0, Lait/podka/menu/PodkaMenu;->a:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_19

    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    iget v1, p0, Lait/podka/menu/PodkaMenu;->a:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setSelected(Z)V

    :cond_19
    return-void
.end method

.method public final c()I
    .registers 3

    const/4 v0, 0x0

    move v1, v0

    :goto_2
    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lt v1, v0, :cond_c

    const/4 v1, -0x1

    :cond_b
    return v1

    :cond_c
    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->isSelected()Z

    move-result v0

    if-nez v0, :cond_b

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_2
.end method

.method public onClick(Landroid/view/View;)V
    .registers 2

    invoke-direct {p0, p1}, Lait/podka/menu/PodkaMenu;->a(Landroid/view/View;)V

    return-void
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 11

    const/4 v4, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    float-to-int v5, v0

    invoke-virtual {p0, v2}, Lait/podka/menu/PodkaMenu;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    if-lez v1, :cond_1f

    invoke-virtual {p0}, Lait/podka/menu/PodkaMenu;->getScrollX()I

    move-result v6

    move v1, v2

    :goto_19
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v7

    if-lt v1, v7, :cond_34

    :cond_1f
    move v1, v4

    :cond_20
    if-eq v1, v4, :cond_49

    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput v1, p0, Lait/podka/menu/PodkaMenu;->b:I

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    packed-switch v1, :pswitch_data_88

    :cond_33
    :goto_33
    :pswitch_33
    return v2

    :cond_34
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/View;->getLeft()I

    move-result v8

    sub-int/2addr v8, v6

    if-lt v5, v8, :cond_46

    invoke-virtual {v7}, Landroid/view/View;->getRight()I

    move-result v7

    sub-int/2addr v7, v6

    if-lt v5, v7, :cond_20

    :cond_46
    add-int/lit8 v1, v1, 0x1

    goto :goto_19

    :cond_49
    iget-object v0, p0, Lait/podka/menu/PodkaMenu;->g:Ljava/util/List;

    iget v1, p0, Lait/podka/menu/PodkaMenu;->b:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    invoke-direct {p0, v0}, Lait/podka/menu/PodkaMenu;->a(Landroid/view/View;)V

    move v2, v3

    goto :goto_33

    :pswitch_58
    if-eqz v0, :cond_5d

    invoke-direct {p0, v0}, Lait/podka/menu/PodkaMenu;->a(Landroid/view/View;)V

    :cond_5d
    move v2, v3

    goto :goto_33

    :pswitch_5f
    if-eqz v0, :cond_6d

    invoke-virtual {v0}, Landroid/widget/Button;->isSelected()Z

    move-result v1

    if-nez v1, :cond_6d

    invoke-direct {p0}, Lait/podka/menu/PodkaMenu;->d()V

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setSelected(Z)V

    :cond_6d
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getHistorySize()I

    move-result v0

    if-lez v0, :cond_33

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getHistorySize()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getHistoricalX(I)F

    move-result v1

    sub-float/2addr v0, v1

    float-to-int v0, v0

    invoke-virtual {p0, v0, v2}, Lait/podka/menu/PodkaMenu;->scrollBy(II)V

    goto :goto_33

    nop

    :pswitch_data_88
    .packed-switch 0x0
        :pswitch_33
        :pswitch_58
        :pswitch_5f
        :pswitch_33
    .end packed-switch
.end method

.method protected onLayout(ZIIII)V
    .registers 8

    const/4 v1, 0x0

    invoke-super/range {p0 .. p5}, Landroid/widget/HorizontalScrollView;->onLayout(ZIIII)V

    invoke-virtual {p0}, Lait/podka/menu/PodkaMenu;->getWidth()I

    move-result v0

    iput v0, p0, Lait/podka/menu/PodkaMenu;->c:I

    invoke-virtual {p0}, Lait/podka/menu/PodkaMenu;->computeHorizontalScrollRange()I

    move-result v0

    iput v0, p0, Lait/podka/menu/PodkaMenu;->d:I

    invoke-virtual {p0, v1}, Lait/podka/menu/PodkaMenu;->setVerticalScrollBarEnabled(Z)V

    invoke-virtual {p0, v1}, Lait/podka/menu/PodkaMenu;->setHorizontalScrollBarEnabled(Z)V

    return-void
.end method

.method public setOnMenuItemClickedListener(Lait/podka/menu/a;)V
    .registers 2

    iput-object p1, p0, Lait/podka/menu/PodkaMenu;->e:Lait/podka/menu/a;

    return-void
.end method
