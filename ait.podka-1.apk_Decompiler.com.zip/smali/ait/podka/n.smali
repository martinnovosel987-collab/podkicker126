###### Class ait.podka.n (ait.podka.n)
.class final Lait/podka/n;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/m;


# direct methods
.method constructor <init>(Lait/podka/m;)V
    .registers 2

    iput-object p1, p0, Lait/podka/n;->a:Lait/podka/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget-object v0, p0, Lait/podka/n;->a:Lait/podka/m;

    invoke-static {v0}, Lait/podka/m;->a(Lait/podka/m;)Lait/podka/PodMapList;

    move-result-object v0

    invoke-virtual {v0}, Lait/podka/PodMapList;->finish()V

    return-void
.end method
