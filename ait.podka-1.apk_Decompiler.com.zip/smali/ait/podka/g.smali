###### Class ait.podka.g (ait.podka.g)
.class final Lait/podka/g;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/Notification;


# direct methods
.method constructor <init>(Lait/podka/Notification;)V
    .registers 2

    iput-object p1, p0, Lait/podka/g;->a:Lait/podka/Notification;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "market://details?id=com.podkicker"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    iget-object v1, p0, Lait/podka/g;->a:Lait/podka/Notification;

    invoke-virtual {v1, v0}, Lait/podka/Notification;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
