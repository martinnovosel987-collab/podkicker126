###### Class ait.podka.q (ait.podka.q)
.class final Lait/podka/q;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/p;


# direct methods
.method constructor <init>(Lait/podka/p;)V
    .registers 2

    iput-object p1, p0, Lait/podka/q;->a:Lait/podka/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    const/4 v6, 0x0

    new-instance v0, Lait/podka/b/i;

    iget-object v1, p0, Lait/podka/q;->a:Lait/podka/p;

    invoke-static {v1}, Lait/podka/p;->a(Lait/podka/p;)Lait/podka/Prefs;

    move-result-object v1

    invoke-virtual {v1}, Lait/podka/Prefs;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lait/podka/b/i;-><init>(Landroid/content/Context;)V

    invoke-static {}, Landroid/util/Xml;->newSerializer()Lorg/xmlpull/v1/XmlSerializer;

    move-result-object v7

    :try_start_14
    new-instance v1, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v2

    const-string v3, "podkicker_backup.opml"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    new-instance v8, Ljava/io/OutputStreamWriter;

    const-string v1, "UTF-8"

    invoke-direct {v8, v2, v1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/lang/String;)V
    :try_end_2b
    .catch Ljava/io/FileNotFoundException; {:try_start_14 .. :try_end_2b} :catch_bf
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_14 .. :try_end_2b} :catch_c4

    :try_start_2b
    invoke-interface {v7, v8}, Lorg/xmlpull/v1/XmlSerializer;->setOutput(Ljava/io/Writer;)V

    const-string v1, "UTF-8"

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V

    const-string v1, ""

    const-string v2, "opml"

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, ""

    const-string v2, "version"

    const-string v3, "2.0"

    invoke-interface {v7, v1, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, ""

    const-string v2, "head"

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, ""

    const-string v2, "dateCreated"

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, "%tc"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v7, v1}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, ""

    const-string v2, "dateCreated"

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, ""

    const-string v2, "head"

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, ""

    const-string v2, "body"

    invoke-interface {v7, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    iget-object v0, v0, Lait/podka/b/i;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, 0x2

    new-array v2, v1, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v3, "ch_feedlink"

    aput-object v3, v2, v1

    const/4 v1, 0x1

    const-string v3, "ch_title"

    aput-object v3, v2, v1

    sget-object v1, Lait/podka/database/d;->a:Landroid/net/Uri;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    :try_end_99
    .catch Ljava/io/IOException; {:try_start_2b .. :try_end_99} :catch_126
    .catchall {:try_start_2b .. :try_end_99} :catchall_10f

    move-result-object v1

    :goto_9a
    if-eqz v1, :cond_a2

    :try_start_9c
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-nez v0, :cond_c9

    :cond_a2
    const-string v0, ""

    const-string v2, "body"

    invoke-interface {v7, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, ""

    const-string v2, "opml"

    invoke-interface {v7, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {v7}, Lorg/xmlpull/v1/XmlSerializer;->endDocument()V

    invoke-interface {v7}, Lorg/xmlpull/v1/XmlSerializer;->flush()V
    :try_end_b6
    .catch Ljava/io/IOException; {:try_start_9c .. :try_end_b6} :catch_fd
    .catchall {:try_start_9c .. :try_end_b6} :catchall_123

    if-eqz v1, :cond_bb

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_bb
    :try_start_bb
    invoke-virtual {v8}, Ljava/io/OutputStreamWriter;->close()V
    :try_end_be
    .catch Ljava/io/IOException; {:try_start_bb .. :try_end_be} :catch_11e

    :goto_be
    return-void

    :catch_bf
    move-exception v0

    invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V

    goto :goto_be

    :catch_c4
    move-exception v0

    invoke-virtual {v0}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto :goto_be

    :cond_c9
    :try_start_c9
    const-string v0, ""

    const-string v2, "outline"

    invoke-interface {v7, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, ""

    const-string v2, "text"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v7, v0, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, ""

    const-string v2, "xmlUrl"

    const/4 v3, 0x0

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v7, v0, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, ""

    const-string v2, "outline"

    invoke-interface {v7, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    :try_end_fc
    .catch Ljava/io/IOException; {:try_start_c9 .. :try_end_fc} :catch_fd
    .catchall {:try_start_c9 .. :try_end_fc} :catchall_123

    goto :goto_9a

    :catch_fd
    move-exception v0

    :goto_fe
    :try_start_fe
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V
    :try_end_101
    .catchall {:try_start_fe .. :try_end_101} :catchall_123

    if-eqz v1, :cond_106

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_106
    :try_start_106
    invoke-virtual {v8}, Ljava/io/OutputStreamWriter;->close()V
    :try_end_109
    .catch Ljava/io/IOException; {:try_start_106 .. :try_end_109} :catch_10a

    goto :goto_be

    :catch_10a
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_be

    :catchall_10f
    move-exception v0

    :goto_110
    if-eqz v6, :cond_115

    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    :cond_115
    :try_start_115
    invoke-virtual {v8}, Ljava/io/OutputStreamWriter;->close()V
    :try_end_118
    .catch Ljava/io/IOException; {:try_start_115 .. :try_end_118} :catch_119

    :goto_118
    throw v0

    :catch_119
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_118

    :catch_11e
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_be

    :catchall_123
    move-exception v0

    move-object v6, v1

    goto :goto_110

    :catch_126
    move-exception v0

    move-object v1, v6

    goto :goto_fe
.end method
