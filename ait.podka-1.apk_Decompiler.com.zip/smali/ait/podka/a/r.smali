###### Class ait.podka.a.r (ait.podka.a.r)
.class final Lait/podka/a/r;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/a/o;

.field private final synthetic b:Ljava/lang/String;

.field private final synthetic c:Ljava/lang/String;


# direct methods
.method constructor <init>(Lait/podka/a/o;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    iput-object p1, p0, Lait/podka/a/r;->a:Lait/podka/a/o;

    iput-object p2, p0, Lait/podka/a/r;->b:Ljava/lang/String;

    iput-object p3, p0, Lait/podka/a/r;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/a/r;->a:Lait/podka/a/o;

    invoke-static {v0}, Lait/podka/a/o;->b(Lait/podka/a/o;)Lait/podka/b/b;

    move-result-object v0

    iget-object v1, p0, Lait/podka/a/r;->b:Ljava/lang/String;

    iget-object v2, p0, Lait/podka/a/r;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lait/podka/b/b;->c(Ljava/lang/String;)V

    return-void
.end method
