###### Class ait.podka.a.k (ait.podka.a.k)
.class final Lait/podka/a/k;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/a/i;

.field private final synthetic b:J

.field private final synthetic c:Lait/podka/a/l;

.field private final synthetic d:I


# direct methods
.method constructor <init>(Lait/podka/a/i;JLait/podka/a/l;I)V
    .registers 6

    iput-object p1, p0, Lait/podka/a/k;->a:Lait/podka/a/i;

    iput-wide p2, p0, Lait/podka/a/k;->b:J

    iput-object p4, p0, Lait/podka/a/k;->c:Lait/podka/a/l;

    iput p5, p0, Lait/podka/a/k;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-wide v0, p0, Lait/podka/a/k;->b:J

    iget-object v2, p0, Lait/podka/a/k;->c:Lait/podka/a/l;

    iget-wide v2, v2, Lait/podka/a/l;->a:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_b

    :goto_a
    return-void

    :cond_b
    iget-object v0, p0, Lait/podka/a/k;->c:Lait/podka/a/l;

    iget-boolean v0, v0, Lait/podka/a/l;->e:Z

    if-nez v0, :cond_1a

    iget-object v0, p0, Lait/podka/a/k;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->q:Landroid/widget/TextView;

    const-string v1, "Downloading"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1a
    iget-object v0, p0, Lait/podka/a/k;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    iget v1, p0, Lait/podka/a/k;->d:I

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v0, p0, Lait/podka/a/k;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->o:Landroid/widget/TextView;

    iget v1, p0, Lait/podka/a/k;->d:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lait/podka/d/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_a
.end method
