###### Class ait.podka.a.j (ait.podka.a.j)
.class final Lait/podka/a/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/a/i;

.field private final synthetic b:J

.field private final synthetic c:Lait/podka/a/l;

.field private final synthetic d:I


# direct methods
.method constructor <init>(Lait/podka/a/i;JLait/podka/a/l;I)V
    .registers 6

    iput-object p1, p0, Lait/podka/a/j;->a:Lait/podka/a/i;

    iput-wide p2, p0, Lait/podka/a/j;->b:J

    iput-object p4, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iput p5, p0, Lait/podka/a/j;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-wide v0, p0, Lait/podka/a/j;->b:J

    iget-object v2, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget-wide v2, v2, Lait/podka/a/l;->a:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_b

    :goto_a
    return-void

    :cond_b
    iget-object v0, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    iget v1, p0, Lait/podka/a/j;->d:I

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v0, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->m:Landroid/view/ViewGroup;

    iget-object v1, p0, Lait/podka/a/j;->a:Lait/podka/a/i;

    iget-object v1, v1, Lait/podka/a/i;->a:Lait/podka/a/h;

    invoke-static {v1}, Lait/podka/a/h;->b(Lait/podka/a/h;)Landroid/view/animation/Animation;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->startAnimation(Landroid/view/animation/Animation;)V

    iget-object v0, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->m:Landroid/view/ViewGroup;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    iget-object v0, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lait/podka/a/l;->d:Z

    iget-object v0, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->q:Landroid/widget/TextView;

    const-string v1, "Completed"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget-object v0, v0, Lait/podka/a/l;->q:Landroid/widget/TextView;

    iget-object v1, p0, Lait/podka/a/j;->c:Lait/podka/a/l;

    iget v1, v1, Lait/podka/a/l;->l:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_a
.end method
