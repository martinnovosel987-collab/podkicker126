###### Class ait.podka.a.e (ait.podka.a.e)
.class public final Lait/podka/a/e;
.super Landroid/support/v4/widget/c;


# instance fields
.field private final j:Landroid/view/LayoutInflater;

.field private final k:Ljava/io/File;

.field private final l:Lait/podka/a/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Landroid/support/v4/widget/c;-><init>(Landroid/content/Context;Landroid/database/Cursor;I)V

    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    iput-object v0, p0, Lait/podka/a/e;->j:Landroid/view/LayoutInflater;

    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "/Android/data/"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/cache/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/a/e;->k:Ljava/io/File;

    iget-object v0, p0, Lait/podka/a/e;->k:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    new-instance v0, Lait/podka/a/f;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    invoke-direct {v0, p0}, Lait/podka/a/f;-><init>(Lait/podka/a/e;)V

    iput-object v0, p0, Lait/podka/a/e;->l:Lait/podka/a/a;

    return-void
.end method

.method static synthetic a(Lait/podka/a/e;)Ljava/io/File;
    .registers 2

    iget-object v0, p0, Lait/podka/a/e;->k:Ljava/io/File;

    return-object v0
.end method


# virtual methods
.method public final a(Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 6

    const/4 v3, 0x0

    iget-object v0, p0, Lait/podka/a/e;->j:Landroid/view/LayoutInflater;

    const v1, 0x7f030009

    invoke-virtual {v0, v1, p1, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lait/podka/a/g;

    invoke-direct {v2, v3}, Lait/podka/a/g;-><init>(B)V

    const v0, 0x7f0b001a

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/g;->a:Landroid/widget/TextView;

    const v0, 0x7f0b0019

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, v2, Lait/podka/a/g;->b:Landroid/widget/ImageView;

    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    return-object v1
.end method

.method public final a(Landroid/view/View;Landroid/database/Cursor;)V
    .registers 7

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lait/podka/a/g;

    const-string v1, "ch_title"

    invoke-interface {p2, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p2, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "\\p{Cntrl}"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, Lait/podka/a/g;->a:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v1, "ch_imageurl"

    invoke-interface {p2, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p2, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lait/podka/a/e;->l:Lait/podka/a/a;

    iget-object v3, v0, Lait/podka/a/g;->b:Landroid/widget/ImageView;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_3a

    move-object v0, v1

    :goto_36
    invoke-virtual {v2, v3, v0}, Lait/podka/a/a;->a(Landroid/widget/ImageView;Ljava/lang/Object;)V

    return-void

    :cond_3a
    const/4 v0, 0x0

    goto :goto_36
.end method
