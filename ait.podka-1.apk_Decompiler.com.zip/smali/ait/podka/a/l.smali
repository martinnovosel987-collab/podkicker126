###### Class ait.podka.a.l (ait.podka.a.l)
.class public final Lait/podka/a/l;
.super Ljava/lang/Object;


# instance fields
.field public volatile a:J

.field public b:Ljava/lang/String;

.field public c:Landroid/widget/TextView;

.field public d:Z

.field public e:Z

.field public f:Z

.field public g:Z

.field public h:Landroid/widget/TextView;

.field public i:Landroid/widget/TextView;

.field public j:Landroid/widget/ProgressBar;

.field public k:I

.field public l:I

.field public m:Landroid/view/ViewGroup;

.field public n:Landroid/widget/TextView;

.field public o:Landroid/widget/TextView;

.field public p:Landroid/widget/TextView;

.field public q:Landroid/widget/TextView;

.field public r:Ljava/lang/String;

.field public s:J


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
