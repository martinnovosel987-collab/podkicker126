###### Class ait.podka.a.d (ait.podka.a.d)
.class final Lait/podka/a/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/a/c;

.field private final synthetic b:Landroid/graphics/Bitmap;


# direct methods
.method constructor <init>(Lait/podka/a/c;Landroid/graphics/Bitmap;)V
    .registers 3

    iput-object p1, p0, Lait/podka/a/d;->a:Lait/podka/a/c;

    iput-object p2, p0, Lait/podka/a/d;->b:Landroid/graphics/Bitmap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lait/podka/a/d;->a:Lait/podka/a/c;

    invoke-static {v0}, Lait/podka/a/c;->a(Lait/podka/a/c;)Landroid/widget/ImageView;

    move-result-object v0

    iget-object v1, p0, Lait/podka/a/d;->a:Lait/podka/a/c;

    invoke-static {v1}, Lait/podka/a/c;->a(Lait/podka/a/c;)Landroid/widget/ImageView;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x7f040000

    invoke-static {v1, v2}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->startAnimation(Landroid/view/animation/Animation;)V

    iget-object v0, p0, Lait/podka/a/d;->a:Lait/podka/a/c;

    invoke-static {v0}, Lait/podka/a/c;->a(Lait/podka/a/c;)Landroid/widget/ImageView;

    move-result-object v0

    iget-object v1, p0, Lait/podka/a/d;->b:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    return-void
.end method
