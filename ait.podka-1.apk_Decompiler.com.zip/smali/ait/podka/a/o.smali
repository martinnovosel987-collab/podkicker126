###### Class ait.podka.a.o (ait.podka.a.o)
.class public final Lait/podka/a/o;
.super Landroid/widget/SimpleAdapter;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private a:Lait/podka/a/a;

.field private b:Ljava/util/List;

.field private c:Landroid/view/animation/Animation;

.field private d:Ljava/util/Set;

.field private e:Lait/podka/b/b;

.field private f:Ljava/io/File;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;[Ljava/lang/String;[I)V
    .registers 11

    const v3, 0x7f03000d

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, Landroid/widget/SimpleAdapter;-><init>(Landroid/content/Context;Ljava/util/List;I[Ljava/lang/String;[I)V

    iput-object p2, p0, Lait/podka/a/o;->b:Ljava/util/List;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lait/podka/a/o;->d:Ljava/util/Set;

    const v0, 0x7f040001

    invoke-static {p1, v0}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v0

    iput-object v0, p0, Lait/podka/a/o;->c:Landroid/view/animation/Animation;

    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "/Android/data/"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/cache/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lait/podka/a/o;->f:Ljava/io/File;

    iget-object v0, p0, Lait/podka/a/o;->f:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    new-instance v0, Lait/podka/b/b;

    invoke-direct {v0, p1}, Lait/podka/b/b;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/a/o;->e:Lait/podka/b/b;

    new-instance v0, Lait/podka/a/p;

    invoke-direct {v0, p0, p1}, Lait/podka/a/p;-><init>(Lait/podka/a/o;Landroid/content/Context;)V

    iput-object v0, p0, Lait/podka/a/o;->a:Lait/podka/a/a;

    new-instance v0, Lait/podka/a/q;

    invoke-direct {v0, p0}, Lait/podka/a/q;-><init>(Lait/podka/a/o;)V

    invoke-virtual {p0, v0}, Lait/podka/a/o;->setViewBinder(Landroid/widget/SimpleAdapter$ViewBinder;)V

    return-void
.end method

.method static synthetic a(Lait/podka/a/o;)Ljava/io/File;
    .registers 2

    iget-object v0, p0, Lait/podka/a/o;->f:Ljava/io/File;

    return-object v0
.end method

.method static synthetic a(Lait/podka/a/o;Landroid/widget/Button;Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p1, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1, p2}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    iget-object v0, p0, Lait/podka/a/o;->d:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setVisibility(I)V

    :goto_12
    return-void

    :cond_13
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_12
.end method

.method static synthetic b(Lait/podka/a/o;)Lait/podka/b/b;
    .registers 2

    iget-object v0, p0, Lait/podka/a/o;->e:Lait/podka/b/b;

    return-object v0
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    const-string v1, ""

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v0, p0, Lait/podka/a/o;->d:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lait/podka/a/o;->b:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_15
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_37

    :goto_1b
    move-object v0, p1

    check-cast v0, Landroid/widget/Button;

    iget-object v3, p0, Lait/podka/a/o;->c:Landroid/view/animation/Animation;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->startAnimation(Landroid/view/animation/Animation;)V

    check-cast p1, Landroid/widget/Button;

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setVisibility(I)V

    new-instance v0, Ljava/lang/Thread;

    new-instance v3, Lait/podka/a/r;

    invoke-direct {v3, p0, v2, v1}, Lait/podka/a/r;-><init>(Lait/podka/a/o;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :cond_37
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    const-string v4, "url"

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_15

    const-string v1, "title"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    goto :goto_1b
.end method

.method public final setViewImage(Landroid/widget/ImageView;Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Lait/podka/a/o;->a:Lait/podka/a/a;

    invoke-virtual {v0, p1, p2}, Lait/podka/a/a;->a(Landroid/widget/ImageView;Ljava/lang/Object;)V

    return-void
.end method
