###### Class ait.podka.a.i (ait.podka.a.i)
.class final Lait/podka/a/i;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/a/h;

.field private final synthetic b:J

.field private final synthetic c:Lait/podka/a/l;

.field private final synthetic d:Ljava/io/File;

.field private final synthetic e:I

.field private final synthetic f:Ljava/io/File;


# direct methods
.method constructor <init>(Lait/podka/a/h;JLait/podka/a/l;Ljava/io/File;ILjava/io/File;)V
    .registers 8

    iput-object p1, p0, Lait/podka/a/i;->a:Lait/podka/a/h;

    iput-wide p2, p0, Lait/podka/a/i;->b:J

    iput-object p4, p0, Lait/podka/a/i;->c:Lait/podka/a/l;

    iput-object p5, p0, Lait/podka/a/i;->d:Ljava/io/File;

    iput p6, p0, Lait/podka/a/i;->e:I

    iput-object p7, p0, Lait/podka/a/i;->f:Ljava/io/File;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    :goto_0
    iget-wide v0, p0, Lait/podka/a/i;->b:J

    iget-object v2, p0, Lait/podka/a/i;->c:Lait/podka/a/l;

    iget-wide v2, v2, Lait/podka/a/l;->a:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_b

    :goto_a
    return-void

    :cond_b
    iget-object v0, p0, Lait/podka/a/i;->d:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v0

    long-to-int v5, v0

    iget v0, p0, Lait/podka/a/i;->e:I

    if-ne v5, v0, :cond_1a

    iget v0, p0, Lait/podka/a/i;->e:I

    if-nez v0, :cond_24

    :cond_1a
    if-nez v5, :cond_43

    iget-object v0, p0, Lait/podka/a/i;->f:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_43

    :cond_24
    iget-object v0, p0, Lait/podka/a/i;->a:Lait/podka/a/h;

    invoke-static {v0}, Lait/podka/a/h;->a(Lait/podka/a/h;)Landroid/os/Handler;

    move-result-object v6

    monitor-enter v6

    :try_start_2b
    iget-object v0, p0, Lait/podka/a/i;->a:Lait/podka/a/h;

    invoke-static {v0}, Lait/podka/a/h;->a(Lait/podka/a/h;)Landroid/os/Handler;

    move-result-object v7

    new-instance v0, Lait/podka/a/j;

    iget-wide v2, p0, Lait/podka/a/i;->b:J

    iget-object v4, p0, Lait/podka/a/i;->c:Lait/podka/a/l;

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lait/podka/a/j;-><init>(Lait/podka/a/i;JLait/podka/a/l;I)V

    invoke-virtual {v7, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    monitor-exit v6
    :try_end_3f
    .catchall {:try_start_2b .. :try_end_3f} :catchall_40

    goto :goto_a

    :catchall_40
    move-exception v0

    monitor-exit v6

    throw v0

    :cond_43
    iget-object v0, p0, Lait/podka/a/i;->a:Lait/podka/a/h;

    invoke-static {v0}, Lait/podka/a/h;->a(Lait/podka/a/h;)Landroid/os/Handler;

    move-result-object v6

    monitor-enter v6

    :try_start_4a
    iget-object v0, p0, Lait/podka/a/i;->a:Lait/podka/a/h;

    invoke-static {v0}, Lait/podka/a/h;->a(Lait/podka/a/h;)Landroid/os/Handler;

    move-result-object v7

    new-instance v0, Lait/podka/a/k;

    iget-wide v2, p0, Lait/podka/a/i;->b:J

    iget-object v4, p0, Lait/podka/a/i;->c:Lait/podka/a/l;

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lait/podka/a/k;-><init>(Lait/podka/a/i;JLait/podka/a/l;I)V

    invoke-virtual {v7, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    monitor-exit v6
    :try_end_5e
    .catchall {:try_start_4a .. :try_end_5e} :catchall_66

    const-wide/16 v0, 0x172

    :try_start_60
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_63
    .catch Ljava/lang/InterruptedException; {:try_start_60 .. :try_end_63} :catch_64

    goto :goto_0

    :catch_64
    move-exception v0

    goto :goto_a

    :catchall_66
    move-exception v0

    monitor-exit v6

    throw v0
.end method
