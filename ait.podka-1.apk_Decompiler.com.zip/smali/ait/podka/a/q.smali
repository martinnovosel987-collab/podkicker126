###### Class ait.podka.a.q (ait.podka.a.q)
.class final Lait/podka/a/q;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/SimpleAdapter$ViewBinder;


# instance fields
.field final synthetic a:Lait/podka/a/o;


# direct methods
.method constructor <init>(Lait/podka/a/o;)V
    .registers 2

    iput-object p1, p0, Lait/podka/a/q;->a:Lait/podka/a/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final setViewValue(Landroid/view/View;Ljava/lang/Object;Ljava/lang/String;)Z
    .registers 6

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b0003

    if-ne v0, v1, :cond_12

    iget-object v0, p0, Lait/podka/a/q;->a:Lait/podka/a/o;

    check-cast p1, Landroid/widget/Button;

    invoke-static {v0, p1, p3}, Lait/podka/a/o;->a(Lait/podka/a/o;Landroid/widget/Button;Ljava/lang/String;)V

    const/4 v0, 0x1

    :goto_11
    return v0

    :cond_12
    const/4 v0, 0x0

    goto :goto_11
.end method
