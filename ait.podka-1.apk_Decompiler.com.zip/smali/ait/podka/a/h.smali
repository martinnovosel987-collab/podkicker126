###### Class ait.podka.a.h (ait.podka.a.h)
.class public final Lait/podka/a/h;
.super Landroid/support/v4/widget/c;


# instance fields
.field private final j:J

.field private final k:Landroid/view/LayoutInflater;

.field private final l:Landroid/os/Handler;

.field private final m:Landroid/view/animation/Animation;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Landroid/support/v4/widget/c;-><init>(Landroid/content/Context;Landroid/database/Cursor;I)V

    const-wide/16 v0, 0x172

    iput-wide v0, p0, Lait/podka/a/h;->j:J

    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    iput-object v0, p0, Lait/podka/a/h;->k:Landroid/view/LayoutInflater;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lait/podka/a/h;->l:Landroid/os/Handler;

    const v0, 0x7f040001

    invoke-static {p1, v0}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v0

    iput-object v0, p0, Lait/podka/a/h;->m:Landroid/view/animation/Animation;

    return-void
.end method

.method static synthetic a(Lait/podka/a/h;)Landroid/os/Handler;
    .registers 2

    iget-object v0, p0, Lait/podka/a/h;->l:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic b(Lait/podka/a/h;)Landroid/view/animation/Animation;
    .registers 2

    iget-object v0, p0, Lait/podka/a/h;->m:Landroid/view/animation/Animation;

    return-object v0
.end method


# virtual methods
.method public final a(Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 6

    iget-object v0, p0, Lait/podka/a/h;->k:Landroid/view/LayoutInflater;

    const v1, 0x7f03000a

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lait/podka/a/l;

    invoke-direct {v2}, Lait/podka/a/l;-><init>()V

    const v0, 0x7f0b001e

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    iput-object v0, v2, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    const v0, 0x7f0b001b

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->h:Landroid/widget/TextView;

    const v0, 0x7f0b0021

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->n:Landroid/widget/TextView;

    const v0, 0x7f0b001c

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->i:Landroid/widget/TextView;

    const v0, 0x7f0b0022

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->c:Landroid/widget/TextView;

    const v0, 0x7f0b001f

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->o:Landroid/widget/TextView;

    const v0, 0x7f0b0023

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->q:Landroid/widget/TextView;

    const v0, 0x7f0b0020

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, v2, Lait/podka/a/l;->p:Landroid/widget/TextView;

    const v0, 0x7f0b001d

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iput-object v0, v2, Lait/podka/a/l;->m:Landroid/view/ViewGroup;

    iget-object v0, p0, Lait/podka/a/h;->d:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v3, 0x7f060006

    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    iput v0, v2, Lait/podka/a/l;->l:I

    iget-object v0, p0, Lait/podka/a/h;->d:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v3, 0x7f060001

    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    iput v0, v2, Lait/podka/a/l;->k:I

    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    return-object v1
.end method

.method public final a(Landroid/view/View;Landroid/database/Cursor;)V
    .registers 20

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lait/podka/a/l;

    const-string v1, "enc_filename"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "enc_queue"

    move-object/from16 v0, p2

    invoke-interface {v0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v2

    move-object/from16 v0, p2

    invoke-interface {v0, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v9

    new-instance v6, Ljava/io/File;

    sget-object v2, Lait/podka/Podka;->f:Ljava/io/File;

    invoke-direct {v6, v2, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v8, Ljava/io/File;

    sget-object v2, Lait/podka/Podka;->g:Ljava/io/File;

    invoke-direct {v8, v2, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const-string v1, "enc_err"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v1, "enc_size"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v7

    const-string v1, "_id"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v3

    const-string v1, "enc_parent"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    const-string v1, "enc_type"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v13

    iget-wide v14, v5, Lait/podka/a/l;->a:J

    iget-object v1, v5, Lait/podka/a/l;->m:Landroid/view/ViewGroup;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/view/ViewGroup;->setVisibility(I)V

    iget-object v1, v5, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v1, v5, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    const/16 v14, 0x64

    invoke-virtual {v1, v14}, Landroid/widget/ProgressBar;->setMax(I)V

    const/4 v1, 0x0

    iput-object v1, v5, Lait/podka/a/l;->b:Ljava/lang/String;

    const/4 v1, 0x0

    iput-boolean v1, v5, Lait/podka/a/l;->f:Z

    iget-object v1, v5, Lait/podka/a/l;->c:Landroid/widget/TextView;

    const/4 v14, 0x4

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setVisibility(I)V

    const/4 v1, 0x0

    iput-boolean v1, v5, Lait/podka/a/l;->d:Z

    const/4 v1, 0x0

    iput-boolean v1, v5, Lait/podka/a/l;->g:Z

    const/4 v1, 0x0

    iput-boolean v1, v5, Lait/podka/a/l;->e:Z

    iget-object v1, v5, Lait/podka/a/l;->h:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->n:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->o:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->p:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->q:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x0

    iput-object v1, v5, Lait/podka/a/l;->r:Ljava/lang/String;

    iget-object v1, v5, Lait/podka/a/l;->i:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-wide/16 v14, -0x1

    iput-wide v14, v5, Lait/podka/a/l;->s:J

    const-string v1, "ent_title"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v14, "ch_title"

    move-object/from16 v0, p2

    invoke-interface {v0, v14}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v14

    move-object/from16 v0, p2

    invoke-interface {v0, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v14

    const-string v15, "\\p{Cntrl}"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v1, v15, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v15

    const-string v1, "\\p{Cntrl}"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v14, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v14

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1af

    const/4 v1, 0x0

    :goto_10a
    iput-boolean v1, v5, Lait/podka/a/l;->e:Z

    const-string v1, "enc_type"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v5, Lait/podka/a/l;->b:Ljava/lang/String;

    iget-object v1, v5, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    invoke-virtual {v1, v7}, Landroid/widget/ProgressBar;->setMax(I)V

    iget-object v1, v5, Lait/podka/a/l;->p:Landroid/widget/TextView;

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v16

    invoke-static/range {v16 .. v16}, Lait/podka/d/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->h:Landroid/widget/TextView;

    invoke-virtual {v1, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v1, "enc_filename"

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    move-object/from16 v0, p2

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v5, Lait/podka/a/l;->r:Ljava/lang/String;

    iget-object v1, v5, Lait/podka/a/l;->n:Landroid/widget/TextView;

    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iput-wide v11, v5, Lait/podka/a/l;->s:J

    const-wide/16 v11, 0x0

    cmp-long v1, v9, v11

    if-lez v1, :cond_1b2

    const/4 v1, 0x1

    :goto_153
    iput-boolean v1, v5, Lait/podka/a/l;->f:Z

    iget-object v9, v5, Lait/podka/a/l;->c:Landroid/widget/TextView;

    iget-boolean v1, v5, Lait/podka/a/l;->f:Z

    if-eqz v1, :cond_1b4

    const/4 v1, 0x0

    :goto_15c
    invoke-virtual {v9, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v1, v5, Lait/podka/a/l;->q:Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iput-wide v3, v5, Lait/podka/a/l;->a:J

    const-string v1, "video"

    invoke-virtual {v13, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_178

    iget-object v1, v5, Lait/podka/a/l;->i:Landroid/widget/TextView;

    const-string v2, " Video "

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x1

    iput-boolean v1, v5, Lait/podka/a/l;->g:Z

    :cond_178
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_1bb

    :try_start_17e
    invoke-virtual {v6}, Ljava/io/File;->createNewFile()Z
    :try_end_181
    .catch Ljava/io/IOException; {:try_start_17e .. :try_end_181} :catch_1b6

    :goto_181
    invoke-virtual {v6}, Ljava/io/File;->length()J

    move-result-wide v1

    long-to-int v1, v1

    iget-object v2, v5, Lait/podka/a/l;->j:Landroid/widget/ProgressBar;

    invoke-virtual {v2, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v2, v5, Lait/podka/a/l;->o:Landroid/widget/TextView;

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lait/podka/d/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->q:Landroid/widget/TextView;

    iget v2, v5, Lait/podka/a/l;->k:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v9, Ljava/lang/Thread;

    new-instance v1, Lait/podka/a/i;

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v8}, Lait/podka/a/i;-><init>(Lait/podka/a/h;JLait/podka/a/l;Ljava/io/File;ILjava/io/File;)V

    invoke-direct {v9, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v9}, Ljava/lang/Thread;->start()V

    :goto_1ae
    return-void

    :cond_1af
    const/4 v1, 0x1

    goto/16 :goto_10a

    :cond_1b2
    const/4 v1, 0x0

    goto :goto_153

    :cond_1b4
    const/4 v1, 0x4

    goto :goto_15c

    :catch_1b6
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_181

    :cond_1bb
    iget-object v1, v5, Lait/podka/a/l;->q:Landroid/widget/TextView;

    const-string v2, "Completed"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v5, Lait/podka/a/l;->q:Landroid/widget/TextView;

    iget v2, v5, Lait/podka/a/l;->l:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v1, v5, Lait/podka/a/l;->m:Landroid/view/ViewGroup;

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setVisibility(I)V

    const/4 v1, 0x1

    iput-boolean v1, v5, Lait/podka/a/l;->d:Z

    goto :goto_1ae
.end method
