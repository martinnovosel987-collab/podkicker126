###### Class ait.podka.a.c (ait.podka.a.c)
.class final Lait/podka/a/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Comparable;
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lait/podka/a/a;

.field private volatile b:Ljava/lang/Object;

.field private final c:J

.field private volatile d:Landroid/widget/ImageView;


# direct methods
.method public constructor <init>(Lait/podka/a/a;Ljava/lang/Object;Landroid/widget/ImageView;)V
    .registers 6

    iput-object p1, p0, Lait/podka/a/c;->a:Lait/podka/a/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lait/podka/a/c;->c:J

    iput-object p2, p0, Lait/podka/a/c;->b:Ljava/lang/Object;

    iput-object p3, p0, Lait/podka/a/c;->d:Landroid/widget/ImageView;

    return-void
.end method

.method static synthetic a(Lait/podka/a/c;)Landroid/widget/ImageView;
    .registers 2

    iget-object v0, p0, Lait/podka/a/c;->d:Landroid/widget/ImageView;

    return-object v0
.end method


# virtual methods
.method public final bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 6

    check-cast p1, Lait/podka/a/c;

    iget-wide v0, p0, Lait/podka/a/c;->c:J

    iget-wide v2, p1, Lait/podka/a/c;->c:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_c

    const/4 v0, 0x1

    :goto_b
    return v0

    :cond_c
    const/4 v0, -0x1

    goto :goto_b
.end method

.method public final run()V
    .registers 5

    iget-object v0, p0, Lait/podka/a/c;->b:Ljava/lang/Object;

    iget-object v1, p0, Lait/podka/a/c;->d:Landroid/widget/ImageView;

    invoke-virtual {v1}, Landroid/widget/ImageView;->getTag()Ljava/lang/Object;

    move-result-object v1

    if-eq v0, v1, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    iget-object v0, p0, Lait/podka/a/c;->a:Lait/podka/a/a;

    iget-object v1, p0, Lait/podka/a/c;->b:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Lait/podka/a/a;->a(Ljava/lang/Object;)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v1, Ljava/lang/ref/SoftReference;

    invoke-direct {v1, v0}, Ljava/lang/ref/SoftReference;-><init>(Ljava/lang/Object;)V

    iget-object v2, p0, Lait/podka/a/c;->a:Lait/podka/a/a;

    iget-object v2, v2, Lait/podka/a/a;->a:Ljava/util/Map;

    iget-object v3, p0, Lait/podka/a/c;->b:Ljava/lang/Object;

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lait/podka/a/c;->b:Ljava/lang/Object;

    iget-object v2, p0, Lait/podka/a/c;->d:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/widget/ImageView;->getTag()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_a

    iget-object v1, p0, Lait/podka/a/c;->a:Lait/podka/a/a;

    iget-object v1, v1, Lait/podka/a/a;->b:Landroid/os/Handler;

    new-instance v2, Lait/podka/a/d;

    invoke-direct {v2, p0, v0}, Lait/podka/a/d;-><init>(Lait/podka/a/c;Landroid/graphics/Bitmap;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_a
.end method
