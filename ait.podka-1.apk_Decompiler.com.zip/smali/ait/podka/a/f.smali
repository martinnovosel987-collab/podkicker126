###### Class ait.podka.a.f (ait.podka.a.f)
.class final Lait/podka/a/f;
.super Lait/podka/a/a;


# instance fields
.field final synthetic c:Lait/podka/a/e;

.field private final synthetic d:Landroid/graphics/Bitmap;


# direct methods
.method constructor <init>(Lait/podka/a/e;)V
    .registers 5

    const/4 v2, 0x0

    iput-object p1, p0, Lait/podka/a/f;->c:Lait/podka/a/e;

    iput-object v2, p0, Lait/podka/a/f;->d:Landroid/graphics/Bitmap;

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1, v2, v2}, Lait/podka/a/a;-><init>(IILandroid/graphics/Bitmap;Landroid/graphics/Bitmap;)V

    return-void
.end method

.method private a(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 10

    const/4 v3, 0x0

    new-instance v4, Ljava/io/File;

    iget-object v0, p0, Lait/podka/a/f;->c:Lait/podka/a/e;

    invoke-static {v0}, Lait/podka/a/e;->a(Lait/podka/a/e;)Ljava/io/File;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, ".png"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-nez v0, :cond_37

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_3f

    :cond_37
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v4, v1, v2}, Ljava/io/File;->setLastModified(J)Z

    :goto_3e
    return-object v0

    :cond_3f
    :try_start_3f
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_44
    .catch Ljava/net/MalformedURLException; {:try_start_3f .. :try_end_44} :catch_ab
    .catch Ljava/io/IOException; {:try_start_3f .. :try_end_44} :catch_d7
    .catch Ljava/lang/Exception; {:try_start_3f .. :try_end_44} :catch_10b
    .catchall {:try_start_3f .. :try_end_44} :catchall_12b

    :try_start_44
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_4a
    .catch Ljava/lang/ClassCastException; {:try_start_44 .. :try_end_4a} :catch_a0
    .catch Ljava/net/MalformedURLException; {:try_start_44 .. :try_end_4a} :catch_ab
    .catch Ljava/io/IOException; {:try_start_44 .. :try_end_4a} :catch_d7
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_4a} :catch_10b
    .catchall {:try_start_44 .. :try_end_4a} :catchall_12b

    :try_start_4a
    const-string v1, "User-Agent"

    sget-object v2, Lait/podka/Podka;->d:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0x3a98

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/16 v1, 0x3a98

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    new-instance v2, Ljava/io/File;

    iget-object v1, p0, Lait/podka/a/f;->c:Lait/podka/a/e;

    invoke-static {v1}, Lait/podka/a/e;->a(Lait/podka/a/e;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v1, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_6e
    .catch Ljava/net/MalformedURLException; {:try_start_4a .. :try_end_6e} :catch_149
    .catch Ljava/io/IOException; {:try_start_4a .. :try_end_6e} :catch_13e
    .catch Ljava/lang/Exception; {:try_start_4a .. :try_end_6e} :catch_139
    .catchall {:try_start_4a .. :try_end_6e} :catchall_126

    :try_start_6e
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-static {v1, v3}, Lait/podka/d/b;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lait/podka/d/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_c4

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v5, 0x64

    new-instance v6, Ljava/io/FileOutputStream;

    invoke-direct {v6, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v1, v3, v5, v6}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    :try_end_90
    .catch Ljava/net/MalformedURLException; {:try_start_6e .. :try_end_90} :catch_150
    .catch Ljava/io/IOException; {:try_start_6e .. :try_end_90} :catch_143
    .catch Ljava/lang/Exception; {:try_start_6e .. :try_end_90} :catch_13b
    .catchall {:try_start_6e .. :try_end_90} :catchall_12e

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_99

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    :cond_99
    if-eqz v0, :cond_9e

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_9e
    move-object v0, v1

    goto :goto_3e

    :catch_a0
    move-exception v0

    :try_start_a1
    new-instance v1, Ljava/io/FileNotFoundException;

    invoke-virtual {v0}, Ljava/lang/ClassCastException;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_ab
    .catch Ljava/net/MalformedURLException; {:try_start_a1 .. :try_end_ab} :catch_ab
    .catch Ljava/io/IOException; {:try_start_a1 .. :try_end_ab} :catch_d7
    .catch Ljava/lang/Exception; {:try_start_a1 .. :try_end_ab} :catch_10b
    .catchall {:try_start_a1 .. :try_end_ab} :catchall_12b

    :catch_ab
    move-exception v0

    move-object v1, v3

    :goto_ad
    :try_start_ad
    invoke-virtual {v0}, Ljava/net/MalformedURLException;->printStackTrace()V
    :try_end_b0
    .catchall {:try_start_ad .. :try_end_b0} :catchall_134

    if-eqz v1, :cond_bb

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_bb

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    :cond_bb
    if-eqz v3, :cond_c0

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_c0
    :goto_c0
    iget-object v0, p0, Lait/podka/a/f;->d:Landroid/graphics/Bitmap;

    goto/16 :goto_3e

    :cond_c4
    :try_start_c4
    iget-object v1, p0, Lait/podka/a/f;->d:Landroid/graphics/Bitmap;
    :try_end_c6
    .catch Ljava/net/MalformedURLException; {:try_start_c4 .. :try_end_c6} :catch_150
    .catch Ljava/io/IOException; {:try_start_c4 .. :try_end_c6} :catch_143
    .catch Ljava/lang/Exception; {:try_start_c4 .. :try_end_c6} :catch_13b
    .catchall {:try_start_c4 .. :try_end_c6} :catchall_12e

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_cf

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    :cond_cf
    if-eqz v0, :cond_d4

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_d4
    move-object v0, v1

    goto/16 :goto_3e

    :catch_d7
    move-exception v0

    move-object v1, v3

    :goto_d9
    :try_start_d9
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    instance-of v0, v0, Ljava/io/FileNotFoundException;
    :try_end_de
    .catchall {:try_start_d9 .. :try_end_de} :catchall_f9

    if-eqz v0, :cond_e3

    :try_start_e0
    invoke-virtual {v4}, Ljava/io/File;->createNewFile()Z
    :try_end_e3
    .catch Ljava/io/IOException; {:try_start_e0 .. :try_end_e3} :catch_f4
    .catchall {:try_start_e0 .. :try_end_e3} :catchall_f9

    :cond_e3
    :goto_e3
    if-eqz v3, :cond_ee

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_ee

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    :cond_ee
    if-eqz v1, :cond_c0

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_c0

    :catch_f4
    move-exception v0

    :try_start_f5
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V
    :try_end_f8
    .catchall {:try_start_f5 .. :try_end_f8} :catchall_f9

    goto :goto_e3

    :catchall_f9
    move-exception v0

    :goto_fa
    if-eqz v3, :cond_105

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_105

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    :cond_105
    if-eqz v1, :cond_10a

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_10a
    throw v0

    :catch_10b
    move-exception v0

    move-object v0, v3

    :goto_10d
    :try_start_10d
    invoke-virtual {v4}, Ljava/io/File;->createNewFile()Z
    :try_end_110
    .catch Ljava/io/IOException; {:try_start_10d .. :try_end_110} :catch_121
    .catchall {:try_start_10d .. :try_end_110} :catchall_126

    :goto_110
    if-eqz v3, :cond_11b

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_11b

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    :cond_11b
    if-eqz v0, :cond_c0

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_c0

    :catch_121
    move-exception v1

    :try_start_122
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    :try_end_125
    .catchall {:try_start_122 .. :try_end_125} :catchall_126

    goto :goto_110

    :catchall_126
    move-exception v1

    move-object v7, v1

    move-object v1, v0

    move-object v0, v7

    goto :goto_fa

    :catchall_12b
    move-exception v0

    move-object v1, v3

    goto :goto_fa

    :catchall_12e
    move-exception v1

    move-object v3, v2

    move-object v7, v1

    move-object v1, v0

    move-object v0, v7

    goto :goto_fa

    :catchall_134
    move-exception v0

    move-object v7, v1

    move-object v1, v3

    move-object v3, v7

    goto :goto_fa

    :catch_139
    move-exception v1

    goto :goto_10d

    :catch_13b
    move-exception v1

    move-object v3, v2

    goto :goto_10d

    :catch_13e
    move-exception v1

    move-object v7, v1

    move-object v1, v0

    move-object v0, v7

    goto :goto_d9

    :catch_143
    move-exception v1

    move-object v3, v2

    move-object v7, v1

    move-object v1, v0

    move-object v0, v7

    goto :goto_d9

    :catch_149
    move-exception v1

    move-object v7, v1

    move-object v1, v3

    move-object v3, v0

    move-object v0, v7

    goto/16 :goto_ad

    :catch_150
    move-exception v1

    move-object v3, v0

    move-object v0, v1

    move-object v1, v2

    goto/16 :goto_ad
.end method


# virtual methods
.method protected final bridge synthetic a(Ljava/lang/Object;)Landroid/graphics/Bitmap;
    .registers 3

    check-cast p1, Ljava/lang/String;

    invoke-direct {p0, p1}, Lait/podka/a/f;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method
