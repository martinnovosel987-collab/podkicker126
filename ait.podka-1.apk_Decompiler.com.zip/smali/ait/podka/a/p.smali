###### Class ait.podka.a.p (ait.podka.a.p)
.class final Lait/podka/a/p;
.super Lait/podka/a/a;


# instance fields
.field final synthetic c:Lait/podka/a/o;


# direct methods
.method constructor <init>(Lait/podka/a/o;Landroid/content/Context;)V
    .registers 4

    const/4 v0, 0x0

    iput-object p1, p0, Lait/podka/a/p;->c:Lait/podka/a/o;

    invoke-direct {p0, v0, v0}, Lait/podka/a/a;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;)V

    return-void
.end method

.method private a(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 11

    const/4 v2, 0x0

    new-instance v4, Ljava/io/File;

    iget-object v0, p0, Lait/podka/a/p;->c:Lait/podka/a/o;

    invoke-static {v0}, Lait/podka/a/o;->a(Lait/podka/a/o;)Ljava/io/File;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, ".png"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-nez v0, :cond_37

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_38

    :cond_37
    :goto_37
    return-object v0

    :cond_38
    :try_start_38
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_3d
    .catch Ljava/net/MalformedURLException; {:try_start_38 .. :try_end_3d} :catch_a4
    .catch Ljava/io/IOException; {:try_start_38 .. :try_end_3d} :catch_cb
    .catchall {:try_start_38 .. :try_end_3d} :catchall_101

    :try_start_3d
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_43
    .catch Ljava/lang/ClassCastException; {:try_start_3d .. :try_end_43} :catch_99
    .catch Ljava/net/MalformedURLException; {:try_start_3d .. :try_end_43} :catch_a4
    .catch Ljava/io/IOException; {:try_start_3d .. :try_end_43} :catch_cb
    .catchall {:try_start_3d .. :try_end_43} :catchall_101

    :try_start_43
    const-string v1, "User-Agent"

    sget-object v3, Lait/podka/Podka;->d:Ljava/lang/String;

    invoke-virtual {v0, v1, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0x3a98

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/16 v1, 0x3a98

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    new-instance v3, Ljava/io/File;

    iget-object v1, p0, Lait/podka/a/p;->c:Lait/podka/a/o;

    invoke-static {v1}, Lait/podka/a/o;->a(Lait/podka/a/o;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v1, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_67
    .catch Ljava/net/MalformedURLException; {:try_start_43 .. :try_end_67} :catch_11a
    .catch Ljava/io/IOException; {:try_start_43 .. :try_end_67} :catch_10f
    .catchall {:try_start_43 .. :try_end_67} :catchall_104

    :try_start_67
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    new-instance v5, Ljava/io/FileOutputStream;

    invoke-direct {v5, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-static {v1, v5}, Lait/podka/d/b;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lait/podka/d/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_ba

    sget-object v5, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v6, 0x64

    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v1, v5, v6, v7}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    :try_end_89
    .catch Ljava/net/MalformedURLException; {:try_start_67 .. :try_end_89} :catch_11e
    .catch Ljava/io/IOException; {:try_start_67 .. :try_end_89} :catch_115
    .catchall {:try_start_67 .. :try_end_89} :catchall_109

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_92

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    :cond_92
    if-eqz v0, :cond_97

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_97
    move-object v0, v1

    goto :goto_37

    :catch_99
    move-exception v0

    :try_start_9a
    new-instance v1, Ljava/io/FileNotFoundException;

    invoke-virtual {v0}, Ljava/lang/ClassCastException;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_a4
    .catch Ljava/net/MalformedURLException; {:try_start_9a .. :try_end_a4} :catch_a4
    .catch Ljava/io/IOException; {:try_start_9a .. :try_end_a4} :catch_cb
    .catchall {:try_start_9a .. :try_end_a4} :catchall_101

    :catch_a4
    move-exception v0

    move-object v0, v2

    move-object v1, v2

    :goto_a7
    if-eqz v0, :cond_b2

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_b2

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    :cond_b2
    if-eqz v1, :cond_b7

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_b7
    :goto_b7
    move-object v0, v2

    goto/16 :goto_37

    :cond_ba
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_c3

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    :cond_c3
    if-eqz v0, :cond_c8

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_c8
    move-object v0, v2

    goto/16 :goto_37

    :catch_cb
    move-exception v0

    move-object v3, v2

    move-object v1, v2

    :goto_ce
    :try_start_ce
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    instance-of v0, v0, Ljava/io/FileNotFoundException;
    :try_end_d3
    .catchall {:try_start_ce .. :try_end_d3} :catchall_ee

    if-eqz v0, :cond_d8

    :try_start_d5
    invoke-virtual {v4}, Ljava/io/File;->createNewFile()Z
    :try_end_d8
    .catch Ljava/io/IOException; {:try_start_d5 .. :try_end_d8} :catch_e9
    .catchall {:try_start_d5 .. :try_end_d8} :catchall_ee

    :cond_d8
    :goto_d8
    if-eqz v3, :cond_e3

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_e3

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    :cond_e3
    if-eqz v1, :cond_b7

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_b7

    :catch_e9
    move-exception v0

    :try_start_ea
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V
    :try_end_ed
    .catchall {:try_start_ea .. :try_end_ed} :catchall_ee

    goto :goto_d8

    :catchall_ee
    move-exception v0

    move-object v2, v3

    :goto_f0
    if-eqz v2, :cond_fb

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_fb

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    :cond_fb
    if-eqz v1, :cond_100

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_100
    throw v0

    :catchall_101
    move-exception v0

    move-object v1, v2

    goto :goto_f0

    :catchall_104
    move-exception v1

    move-object v8, v1

    move-object v1, v0

    move-object v0, v8

    goto :goto_f0

    :catchall_109
    move-exception v1

    move-object v2, v3

    move-object v8, v1

    move-object v1, v0

    move-object v0, v8

    goto :goto_f0

    :catch_10f
    move-exception v1

    move-object v3, v2

    move-object v8, v1

    move-object v1, v0

    move-object v0, v8

    goto :goto_ce

    :catch_115
    move-exception v1

    move-object v8, v1

    move-object v1, v0

    move-object v0, v8

    goto :goto_ce

    :catch_11a
    move-exception v1

    move-object v1, v0

    move-object v0, v2

    goto :goto_a7

    :catch_11e
    move-exception v1

    move-object v1, v0

    move-object v0, v3

    goto :goto_a7
.end method


# virtual methods
.method protected final bridge synthetic a(Ljava/lang/Object;)Landroid/graphics/Bitmap;
    .registers 3

    check-cast p1, Ljava/lang/String;

    invoke-direct {p0, p1}, Lait/podka/a/p;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method
