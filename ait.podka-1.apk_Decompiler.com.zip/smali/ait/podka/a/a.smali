###### Class ait.podka.a.a (ait.podka.a.a)
.class public abstract Lait/podka/a/a;
.super Ljava/lang/Object;


# instance fields
.field a:Ljava/util/Map;

.field b:Landroid/os/Handler;

.field private c:Ljava/util/concurrent/Executor;

.field private d:Landroid/graphics/Bitmap;

.field private e:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(IILandroid/graphics/Bitmap;Landroid/graphics/Bitmap;)V
    .registers 13

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Lait/podka/a/a;->a:Ljava/util/Map;

    iput-object p3, p0, Lait/podka/a/a;->d:Landroid/graphics/Bitmap;

    iput-object p4, p0, Lait/podka/a/a;->e:Landroid/graphics/Bitmap;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lait/podka/a/a;->b:Landroid/os/Handler;

    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v1, 0x0

    const-wide/16 v3, 0x2710

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Ljava/util/concurrent/PriorityBlockingQueue;

    invoke-direct {v6}, Ljava/util/concurrent/PriorityBlockingQueue;-><init>()V

    new-instance v7, Lait/podka/a/b;

    invoke-direct {v7, p0, p2}, Lait/podka/a/b;-><init>(Lait/podka/a/a;I)V

    move v2, p1

    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    iput-object v0, p0, Lait/podka/a/a;->c:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public constructor <init>(Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;)V
    .registers 6

    const/4 v2, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1, v2, v2}, Lait/podka/a/a;-><init>(IILandroid/graphics/Bitmap;Landroid/graphics/Bitmap;)V

    return-void
.end method


# virtual methods
.method protected abstract a(Ljava/lang/Object;)Landroid/graphics/Bitmap;
.end method

.method public final a(Landroid/widget/ImageView;Ljava/lang/Object;)V
    .registers 5

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    if-nez p2, :cond_b

    iget-object v0, p0, Lait/podka/a/a;->d:Landroid/graphics/Bitmap;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :goto_a
    return-void

    :cond_b
    iget-object v0, p0, Lait/podka/a/a;->a:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/SoftReference;

    if-eqz v0, :cond_21

    invoke-virtual {v0}, Ljava/lang/ref/SoftReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Bitmap;

    if-eqz v0, :cond_21

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    goto :goto_a

    :cond_21
    iget-object v0, p0, Lait/podka/a/a;->e:Landroid/graphics/Bitmap;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    new-instance v0, Lait/podka/a/c;

    invoke-direct {v0, p0, p2, p1}, Lait/podka/a/c;-><init>(Lait/podka/a/a;Ljava/lang/Object;Landroid/widget/ImageView;)V

    iget-object v1, p0, Lait/podka/a/a;->c:Ljava/util/concurrent/Executor;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_a
.end method
