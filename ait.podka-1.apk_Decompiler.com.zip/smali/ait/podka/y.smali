###### Class ait.podka.y (ait.podka.y)
.class final Lait/podka/y;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/SearchActivity;

.field private b:Ljava/lang/String;

.field private c:Landroid/app/ProgressDialog;


# direct methods
.method private constructor <init>(Lait/podka/SearchActivity;)V
    .registers 2

    iput-object p1, p0, Lait/podka/y;->a:Lait/podka/SearchActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/SearchActivity;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/y;-><init>(Lait/podka/SearchActivity;)V

    return-void
.end method

.method private varargs a()Lorg/json/JSONObject;
    .registers 2

    :try_start_0
    iget-object v0, p0, Lait/podka/y;->a:Lait/podka/SearchActivity;

    iget-object v0, p0, Lait/podka/y;->b:Ljava/lang/String;

    invoke-static {v0}, Lait/podka/SearchActivity;->a(Ljava/lang/String;)Lorg/json/JSONObject;
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_9

    move-result-object v0

    :goto_8
    return-object v0

    :catch_9
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v0, 0x0

    goto :goto_8
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-direct {p0}, Lait/podka/y;->a()Lorg/json/JSONObject;

    move-result-object v0

    return-object v0
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Lorg/json/JSONObject;

    :try_start_2
    iget-object v0, p0, Lait/podka/y;->c:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_7} :catch_f

    :goto_7
    if-nez p1, :cond_14

    iget-object v0, p0, Lait/podka/y;->a:Lait/podka/SearchActivity;

    invoke-static {v0}, Lait/podka/SearchActivity;->a(Lait/podka/SearchActivity;)V

    :goto_e
    return-void

    :catch_f
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_7

    :cond_14
    iget-object v0, p0, Lait/podka/y;->a:Lait/podka/SearchActivity;

    invoke-static {v0, p1}, Lait/podka/SearchActivity;->a(Lait/podka/SearchActivity;Lorg/json/JSONObject;)V

    goto :goto_e
.end method

.method protected final onPreExecute()V
    .registers 4

    iget-object v0, p0, Lait/podka/y;->a:Lait/podka/SearchActivity;

    const/4 v1, 0x0

    const-string v2, "searching"

    invoke-static {v0, v1, v2}, Landroid/app/ProgressDialog;->show(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/app/ProgressDialog;

    move-result-object v0

    iput-object v0, p0, Lait/podka/y;->c:Landroid/app/ProgressDialog;

    iget-object v0, p0, Lait/podka/y;->a:Lait/podka/SearchActivity;

    const v1, 0x7f0b0013

    invoke-virtual {v0, v1}, Lait/podka/SearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lait/podka/y;->b:Ljava/lang/String;

    return-void
.end method
