###### Class ait.podka.w (ait.podka.w)
.class final Lait/podka/w;
.super Landroid/content/AsyncQueryHandler;


# instance fields
.field final synthetic a:Lait/podka/v;

.field private final synthetic b:Landroid/preference/Preference;


# direct methods
.method constructor <init>(Lait/podka/v;Landroid/content/ContentResolver;Landroid/preference/Preference;)V
    .registers 4

    iput-object p1, p0, Lait/podka/w;->a:Lait/podka/v;

    iput-object p3, p0, Lait/podka/w;->b:Landroid/preference/Preference;

    invoke-direct {p0, p2}, Landroid/content/AsyncQueryHandler;-><init>(Landroid/content/ContentResolver;)V

    return-void
.end method


# virtual methods
.method protected final onDeleteComplete(ILjava/lang/Object;I)V
    .registers 7

    iget-object v0, p0, Lait/podka/w;->a:Lait/podka/v;

    invoke-static {v0}, Lait/podka/v;->a(Lait/podka/v;)Lait/podka/Prefs;

    move-result-object v0

    invoke-virtual {v0}, Lait/podka/Prefs;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Deleted "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " episodes."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, p0, Lait/podka/w;->b:Landroid/preference/Preference;

    const-string v1, "Cache cleared."

    invoke-virtual {v0, v1}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    invoke-super {p0, p1, p2, p3}, Landroid/content/AsyncQueryHandler;->onDeleteComplete(ILjava/lang/Object;I)V

    return-void
.end method
