###### Class ait.podka.d.a (ait.podka.d.a)
.class public final Lait/podka/d/a;
.super Ljava/lang/Object;


# instance fields
.field private final a:J

.field private final b:J

.field private final c:J

.field private final d:J

.field private final e:J

.field private final f:J


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/32 v0, 0xea60

    iput-wide v0, p0, Lait/podka/d/a;->a:J

    const-wide/32 v0, 0x36ee80

    iput-wide v0, p0, Lait/podka/d/a;->b:J

    const-wide/32 v0, 0x5265c00

    iput-wide v0, p0, Lait/podka/d/a;->c:J

    const-wide/32 v0, 0x240c8400

    iput-wide v0, p0, Lait/podka/d/a;->d:J

    const-wide v0, 0x90321000L

    iput-wide v0, p0, Lait/podka/d/a;->e:J

    const-wide v0, 0x6c258c000L

    iput-wide v0, p0, Lait/podka/d/a;->f:J

    return-void
.end method
