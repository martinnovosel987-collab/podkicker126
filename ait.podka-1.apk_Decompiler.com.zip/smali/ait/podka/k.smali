###### Class ait.podka.k (ait.podka.k)
.class final Lait/podka/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/j;


# direct methods
.method constructor <init>(Lait/podka/j;)V
    .registers 2

    iput-object p1, p0, Lait/podka/k;->a:Lait/podka/j;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget-object v0, p0, Lait/podka/k;->a:Lait/podka/j;

    invoke-static {v0}, Lait/podka/j;->a(Lait/podka/j;)Lait/podka/PodMap;

    move-result-object v0

    invoke-virtual {v0}, Lait/podka/PodMap;->finish()V

    return-void
.end method
