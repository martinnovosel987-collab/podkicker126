###### Class ait.podka.v (ait.podka.v)
.class final Lait/podka/v;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/preference/Preference$OnPreferenceClickListener;


# instance fields
.field final synthetic a:Lait/podka/Prefs;

.field private final synthetic b:Landroid/preference/Preference;


# direct methods
.method constructor <init>(Lait/podka/Prefs;Landroid/preference/Preference;)V
    .registers 3

    iput-object p1, p0, Lait/podka/v;->a:Lait/podka/Prefs;

    iput-object p2, p0, Lait/podka/v;->b:Landroid/preference/Preference;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic a(Lait/podka/v;)Lait/podka/Prefs;
    .registers 2

    iget-object v0, p0, Lait/podka/v;->a:Lait/podka/Prefs;

    return-object v0
.end method


# virtual methods
.method public final onPreferenceClick(Landroid/preference/Preference;)Z
    .registers 8

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lait/podka/v;->a:Lait/podka/Prefs;

    invoke-virtual {v0}, Lait/podka/Prefs;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v3, "Deleting episodes."

    invoke-static {v0, v3, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    new-instance v0, Lait/podka/w;

    iget-object v3, p0, Lait/podka/v;->a:Lait/podka/Prefs;

    invoke-virtual {v3}, Lait/podka/Prefs;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    iget-object v4, p0, Lait/podka/v;->b:Landroid/preference/Preference;

    invoke-direct {v0, p0, v3, v4}, Lait/podka/w;-><init>(Lait/podka/v;Landroid/content/ContentResolver;Landroid/preference/Preference;)V

    sget-object v3, Lait/podka/database/f;->b:Landroid/net/Uri;

    move-object v4, v2

    move-object v5, v2

    invoke-virtual/range {v0 .. v5}, Landroid/content/AsyncQueryHandler;->startDelete(ILjava/lang/Object;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lait/podka/x;

    invoke-direct {v1, p0}, Lait/podka/x;-><init>(Lait/podka/v;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v0, 0x1

    return v0
.end method
