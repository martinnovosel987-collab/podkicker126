###### Class ait.podka.video.c (ait.podka.video.c)
.class final Lait/podka/video/c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# instance fields
.field final synthetic a:Lait/podka/video/b;


# direct methods
.method constructor <init>(Lait/podka/video/b;)V
    .registers 2

    iput-object p1, p0, Lait/podka/video/c;->a:Lait/podka/video/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .registers 7

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->reset()V

    iget-object v0, p0, Lait/podka/video/c;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    const-string v1, "Mediafile could not be played"

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, p0, Lait/podka/video/c;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    invoke-virtual {v0}, Lait/podka/video/VideoPlayer;->finish()V

    return v2
.end method
