###### Class ait.podka.video.e (ait.podka.video.e)
.class final Lait/podka/video/e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/video/VideoPlayer;

.field private final synthetic b:Ljava/lang/String;


# direct methods
.method constructor <init>(Lait/podka/video/VideoPlayer;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lait/podka/video/e;->a:Lait/podka/video/VideoPlayer;

    iput-object p2, p0, Lait/podka/video/e;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lait/podka/video/e;->b:Ljava/lang/String;

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "video/*"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    :try_start_12
    iget-object v1, p0, Lait/podka/video/e;->a:Lait/podka/video/VideoPlayer;

    invoke-virtual {v1, v0}, Lait/podka/video/VideoPlayer;->startActivity(Landroid/content/Intent;)V
    :try_end_17
    .catch Landroid/content/ActivityNotFoundException; {:try_start_12 .. :try_end_17} :catch_1d

    :goto_17
    iget-object v0, p0, Lait/podka/video/e;->a:Lait/podka/video/VideoPlayer;

    invoke-virtual {v0}, Lait/podka/video/VideoPlayer;->finish()V

    return-void

    :catch_1d
    move-exception v0

    invoke-virtual {v0}, Landroid/content/ActivityNotFoundException;->printStackTrace()V

    iget-object v1, p0, Lait/podka/video/e;->a:Lait/podka/video/VideoPlayer;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Landroid/content/ActivityNotFoundException;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    invoke-static {v1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_17
.end method
