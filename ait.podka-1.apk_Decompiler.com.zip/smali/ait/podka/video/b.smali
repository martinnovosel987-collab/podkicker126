###### Class ait.podka.video.b (ait.podka.video.b)
.class final Lait/podka/video/b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/video/VideoPlayer;

.field private final synthetic b:Ljava/lang/String;


# direct methods
.method constructor <init>(Lait/podka/video/VideoPlayer;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lait/podka/video/b;->a:Lait/podka/video/VideoPlayer;

    iput-object p2, p0, Lait/podka/video/b;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;
    .registers 2

    iget-object v0, p0, Lait/podka/video/b;->a:Lait/podka/video/VideoPlayer;

    return-object v0
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    iget-object v0, p0, Lait/podka/video/b;->a:Lait/podka/video/VideoPlayer;

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    iget-object v1, p0, Lait/podka/video/b;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setVideoPath(Ljava/lang/String;)V

    iget-object v0, p0, Lait/podka/video/b;->a:Lait/podka/video/VideoPlayer;

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    new-instance v1, Lait/podka/video/c;

    invoke-direct {v1, p0}, Lait/podka/video/c;-><init>(Lait/podka/video/b;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    iget-object v0, p0, Lait/podka/video/b;->a:Lait/podka/video/VideoPlayer;

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    new-instance v1, Lait/podka/video/d;

    invoke-direct {v1, p0}, Lait/podka/video/d;-><init>(Lait/podka/video/b;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    return-void
.end method
