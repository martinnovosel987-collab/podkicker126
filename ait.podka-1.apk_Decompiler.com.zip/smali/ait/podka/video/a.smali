###### Class ait.podka.video.a (ait.podka.video.a)
.class final Lait/podka/video/a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# instance fields
.field final synthetic a:Lait/podka/video/VideoPlayer;


# direct methods
.method constructor <init>(Lait/podka/video/VideoPlayer;)V
    .registers 2

    iput-object p1, p0, Lait/podka/video/a;->a:Lait/podka/video/VideoPlayer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel(Landroid/content/DialogInterface;)V
    .registers 3

    iget-object v0, p0, Lait/podka/video/a;->a:Lait/podka/video/VideoPlayer;

    invoke-virtual {v0}, Lait/podka/video/VideoPlayer;->finish()V

    return-void
.end method
