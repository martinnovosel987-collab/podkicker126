###### Class ait.podka.video.VideoPlayer (ait.podka.video.VideoPlayer)
.class public Lait/podka/video/VideoPlayer;
.super Landroid/app/Activity;


# instance fields
.field private a:Landroid/widget/VideoView;

.field private b:Landroid/widget/MediaController;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method static synthetic a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;
    .registers 2

    iget-object v0, p0, Lait/podka/video/VideoPlayer;->a:Landroid/widget/VideoView;

    return-object v0
.end method

.method static synthetic a(Lait/podka/video/VideoPlayer;Landroid/widget/MediaController;)V
    .registers 2

    iput-object p1, p0, Lait/podka/video/VideoPlayer;->b:Landroid/widget/MediaController;

    return-void
.end method

.method static synthetic a(Lait/podka/video/VideoPlayer;Ljava/lang/String;)V
    .registers 5

    new-instance v0, Landroid/content/Intent;

    const-string v1, "w003t"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "action"

    const/4 v2, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lait/podka/video/VideoPlayer;->sendBroadcast(Landroid/content/Intent;)V

    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Video"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Choose player"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lait/podka/video/a;

    invoke-direct {v1, p0}, Lait/podka/video/a;-><init>(Lait/podka/video/VideoPlayer;)V

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Podkicker"

    new-instance v2, Lait/podka/video/b;

    invoke-direct {v2, p0, p1}, Lait/podka/video/b;-><init>(Lait/podka/video/VideoPlayer;Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "External Player"

    new-instance v2, Lait/podka/video/e;

    invoke-direct {v2, p0, p1}, Lait/podka/video/e;-><init>(Lait/podka/video/VideoPlayer;Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    return-void
.end method

.method static synthetic b(Lait/podka/video/VideoPlayer;)Landroid/widget/MediaController;
    .registers 2

    iget-object v0, p0, Lait/podka/video/VideoPlayer;->b:Landroid/widget/MediaController;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 7

    const/4 v4, 0x0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const v0, 0x7f03001a

    invoke-virtual {p0, v0}, Lait/podka/video/VideoPlayer;->setContentView(I)V

    const v0, 0x7f0b003b

    invoke-virtual {p0, v0}, Lait/podka/video/VideoPlayer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/VideoView;

    iput-object v0, p0, Lait/podka/video/VideoPlayer;->a:Landroid/widget/VideoView;

    invoke-virtual {p0}, Lait/podka/video/VideoPlayer;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "enclosureID"

    const-wide/16 v2, -0x1

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    new-instance v2, Lait/podka/video/f;

    invoke-direct {v2, p0, v4}, Lait/podka/video/f;-><init>(Lait/podka/video/VideoPlayer;B)V

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Long;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    aput-object v0, v3, v4

    invoke-virtual {v2, v3}, Lait/podka/video/f;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
