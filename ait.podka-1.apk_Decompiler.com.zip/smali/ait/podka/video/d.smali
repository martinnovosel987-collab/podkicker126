###### Class ait.podka.video.d (ait.podka.video.d)
.class final Lait/podka/video/d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaPlayer$OnPreparedListener;


# instance fields
.field final synthetic a:Lait/podka/video/b;


# direct methods
.method constructor <init>(Lait/podka/video/b;)V
    .registers 2

    iput-object p1, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onPrepared(Landroid/media/MediaPlayer;)V
    .registers 5

    iget-object v0, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setKeepScreenOn(Z)V

    iget-object v0, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/VideoView;->requestFocus()Z

    iget-object v0, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/VideoView;->start()V

    iget-object v0, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    new-instance v1, Landroid/widget/MediaController;

    iget-object v2, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v2}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/MediaController;-><init>(Landroid/content/Context;)V

    invoke-static {v0, v1}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;Landroid/widget/MediaController;)V

    iget-object v0, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->b(Lait/podka/video/VideoPlayer;)Landroid/widget/MediaController;

    move-result-object v0

    iget-object v1, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v1}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v1

    invoke-static {v1}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/MediaController;->setAnchorView(Landroid/view/View;)V

    iget-object v0, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v0}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v0

    invoke-static {v0}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;)Landroid/widget/VideoView;

    move-result-object v0

    iget-object v1, p0, Lait/podka/video/d;->a:Lait/podka/video/b;

    invoke-static {v1}, Lait/podka/video/b;->a(Lait/podka/video/b;)Lait/podka/video/VideoPlayer;

    move-result-object v1

    invoke-static {v1}, Lait/podka/video/VideoPlayer;->b(Lait/podka/video/VideoPlayer;)Landroid/widget/MediaController;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setMediaController(Landroid/widget/MediaController;)V

    return-void
.end method
