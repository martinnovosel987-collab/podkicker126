###### Class ait.podka.video.f (ait.podka.video.f)
.class final Lait/podka/video/f;
.super Landroid/os/AsyncTask;


# instance fields
.field final synthetic a:Lait/podka/video/VideoPlayer;

.field private b:Ljava/lang/String;


# direct methods
.method private constructor <init>(Lait/podka/video/VideoPlayer;)V
    .registers 2

    iput-object p1, p0, Lait/podka/video/f;->a:Lait/podka/video/VideoPlayer;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lait/podka/video/VideoPlayer;B)V
    .registers 3

    invoke-direct {p0, p1}, Lait/podka/video/f;-><init>(Lait/podka/video/VideoPlayer;)V

    return-void
.end method


# virtual methods
.method protected final varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, [Ljava/lang/Long;

    const/4 v0, 0x0

    aget-object v0, p1, v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iget-object v1, p0, Lait/podka/video/f;->a:Lait/podka/video/VideoPlayer;

    invoke-virtual {v1}, Lait/podka/video/VideoPlayer;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-static {v0, v1}, Lait/podka/database/a;->a(Ljava/lang/Long;Landroid/content/ContentResolver;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lait/podka/video/f;->b:Ljava/lang/String;

    const/4 v0, 0x0

    return-object v0
.end method

.method protected final synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lait/podka/video/f;->a:Lait/podka/video/VideoPlayer;

    iget-object v1, p0, Lait/podka/video/f;->b:Ljava/lang/String;

    invoke-static {v0, v1}, Lait/podka/video/VideoPlayer;->a(Lait/podka/video/VideoPlayer;Ljava/lang/String;)V

    return-void
.end method
