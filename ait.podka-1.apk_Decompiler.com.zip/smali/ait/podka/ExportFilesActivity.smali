###### Class ait.podka.ExportFilesActivity (ait.podka.ExportFilesActivity)
.class public Lait/podka/ExportFilesActivity;
.super Landroid/app/Activity;


# instance fields
.field a:Landroid/widget/TextView;

.field b:Landroid/content/ContentResolver;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lait/podka/ExportFilesActivity;->requestWindowFeature(I)Z

    const v0, 0x7f030003

    invoke-virtual {p0, v0}, Lait/podka/ExportFilesActivity;->setContentView(I)V

    invoke-virtual {p0}, Lait/podka/ExportFilesActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v1, -0x2

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v1, -0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    invoke-virtual {p0}, Lait/podka/ExportFilesActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    invoke-virtual {p0}, Lait/podka/ExportFilesActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    const v0, 0x7f0b0004

    invoke-virtual {p0, v0}, Lait/podka/ExportFilesActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lait/podka/ExportFilesActivity;->a:Landroid/widget/TextView;

    invoke-virtual {p0}, Lait/podka/ExportFilesActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iput-object v0, p0, Lait/podka/ExportFilesActivity;->b:Landroid/content/ContentResolver;

    new-instance v0, Lait/podka/d;

    invoke-direct {v0, p0, v2}, Lait/podka/d;-><init>(Lait/podka/ExportFilesActivity;B)V

    new-array v1, v2, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lait/podka/d;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
