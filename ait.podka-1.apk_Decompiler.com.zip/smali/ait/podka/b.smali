###### Class ait.podka.b (ait.podka.b)
.class final Lait/podka/b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Lait/podka/ActivityWelcome;


# direct methods
.method constructor <init>(Lait/podka/ActivityWelcome;)V
    .registers 2

    iput-object p1, p0, Lait/podka/b;->a:Lait/podka/ActivityWelcome;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Lait/podka/b;->a:Lait/podka/ActivityWelcome;

    invoke-virtual {v0}, Lait/podka/ActivityWelcome;->a()V

    return-void
.end method
