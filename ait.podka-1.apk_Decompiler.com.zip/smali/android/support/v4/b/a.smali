###### Class android.support.v4.b.a (android.support.v4.b.a)
.class public Landroid/support/v4/b/a;
.super Landroid/support/v4/b/l;

# interfaces
.implements Ljava/util/Map;


# instance fields
.field a:Landroid/support/v4/b/f;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/b/l;-><init>()V

    return-void
.end method

.method private b()Landroid/support/v4/b/f;
    .registers 2

    iget-object v0, p0, Landroid/support/v4/b/a;->a:Landroid/support/v4/b/f;

    if-nez v0, :cond_b

    new-instance v0, Landroid/support/v4/b/b;

    invoke-direct {v0, p0}, Landroid/support/v4/b/b;-><init>(Landroid/support/v4/b/a;)V

    iput-object v0, p0, Landroid/support/v4/b/a;->a:Landroid/support/v4/b/f;

    :cond_b
    iget-object v0, p0, Landroid/support/v4/b/a;->a:Landroid/support/v4/b/f;

    return-object v0
.end method


# virtual methods
.method public entrySet()Ljava/util/Set;
    .registers 3

    invoke-direct {p0}, Landroid/support/v4/b/a;->b()Landroid/support/v4/b/f;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/b/f;->b:Landroid/support/v4/b/h;

    if-nez v1, :cond_f

    new-instance v1, Landroid/support/v4/b/h;

    invoke-direct {v1, v0}, Landroid/support/v4/b/h;-><init>(Landroid/support/v4/b/f;)V

    iput-object v1, v0, Landroid/support/v4/b/f;->b:Landroid/support/v4/b/h;

    :cond_f
    iget-object v0, v0, Landroid/support/v4/b/f;->b:Landroid/support/v4/b/h;

    return-object v0
.end method

.method public keySet()Ljava/util/Set;
    .registers 3

    invoke-direct {p0}, Landroid/support/v4/b/a;->b()Landroid/support/v4/b/f;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/b/f;->c:Landroid/support/v4/b/i;

    if-nez v1, :cond_f

    new-instance v1, Landroid/support/v4/b/i;

    invoke-direct {v1, v0}, Landroid/support/v4/b/i;-><init>(Landroid/support/v4/b/f;)V

    iput-object v1, v0, Landroid/support/v4/b/f;->c:Landroid/support/v4/b/i;

    :cond_f
    iget-object v0, v0, Landroid/support/v4/b/f;->c:Landroid/support/v4/b/i;

    return-object v0
.end method

.method public putAll(Ljava/util/Map;)V
    .registers 7

    const/4 v4, 0x0

    iget v0, p0, Landroid/support/v4/b/a;->h:I

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v1

    add-int/2addr v0, v1

    iget-object v1, p0, Landroid/support/v4/b/l;->f:[I

    array-length v1, v1

    if-ge v1, v0, :cond_2d

    iget-object v1, p0, Landroid/support/v4/b/l;->f:[I

    iget-object v2, p0, Landroid/support/v4/b/l;->g:[Ljava/lang/Object;

    invoke-super {p0, v0}, Landroid/support/v4/b/l;->a(I)V

    iget v0, p0, Landroid/support/v4/b/l;->h:I

    if-lez v0, :cond_28

    iget-object v0, p0, Landroid/support/v4/b/l;->f:[I

    iget v3, p0, Landroid/support/v4/b/l;->h:I

    invoke-static {v1, v4, v0, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Landroid/support/v4/b/l;->g:[Ljava/lang/Object;

    iget v3, p0, Landroid/support/v4/b/l;->h:I

    shl-int/lit8 v3, v3, 0x1

    invoke-static {v2, v4, v0, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_28
    iget v0, p0, Landroid/support/v4/b/l;->h:I

    invoke-static {v1, v2, v0}, Landroid/support/v4/b/l;->a([I[Ljava/lang/Object;I)V

    :cond_2d
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_35
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v2, v0}, Landroid/support/v4/b/a;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_35

    :cond_4d
    return-void
.end method

.method public values()Ljava/util/Collection;
    .registers 3

    invoke-direct {p0}, Landroid/support/v4/b/a;->b()Landroid/support/v4/b/f;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/b/f;->d:Landroid/support/v4/b/k;

    if-nez v1, :cond_f

    new-instance v1, Landroid/support/v4/b/k;

    invoke-direct {v1, v0}, Landroid/support/v4/b/k;-><init>(Landroid/support/v4/b/f;)V

    iput-object v1, v0, Landroid/support/v4/b/f;->d:Landroid/support/v4/b/k;

    :cond_f
    iget-object v0, v0, Landroid/support/v4/b/f;->d:Landroid/support/v4/b/k;

    return-object v0
.end method
