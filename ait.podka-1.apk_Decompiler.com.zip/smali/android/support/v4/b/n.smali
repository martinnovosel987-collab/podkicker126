###### Class android.support.v4.b.n (android.support.v4.b.n)
.class public final Landroid/support/v4/b/n;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/Object;

.field private static b:[C


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroid/support/v4/b/n;->a:Ljava/lang/Object;

    const/16 v0, 0x18

    new-array v0, v0, [C

    sput-object v0, Landroid/support/v4/b/n;->b:[C

    return-void
.end method

.method private static a([CICIZI)I
    .registers 10

    if-nez p4, :cond_4

    if-lez p1, :cond_32

    :cond_4
    const/16 v0, 0x63

    if-le p1, v0, :cond_33

    div-int/lit8 v1, p1, 0x64

    add-int/lit8 v0, v1, 0x30

    int-to-char v0, v0

    aput-char v0, p0, p3

    add-int/lit8 v0, p3, 0x1

    mul-int/lit8 v1, v1, 0x64

    sub-int v1, p1, v1

    :goto_15
    const/16 v2, 0x9

    if-gt v1, v2, :cond_1b

    if-eq p3, v0, :cond_27

    :cond_1b
    div-int/lit8 v2, v1, 0xa

    add-int/lit8 v3, v2, 0x30

    int-to-char v3, v3

    aput-char v3, p0, v0

    add-int/lit8 v0, v0, 0x1

    mul-int/lit8 v2, v2, 0xa

    sub-int/2addr v1, v2

    :cond_27
    add-int/lit8 v1, v1, 0x30

    int-to-char v1, v1

    aput-char v1, p0, v0

    add-int/lit8 v0, v0, 0x1

    aput-char p2, p0, v0

    add-int/lit8 p3, v0, 0x1

    :cond_32
    return p3

    :cond_33
    move v0, p3

    move v1, p1

    goto :goto_15
.end method

.method public static a(JJLjava/io/PrintWriter;)V
    .registers 7

    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-nez v0, :cond_c

    const-string v0, "--"

    invoke-virtual {p4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    :goto_b
    return-void

    :cond_c
    sub-long v0, p0, p2

    invoke-static {v0, v1, p4}, Landroid/support/v4/b/n;->b(JLjava/io/PrintWriter;)V

    goto :goto_b
.end method

.method public static a(JLjava/io/PrintWriter;)V
    .registers 3

    invoke-static {p0, p1, p2}, Landroid/support/v4/b/n;->b(JLjava/io/PrintWriter;)V

    return-void
.end method

.method private static b(JLjava/io/PrintWriter;)V
    .registers 16

    const v5, 0x15180

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v11, Landroid/support/v4/b/n;->a:Ljava/lang/Object;

    monitor-enter v11

    :try_start_8
    sget-object v0, Landroid/support/v4/b/n;->b:[C

    array-length v0, v0

    if-gez v0, :cond_12

    const/4 v0, 0x0

    new-array v0, v0, [C

    sput-object v0, Landroid/support/v4/b/n;->b:[C

    :cond_12
    sget-object v0, Landroid/support/v4/b/n;->b:[C

    const-wide/16 v1, 0x0

    cmp-long v1, p0, v1

    if-nez v1, :cond_2d

    const/4 v1, 0x0

    const/16 v2, 0x30

    aput-char v2, v0, v1

    move v0, v6

    :goto_20
    new-instance v1, Ljava/lang/String;

    sget-object v2, Landroid/support/v4/b/n;->b:[C

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3, v0}, Ljava/lang/String;-><init>([CII)V

    invoke-virtual {p2, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    monitor-exit v11

    return-void

    :cond_2d
    const-wide/16 v1, 0x0

    cmp-long v1, p0, v1

    if-lez v1, :cond_a1

    const/16 v1, 0x2b

    move v4, v1

    :goto_36
    const-wide/16 v1, 0x3e8

    rem-long v1, p0, v1

    long-to-int v12, v1

    const-wide/16 v1, 0x3e8

    div-long v1, p0, v1

    long-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v3, v1

    if-le v3, v5, :cond_b4

    const v1, 0x15180

    div-int v1, v3, v1

    mul-int v2, v1, v5

    sub-int/2addr v3, v2

    :goto_4f
    const/16 v2, 0xe10

    if-le v3, v2, :cond_b2

    div-int/lit16 v2, v3, 0xe10

    mul-int/lit16 v5, v2, 0xe10

    sub-int/2addr v3, v5

    move v10, v2

    :goto_59
    const/16 v2, 0x3c

    if-le v3, v2, :cond_af

    div-int/lit8 v2, v3, 0x3c

    mul-int/lit8 v5, v2, 0x3c

    sub-int/2addr v3, v5

    move v8, v2

    move v9, v3

    :goto_64
    const/4 v2, 0x0

    aput-char v4, v0, v2

    const/16 v2, 0x64

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v5}, Landroid/support/v4/b/n;->a([CICIZI)I

    move-result v3

    const/16 v2, 0x68

    if-eq v3, v6, :cond_a6

    move v4, v6

    :goto_75
    const/4 v5, 0x0

    move v1, v10

    invoke-static/range {v0 .. v5}, Landroid/support/v4/b/n;->a([CICIZI)I

    move-result v3

    const/16 v2, 0x6d

    if-eq v3, v6, :cond_a8

    move v4, v6

    :goto_80
    const/4 v5, 0x0

    move v1, v8

    invoke-static/range {v0 .. v5}, Landroid/support/v4/b/n;->a([CICIZI)I

    move-result v3

    const/16 v2, 0x73

    if-eq v3, v6, :cond_aa

    move v4, v6

    :goto_8b
    const/4 v5, 0x0

    move v1, v9

    invoke-static/range {v0 .. v5}, Landroid/support/v4/b/n;->a([CICIZI)I

    move-result v3

    const/16 v2, 0x6d

    const/4 v4, 0x1

    const/4 v5, 0x0

    move v1, v12

    invoke-static/range {v0 .. v5}, Landroid/support/v4/b/n;->a([CICIZI)I

    move-result v1

    const/16 v2, 0x73

    aput-char v2, v0, v1
    :try_end_9e
    .catchall {:try_start_8 .. :try_end_9e} :catchall_ac

    add-int/lit8 v0, v1, 0x1

    goto :goto_20

    :cond_a1
    const/16 v1, 0x2d

    neg-long p0, p0

    move v4, v1

    goto :goto_36

    :cond_a6
    move v4, v7

    goto :goto_75

    :cond_a8
    move v4, v7

    goto :goto_80

    :cond_aa
    move v4, v7

    goto :goto_8b

    :catchall_ac
    move-exception v0

    monitor-exit v11

    throw v0

    :cond_af
    move v8, v7

    move v9, v3

    goto :goto_64

    :cond_b2
    move v10, v7

    goto :goto_59

    :cond_b4
    move v1, v7

    goto :goto_4f
.end method
