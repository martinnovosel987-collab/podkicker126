###### Class android.support.v4.widget.d (android.support.v4.widget.d)
.class final Landroid/support/v4/widget/d;
.super Landroid/database/ContentObserver;


# instance fields
.field final synthetic a:Landroid/support/v4/widget/c;


# virtual methods
.method public final deliverSelfNotifications()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final onChange(Z)V
    .registers 3

    iget-object v0, p0, Landroid/support/v4/widget/d;->a:Landroid/support/v4/widget/c;

    invoke-virtual {v0}, Landroid/support/v4/widget/c;->c()V

    return-void
.end method
