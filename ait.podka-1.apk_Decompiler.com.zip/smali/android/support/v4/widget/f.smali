###### Class android.support.v4.widget.f (android.support.v4.widget.f)
.class interface abstract Landroid/support/v4/widget/f;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ljava/lang/CharSequence;)Landroid/database/Cursor;
.end method

.method public abstract a(Landroid/database/Cursor;)V
.end method

.method public abstract b()Landroid/database/Cursor;
.end method

.method public abstract c(Landroid/database/Cursor;)Ljava/lang/CharSequence;
.end method
