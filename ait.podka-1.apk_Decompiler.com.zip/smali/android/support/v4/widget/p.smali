###### Class android.support.v4.widget.p (android.support.v4.widget.p)
.class public final Landroid/support/v4/widget/p;
.super Ljava/lang/Object;


# static fields
.field static final b:Landroid/support/v4/widget/q;


# instance fields
.field a:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_e

    new-instance v0, Landroid/support/v4/widget/t;

    invoke-direct {v0}, Landroid/support/v4/widget/t;-><init>()V

    sput-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    :goto_d
    return-void

    :cond_e
    const/16 v1, 0x9

    if-lt v0, v1, :cond_1a

    new-instance v0, Landroid/support/v4/widget/s;

    invoke-direct {v0}, Landroid/support/v4/widget/s;-><init>()V

    sput-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    goto :goto_d

    :cond_1a
    new-instance v0, Landroid/support/v4/widget/r;

    invoke-direct {v0}, Landroid/support/v4/widget/r;-><init>()V

    sput-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    goto :goto_d
.end method

.method private constructor <init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/widget/q;->a(Landroid/content/Context;Landroid/view/animation/Interpolator;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/view/animation/Interpolator;)Landroid/support/v4/widget/p;
    .registers 3

    new-instance v0, Landroid/support/v4/widget/p;

    invoke-direct {v0, p0, p1}, Landroid/support/v4/widget/p;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    return-object v0
.end method


# virtual methods
.method public final a(IIIII)V
    .registers 13

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move v6, p5

    invoke-interface/range {v0 .. v6}, Landroid/support/v4/widget/q;->a(Ljava/lang/Object;IIIII)V

    return-void
.end method

.method public final a()Z
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->a(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final b()I
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->b(Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public final c()I
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->c(Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public final d()I
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->f(Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public final e()I
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->g(Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public final f()Z
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->d(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final g()V
    .registers 3

    sget-object v0, Landroid/support/v4/widget/p;->b:Landroid/support/v4/widget/q;

    iget-object v1, p0, Landroid/support/v4/widget/p;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Landroid/support/v4/widget/q;->e(Ljava/lang/Object;)V

    return-void
.end method
