###### Class android.support.v4.widget.z (android.support.v4.widget.z)
.class interface abstract Landroid/support/v4/widget/z;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/support/v4/widget/SlidingPaneLayout;Landroid/view/View;)V
.end method
