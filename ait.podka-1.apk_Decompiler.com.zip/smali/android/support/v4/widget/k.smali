###### Class android.support.v4.widget.k (android.support.v4.widget.k)
.class final Landroid/support/v4/widget/k;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Landroid/support/v4/widget/j;


# direct methods
.method constructor <init>(Landroid/support/v4/widget/j;)V
    .registers 2

    iput-object p1, p0, Landroid/support/v4/widget/k;->a:Landroid/support/v4/widget/j;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 8

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x0

    iget-object v5, p0, Landroid/support/v4/widget/k;->a:Landroid/support/v4/widget/j;

    iget-object v1, v5, Landroid/support/v4/widget/j;->b:Landroid/support/v4/widget/ad;

    invoke-virtual {v1}, Landroid/support/v4/widget/ad;->b()I

    move-result v2

    iget v1, v5, Landroid/support/v4/widget/j;->a:I

    if-ne v1, v6, :cond_5b

    move v3, v4

    :goto_10
    if-eqz v3, :cond_5d

    iget-object v1, v5, Landroid/support/v4/widget/j;->c:Landroid/support/v4/widget/DrawerLayout;

    invoke-virtual {v1, v6}, Landroid/support/v4/widget/DrawerLayout;->a(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_1f

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v0

    neg-int v0, v0

    :cond_1f
    add-int/2addr v0, v2

    move-object v2, v1

    move v1, v0

    :goto_22
    if-eqz v2, :cond_5a

    if-eqz v3, :cond_2c

    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    move-result v0

    if-lt v0, v1, :cond_34

    :cond_2c
    if-nez v3, :cond_5a

    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    move-result v0

    if-le v0, v1, :cond_5a

    :cond_34
    iget-object v0, v5, Landroid/support/v4/widget/j;->c:Landroid/support/v4/widget/DrawerLayout;

    invoke-virtual {v0, v2}, Landroid/support/v4/widget/DrawerLayout;->a(Landroid/view/View;)I

    move-result v0

    if-nez v0, :cond_5a

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v4/widget/DrawerLayout$LayoutParams;

    iget-object v3, v5, Landroid/support/v4/widget/j;->b:Landroid/support/v4/widget/ad;

    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    move-result v6

    invoke-virtual {v3, v2, v1, v6}, Landroid/support/v4/widget/ad;->a(Landroid/view/View;II)Z

    iput-boolean v4, v0, Landroid/support/v4/widget/DrawerLayout$LayoutParams;->c:Z

    iget-object v0, v5, Landroid/support/v4/widget/j;->c:Landroid/support/v4/widget/DrawerLayout;

    invoke-virtual {v0}, Landroid/support/v4/widget/DrawerLayout;->invalidate()V

    invoke-virtual {v5}, Landroid/support/v4/widget/j;->b()V

    iget-object v0, v5, Landroid/support/v4/widget/j;->c:Landroid/support/v4/widget/DrawerLayout;

    invoke-virtual {v0}, Landroid/support/v4/widget/DrawerLayout;->b()V

    :cond_5a
    return-void

    :cond_5b
    move v3, v0

    goto :goto_10

    :cond_5d
    iget-object v0, v5, Landroid/support/v4/widget/j;->c:Landroid/support/v4/widget/DrawerLayout;

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Landroid/support/v4/widget/DrawerLayout;->a(I)Landroid/view/View;

    move-result-object v1

    iget-object v0, v5, Landroid/support/v4/widget/j;->c:Landroid/support/v4/widget/DrawerLayout;

    invoke-virtual {v0}, Landroid/support/v4/widget/DrawerLayout;->getWidth()I

    move-result v0

    sub-int/2addr v0, v2

    move-object v2, v1

    move v1, v0

    goto :goto_22
.end method
