###### Class android.support.v4.widget.t (android.support.v4.widget.t)
.class final Landroid/support/v4/widget/t;
.super Landroid/support/v4/widget/s;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/widget/s;-><init>()V

    return-void
.end method
