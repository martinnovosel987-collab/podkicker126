###### Class android.support.v4.app.ao (android.support.v4.app.ao)
.class public interface abstract Landroid/support/v4/app/ao;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/support/v4/app/am;)Landroid/app/Notification;
.end method
