###### Class android.support.v4.app.ag (android.support.v4.app.ag)
.class final Landroid/support/v4/app/ag;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/support/v4/content/h;


# instance fields
.field final a:I

.field final b:Landroid/os/Bundle;

.field c:Landroid/support/v4/app/ae;

.field d:Landroid/support/v4/content/f;

.field e:Z

.field f:Z

.field g:Ljava/lang/Object;

.field h:Z

.field i:Z

.field j:Z

.field k:Z

.field l:Z

.field m:Z

.field n:Landroid/support/v4/app/ag;

.field final synthetic o:Landroid/support/v4/app/af;


# direct methods
.method public constructor <init>(Landroid/support/v4/app/af;ILandroid/os/Bundle;Landroid/support/v4/app/ae;)V
    .registers 5

    iput-object p1, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Landroid/support/v4/app/ag;->a:I

    iput-object p3, p0, Landroid/support/v4/app/ag;->b:Landroid/os/Bundle;

    iput-object p4, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    return-void
.end method


# virtual methods
.method final a()V
    .registers 5

    const/4 v3, 0x1

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->i:Z

    if-eqz v0, :cond_c

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->j:Z

    if-eqz v0, :cond_c

    iput-boolean v3, p0, Landroid/support/v4/app/ag;->h:Z

    :cond_b
    :goto_b
    return-void

    :cond_c
    iget-boolean v0, p0, Landroid/support/v4/app/ag;->h:Z

    if-nez v0, :cond_b

    iput-boolean v3, p0, Landroid/support/v4/app/ag;->h:Z

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_24

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "  Starting: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_24
    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    if-nez v0, :cond_38

    iget-object v0, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    if-eqz v0, :cond_38

    iget-object v0, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    iget v1, p0, Landroid/support/v4/app/ag;->a:I

    iget-object v2, p0, Landroid/support/v4/app/ag;->b:Landroid/os/Bundle;

    invoke-interface {v0, v1}, Landroid/support/v4/app/ae;->b(I)Landroid/support/v4/content/f;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    :cond_38
    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    if-eqz v0, :cond_b

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->isMemberClass()Z

    move-result v0

    if-eqz v0, :cond_6f

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v0

    if-nez v0, :cond_6f

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Object returned from onCreateLoader must not be a non-static inner member class: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_6f
    iget-boolean v0, p0, Landroid/support/v4/app/ag;->m:Z

    if-nez v0, :cond_89

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    iget v1, p0, Landroid/support/v4/app/ag;->a:I

    iget-object v2, v0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    if-eqz v2, :cond_83

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "There is already a listener registered"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_83
    iput-object p0, v0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    iput v1, v0, Landroid/support/v4/content/f;->m:I

    iput-boolean v3, p0, Landroid/support/v4/app/ag;->m:Z

    :cond_89
    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0}, Landroid/support/v4/content/f;->h()V

    goto/16 :goto_b
.end method

.method public final a(Landroid/support/v4/content/f;Ljava/lang/Object;)V
    .registers 7

    const/4 v3, 0x0

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_13

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "onLoadComplete: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_13
    iget-boolean v0, p0, Landroid/support/v4/app/ag;->l:Z

    if-eqz v0, :cond_1a

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    :cond_19
    :goto_19
    return-void

    :cond_1a
    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    iget v1, p0, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->a(I)Ljava/lang/Object;

    move-result-object v0

    if-eq v0, p0, :cond_29

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    goto :goto_19

    :cond_29
    iget-object v0, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    if-eqz v0, :cond_53

    sget-boolean v1, Landroid/support/v4/app/af;->a:Z

    if-eqz v1, :cond_3f

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "  Switching to pending loader: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_3f
    iput-object v3, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    iget-object v1, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v1, v1, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    iget v2, p0, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {v1, v2, v3}, Landroid/support/v4/b/m;->a(ILjava/lang/Object;)V

    invoke-virtual {p0}, Landroid/support/v4/app/ag;->c()V

    iget-object v1, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    invoke-virtual {v1, v0}, Landroid/support/v4/app/af;->a(Landroid/support/v4/app/ag;)V

    goto :goto_19

    :cond_53
    iget-object v0, p0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    if-ne v0, p2, :cond_5b

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->e:Z

    if-nez v0, :cond_67

    :cond_5b
    iput-object p2, p0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/ag;->e:Z

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->h:Z

    if-eqz v0, :cond_67

    invoke-virtual {p0, p1, p2}, Landroid/support/v4/app/ag;->b(Landroid/support/v4/content/f;Ljava/lang/Object;)V

    :cond_67
    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    iget v1, p0, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->a(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    if-eqz v0, :cond_86

    if-eq v0, p0, :cond_86

    const/4 v1, 0x0

    iput-boolean v1, v0, Landroid/support/v4/app/ag;->f:Z

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->c()V

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    iget v1, p0, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->b(I)V

    :cond_86
    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_19

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    invoke-virtual {v0}, Landroid/support/v4/app/af;->a()Z

    move-result v0

    if-nez v0, :cond_19

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    invoke-virtual {v0}, Landroid/support/v4/app/o;->g()V

    goto/16 :goto_19
.end method

.method public final a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 8

    :goto_0
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mId="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(I)V

    const-string v0, " mArgs="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->b:Landroid/os/Bundle;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mCallbacks="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mLoader="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    if-eqz v0, :cond_4d

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "  "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p2, p3, p4}, Landroid/support/v4/content/f;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    :cond_4d
    iget-boolean v0, p0, Landroid/support/v4/app/ag;->e:Z

    if-nez v0, :cond_55

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->f:Z

    if-eqz v0, :cond_79

    :cond_55
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mHaveData="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->e:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, "  mDeliveredData="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->f:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mData="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_79
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mStarted="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->h:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mReportNextStart="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->k:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mDestroyed="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->l:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mRetaining="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->i:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mRetainingStarted="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->j:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mListenerRegistered="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->m:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    if-eqz v0, :cond_e8

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Pending Loader "

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    const-string v0, ":"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    iget-object p0, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "  "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_0

    :cond_e8
    return-void
.end method

.method final b()V
    .registers 4

    const/4 v2, 0x0

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_13

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "  Stopping: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_13
    iput-boolean v2, p0, Landroid/support/v4/app/ag;->h:Z

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->i:Z

    if-nez v0, :cond_2d

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    if-eqz v0, :cond_2d

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->m:Z

    if-eqz v0, :cond_2d

    iput-boolean v2, p0, Landroid/support/v4/app/ag;->m:Z

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0, p0}, Landroid/support/v4/content/f;->a(Landroid/support/v4/content/h;)V

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0}, Landroid/support/v4/content/f;->j()V

    :cond_2d
    return-void
.end method

.method final b(Landroid/support/v4/content/f;Ljava/lang/Object;)V
    .registers 7

    iget-object v0, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    if-eqz v0, :cond_63

    const/4 v0, 0x0

    iget-object v1, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v1, v1, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v1, :cond_74

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iget-object v0, v0, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    iget-object v1, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v1, v1, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v1, v1, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    const-string v2, "onLoadFinished"

    iput-object v2, v1, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    move-object v1, v0

    :goto_1e
    :try_start_1e
    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_4d

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "  onLoadFinished in "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ": "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    const/16 v3, 0x40

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-static {p2, v2}, Landroid/support/v4/b/d;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    const-string v3, "}"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_4d
    iget-object v0, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    invoke-interface {v0, p2}, Landroid/support/v4/app/ae;->a(Ljava/lang/Object;)V
    :try_end_52
    .catchall {:try_start_1e .. :try_end_52} :catchall_64

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_60

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iput-object v1, v0, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    :cond_60
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/ag;->f:Z

    :cond_63
    return-void

    :catchall_64
    move-exception v0

    iget-object v2, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v2, v2, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v2, :cond_73

    iget-object v2, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v2, v2, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v2, v2, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iput-object v1, v2, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    :cond_73
    throw v0

    :cond_74
    move-object v1, v0

    goto :goto_1e
.end method

.method final c()V
    .registers 6

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_2
    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_14

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "  Destroying: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_14
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/ag;->l:Z

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->f:Z

    iput-boolean v4, p0, Landroid/support/v4/app/ag;->f:Z

    iget-object v1, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    if-eqz v1, :cond_69

    iget-object v1, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    if-eqz v1, :cond_69

    iget-boolean v1, p0, Landroid/support/v4/app/ag;->e:Z

    if-eqz v1, :cond_69

    if-eqz v0, :cond_69

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_3b

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "  Reseting: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_3b
    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_9c

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iget-object v0, v0, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    iget-object v1, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v1, v1, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v1, v1, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    const-string v3, "onLoaderReset"

    iput-object v3, v1, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    move-object v1, v0

    :goto_54
    :try_start_54
    iget-object v0, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    iget-object v3, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-interface {v0}, Landroid/support/v4/app/ae;->a_()V
    :try_end_5b
    .catchall {:try_start_54 .. :try_end_5b} :catchall_8b

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_69

    iget-object v0, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v0, v0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iput-object v1, v0, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    :cond_69
    iput-object v2, p0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    iput-object v2, p0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    iput-boolean v4, p0, Landroid/support/v4/app/ag;->e:Z

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    if-eqz v0, :cond_83

    iget-boolean v0, p0, Landroid/support/v4/app/ag;->m:Z

    if-eqz v0, :cond_7e

    iput-boolean v4, p0, Landroid/support/v4/app/ag;->m:Z

    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0, p0}, Landroid/support/v4/content/f;->a(Landroid/support/v4/content/h;)V

    :cond_7e
    iget-object v0, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {v0}, Landroid/support/v4/content/f;->k()V

    :cond_83
    iget-object v0, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    if-eqz v0, :cond_9b

    iget-object p0, p0, Landroid/support/v4/app/ag;->n:Landroid/support/v4/app/ag;

    goto/16 :goto_2

    :catchall_8b
    move-exception v0

    iget-object v2, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v2, v2, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v2, :cond_9a

    iget-object v2, p0, Landroid/support/v4/app/ag;->o:Landroid/support/v4/app/af;

    iget-object v2, v2, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v2, v2, Landroid/support/v4/app/FragmentActivity;->i:Landroid/support/v4/app/o;

    iput-object v1, v2, Landroid/support/v4/app/o;->u:Ljava/lang/String;

    :cond_9a
    throw v0

    :cond_9b
    return-void

    :cond_9c
    move-object v1, v2

    goto :goto_54
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x40

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "LoaderInfo{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " #"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " : "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-static {v1, v0}, Landroid/support/v4/b/d;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    const-string v1, "}}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
