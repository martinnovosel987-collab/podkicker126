###### Class android.support.v4.app.av (android.support.v4.app.av)
.class final Landroid/support/v4/app/av;
.super Landroid/util/AndroidRuntimeException;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    return-void
.end method
