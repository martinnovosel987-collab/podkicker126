###### Class android.support.v4.app.aj (android.support.v4.app.aj)
.class public final Landroid/support/v4/app/aj;
.super Ljava/lang/Object;


# instance fields
.field public a:I

.field public b:Ljava/lang/CharSequence;

.field public c:Landroid/app/PendingIntent;
