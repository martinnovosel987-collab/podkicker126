###### Class android.support.v4.app.z (android.support.v4.app.z)
.class public abstract Landroid/support/v4/app/z;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()I
.end method

.method public abstract a(I)Landroid/support/v4/app/z;
.end method

.method public abstract a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;
.end method

.method public abstract a(ILandroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/z;
.end method

.method public abstract a(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;
.end method

.method public abstract a(Landroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/z;
.end method

.method public abstract a(Ljava/lang/String;)Landroid/support/v4/app/z;
.end method

.method public abstract b()I
.end method

.method public abstract b(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;
.end method

.method public abstract c(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/z;
.end method
