###### Class android.support.v4.app.ak (android.support.v4.app.ak)
.class public final Landroid/support/v4/app/ak;
.super Landroid/support/v4/app/at;


# instance fields
.field a:Landroid/graphics/Bitmap;

.field b:Landroid/graphics/Bitmap;

.field c:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/app/at;-><init>()V

    return-void
.end method
