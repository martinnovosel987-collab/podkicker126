###### Class android.support.v4.app.y (android.support.v4.app.y)
.class final Landroid/support/v4/app/y;
.super Ljava/lang/Object;


# instance fields
.field final a:Ljava/lang/String;

.field final b:Ljava/lang/Class;

.field final c:Landroid/os/Bundle;

.field d:Landroid/support/v4/app/Fragment;
