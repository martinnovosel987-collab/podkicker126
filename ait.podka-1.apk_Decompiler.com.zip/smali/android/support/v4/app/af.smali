###### Class android.support.v4.app.af (android.support.v4.app.af)
.class final Landroid/support/v4/app/af;
.super Landroid/support/v4/app/ad;


# static fields
.field static a:Z


# instance fields
.field final b:Landroid/support/v4/b/m;

.field final c:Landroid/support/v4/b/m;

.field final d:Ljava/lang/String;

.field e:Landroid/support/v4/app/FragmentActivity;

.field f:Z

.field g:Z

.field h:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    sput-boolean v0, Landroid/support/v4/app/af;->a:Z

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Landroid/support/v4/app/FragmentActivity;Z)V
    .registers 5

    invoke-direct {p0}, Landroid/support/v4/app/ad;-><init>()V

    new-instance v0, Landroid/support/v4/b/m;

    invoke-direct {v0}, Landroid/support/v4/b/m;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    new-instance v0, Landroid/support/v4/b/m;

    invoke-direct {v0}, Landroid/support/v4/b/m;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    iput-object p1, p0, Landroid/support/v4/app/af;->d:Ljava/lang/String;

    iput-object p2, p0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    iput-boolean p3, p0, Landroid/support/v4/app/af;->f:Z

    return-void
.end method

.method private a(ILandroid/os/Bundle;Landroid/support/v4/app/ae;)Landroid/support/v4/app/ag;
    .registers 7

    const/4 v2, 0x0

    const/4 v0, 0x1

    :try_start_2
    iput-boolean v0, p0, Landroid/support/v4/app/af;->h:Z

    new-instance v0, Landroid/support/v4/app/ag;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1, p3}, Landroid/support/v4/app/ag;-><init>(Landroid/support/v4/app/af;ILandroid/os/Bundle;Landroid/support/v4/app/ae;)V

    invoke-interface {p3, p1}, Landroid/support/v4/app/ae;->b(I)Landroid/support/v4/content/f;

    move-result-object v1

    iput-object v1, v0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    invoke-virtual {p0, v0}, Landroid/support/v4/app/af;->a(Landroid/support/v4/app/ag;)V
    :try_end_13
    .catchall {:try_start_2 .. :try_end_13} :catchall_16

    iput-boolean v2, p0, Landroid/support/v4/app/af;->h:Z

    return-object v0

    :catchall_16
    move-exception v0

    iput-boolean v2, p0, Landroid/support/v4/app/af;->h:Z

    throw v0
.end method


# virtual methods
.method public final a(ILandroid/support/v4/app/ae;)Landroid/support/v4/content/f;
    .registers 7

    const/4 v3, 0x0

    iget-boolean v0, p0, Landroid/support/v4/app/af;->h:Z

    if-eqz v0, :cond_d

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Called while creating a loader"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d
    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, p1}, Landroid/support/v4/b/m;->a(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    sget-boolean v1, Landroid/support/v4/app/af;->a:Z

    if-eqz v1, :cond_31

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "initLoader in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": args="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_31
    if-nez v0, :cond_5b

    invoke-direct {p0, p1, v3, p2}, Landroid/support/v4/app/af;->a(ILandroid/os/Bundle;Landroid/support/v4/app/ae;)Landroid/support/v4/app/ag;

    move-result-object v0

    sget-boolean v1, Landroid/support/v4/app/af;->a:Z

    if-eqz v1, :cond_49

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "  Created new loader "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_49
    :goto_49
    iget-boolean v1, v0, Landroid/support/v4/app/ag;->e:Z

    if-eqz v1, :cond_58

    iget-boolean v1, p0, Landroid/support/v4/app/af;->f:Z

    if-eqz v1, :cond_58

    iget-object v1, v0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    iget-object v2, v0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/ag;->b(Landroid/support/v4/content/f;Ljava/lang/Object;)V

    :cond_58
    iget-object v0, v0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    return-object v0

    :cond_5b
    sget-boolean v1, Landroid/support/v4/app/af;->a:Z

    if-eqz v1, :cond_6d

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "  Re-using existing loader "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_6d
    iput-object p2, v0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    goto :goto_49
.end method

.method final a(Landroid/support/v4/app/FragmentActivity;)V
    .registers 2

    iput-object p1, p0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    return-void
.end method

.method final a(Landroid/support/v4/app/ag;)V
    .registers 4

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    iget v1, p1, Landroid/support/v4/app/ag;->a:I

    invoke-virtual {v0, v1, p1}, Landroid/support/v4/b/m;->a(ILjava/lang/Object;)V

    iget-boolean v0, p0, Landroid/support/v4/app/af;->f:Z

    if-eqz v0, :cond_e

    invoke-virtual {p1}, Landroid/support/v4/app/ag;->a()V

    :cond_e
    return-void
.end method

.method public final a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 10

    const/4 v2, 0x0

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    if-lez v0, :cond_59

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Active Loaders:"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "    "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move v1, v2

    :goto_25
    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    if-ge v1, v0, :cond_59

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v4, "  #"

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v4, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v4, v1}, Landroid/support/v4/b/m;->c(I)I

    move-result v4

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->print(I)V

    const-string v4, ": "

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    invoke-virtual {v0, v3, p2, p3, p4}, Landroid/support/v4/app/ag;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_25

    :cond_59
    iget-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    if-lez v0, :cond_af

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Inactive Loaders:"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "    "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_7c
    iget-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    if-ge v2, v0, :cond_af

    iget-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v0, v2}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "  #"

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v3, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v3, v2}, Landroid/support/v4/b/m;->c(I)I

    move-result v3

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(I)V

    const-string v3, ": "

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    invoke-virtual {v0, v1, p2, p3, p4}, Landroid/support/v4/app/ag;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7c

    :cond_af
    return-void
.end method

.method public final a()Z
    .registers 7

    const/4 v1, 0x0

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v4

    move v2, v1

    move v3, v1

    :goto_9
    if-ge v2, v4, :cond_23

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v2}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    iget-boolean v5, v0, Landroid/support/v4/app/ag;->h:Z

    if-eqz v5, :cond_21

    iget-boolean v0, v0, Landroid/support/v4/app/ag;->f:Z

    if-nez v0, :cond_21

    const/4 v0, 0x1

    :goto_1c
    or-int/2addr v3, v0

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_9

    :cond_21
    move v0, v1

    goto :goto_1c

    :cond_23
    return v3
.end method

.method final b()V
    .registers 5

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_12

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Starting in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_12
    iget-boolean v0, p0, Landroid/support/v4/app/af;->f:Z

    if-eqz v0, :cond_35

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "here"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Called doStart when already started: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_34
    return-void

    :cond_35
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/af;->f:Z

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_41
    if-ltz v1, :cond_34

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->a()V

    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_41
.end method

.method final c()V
    .registers 5

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_12

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Stopping in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_12
    iget-boolean v0, p0, Landroid/support/v4/app/af;->f:Z

    if-nez v0, :cond_35

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "here"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Called doStop when not started: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_34
    return-void

    :cond_35
    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_3e
    if-ltz v1, :cond_4f

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->b()V

    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_3e

    :cond_4f
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/af;->f:Z

    goto :goto_34
.end method

.method final d()V
    .registers 7

    const/4 v5, 0x1

    const/4 v4, 0x0

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_14

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Retaining in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_14
    iget-boolean v0, p0, Landroid/support/v4/app/af;->f:Z

    if-nez v0, :cond_37

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "here"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Called doRetain when not started: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_36
    return-void

    :cond_37
    iput-boolean v5, p0, Landroid/support/v4/app/af;->g:Z

    iput-boolean v4, p0, Landroid/support/v4/app/af;->f:Z

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_44
    if-ltz v1, :cond_36

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    sget-boolean v2, Landroid/support/v4/app/af;->a:Z

    if-eqz v2, :cond_60

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Retaining: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_60
    iput-boolean v5, v0, Landroid/support/v4/app/ag;->i:Z

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->h:Z

    iput-boolean v2, v0, Landroid/support/v4/app/ag;->j:Z

    iput-boolean v4, v0, Landroid/support/v4/app/ag;->h:Z

    const/4 v2, 0x0

    iput-object v2, v0, Landroid/support/v4/app/ag;->c:Landroid/support/v4/app/ae;

    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_44
.end method

.method final e()V
    .registers 6

    const/4 v4, 0x0

    iget-boolean v0, p0, Landroid/support/v4/app/af;->g:Z

    if-eqz v0, :cond_68

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_17

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Finished Retaining in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_17
    iput-boolean v4, p0, Landroid/support/v4/app/af;->g:Z

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_22
    if-ltz v1, :cond_68

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->i:Z

    if-eqz v2, :cond_51

    sget-boolean v2, Landroid/support/v4/app/af;->a:Z

    if-eqz v2, :cond_42

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Finished Retaining: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_42
    iput-boolean v4, v0, Landroid/support/v4/app/ag;->i:Z

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->h:Z

    iget-boolean v3, v0, Landroid/support/v4/app/ag;->j:Z

    if-eq v2, v3, :cond_51

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->h:Z

    if-nez v2, :cond_51

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->b()V

    :cond_51
    iget-boolean v2, v0, Landroid/support/v4/app/ag;->h:Z

    if-eqz v2, :cond_64

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->e:Z

    if-eqz v2, :cond_64

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->k:Z

    if-nez v2, :cond_64

    iget-object v2, v0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    iget-object v3, v0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    invoke-virtual {v0, v2, v3}, Landroid/support/v4/app/ag;->b(Landroid/support/v4/content/f;Ljava/lang/Object;)V

    :cond_64
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_22

    :cond_68
    return-void
.end method

.method final f()V
    .registers 4

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_9
    if-ltz v1, :cond_1a

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    const/4 v2, 0x1

    iput-boolean v2, v0, Landroid/support/v4/app/ag;->k:Z

    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_9

    :cond_1a
    return-void
.end method

.method final g()V
    .registers 5

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_9
    if-ltz v1, :cond_2d

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->h:Z

    if-eqz v2, :cond_29

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->k:Z

    if-eqz v2, :cond_29

    const/4 v2, 0x0

    iput-boolean v2, v0, Landroid/support/v4/app/ag;->k:Z

    iget-boolean v2, v0, Landroid/support/v4/app/ag;->e:Z

    if-eqz v2, :cond_29

    iget-object v2, v0, Landroid/support/v4/app/ag;->d:Landroid/support/v4/content/f;

    iget-object v3, v0, Landroid/support/v4/app/ag;->g:Ljava/lang/Object;

    invoke-virtual {v0, v2, v3}, Landroid/support/v4/app/ag;->b(Landroid/support/v4/content/f;Ljava/lang/Object;)V

    :cond_29
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_9

    :cond_2d
    return-void
.end method

.method final h()V
    .registers 3

    iget-boolean v0, p0, Landroid/support/v4/app/af;->g:Z

    if-nez v0, :cond_35

    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_16

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Destroying Active in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_16
    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_1f
    if-ltz v1, :cond_30

    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->c()V

    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_1f

    :cond_30
    iget-object v0, p0, Landroid/support/v4/app/af;->b:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->b()V

    :cond_35
    sget-boolean v0, Landroid/support/v4/app/af;->a:Z

    if-eqz v0, :cond_47

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Destroying Inactive in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_47
    iget-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_50
    if-ltz v1, :cond_61

    iget-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v0, v1}, Landroid/support/v4/b/m;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/ag;

    invoke-virtual {v0}, Landroid/support/v4/app/ag;->c()V

    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_50

    :cond_61
    iget-object v0, p0, Landroid/support/v4/app/af;->c:Landroid/support/v4/b/m;

    invoke-virtual {v0}, Landroid/support/v4/b/m;->b()V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "LoaderManager{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " in "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/v4/app/af;->e:Landroid/support/v4/app/FragmentActivity;

    invoke-static {v1, v0}, Landroid/support/v4/b/d;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    const-string v1, "}}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
