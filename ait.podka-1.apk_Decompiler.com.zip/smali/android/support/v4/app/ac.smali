###### Class android.support.v4.app.ac (android.support.v4.app.ac)
.class final Landroid/support/v4/app/ac;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field final synthetic a:Landroid/support/v4/app/aa;


# direct methods
.method constructor <init>(Landroid/support/v4/app/aa;)V
    .registers 2

    iput-object p1, p0, Landroid/support/v4/app/ac;->a:Landroid/support/v4/app/aa;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 7

    iget-object v0, p0, Landroid/support/v4/app/ac;->a:Landroid/support/v4/app/aa;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/support/v4/app/aa;->a(Landroid/view/View;IJ)V

    return-void
.end method
