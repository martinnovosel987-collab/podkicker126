###### Class android.support.v4.app.al (android.support.v4.app.al)
.class public final Landroid/support/v4/app/al;
.super Landroid/support/v4/app/at;


# instance fields
.field a:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/app/at;-><init>()V

    return-void
.end method
