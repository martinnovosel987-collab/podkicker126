###### Class android.support.v4.app.s (android.support.v4.app.s)
.class final Landroid/support/v4/app/s;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:I

.field final synthetic b:I

.field final synthetic c:Landroid/support/v4/app/o;


# direct methods
.method constructor <init>(Landroid/support/v4/app/o;II)V
    .registers 5

    iput-object p1, p0, Landroid/support/v4/app/s;->c:Landroid/support/v4/app/o;

    iput p2, p0, Landroid/support/v4/app/s;->a:I

    const/4 v0, 0x1

    iput v0, p0, Landroid/support/v4/app/s;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Landroid/support/v4/app/s;->c:Landroid/support/v4/app/o;

    iget-object v1, p0, Landroid/support/v4/app/s;->c:Landroid/support/v4/app/o;

    iget-object v1, v1, Landroid/support/v4/app/o;->o:Landroid/support/v4/app/FragmentActivity;

    iget-object v1, v1, Landroid/support/v4/app/FragmentActivity;->h:Landroid/os/Handler;

    const/4 v1, 0x0

    iget v2, p0, Landroid/support/v4/app/s;->a:I

    iget v3, p0, Landroid/support/v4/app/s;->b:I

    invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/app/o;->a(Ljava/lang/String;II)Z

    return-void
.end method
