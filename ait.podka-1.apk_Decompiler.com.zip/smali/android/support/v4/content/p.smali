###### Class android.support.v4.content.p (android.support.v4.content.p)
.class public final enum Landroid/support/v4/content/p;
.super Ljava/lang/Enum;


# static fields
.field public static final enum a:Landroid/support/v4/content/p;

.field public static final enum b:Landroid/support/v4/content/p;

.field public static final enum c:Landroid/support/v4/content/p;

.field private static final synthetic d:[Landroid/support/v4/content/p;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Landroid/support/v4/content/p;

    const-string v1, "PENDING"

    invoke-direct {v0, v1, v2}, Landroid/support/v4/content/p;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroid/support/v4/content/p;->a:Landroid/support/v4/content/p;

    new-instance v0, Landroid/support/v4/content/p;

    const-string v1, "RUNNING"

    invoke-direct {v0, v1, v3}, Landroid/support/v4/content/p;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroid/support/v4/content/p;->b:Landroid/support/v4/content/p;

    new-instance v0, Landroid/support/v4/content/p;

    const-string v1, "FINISHED"

    invoke-direct {v0, v1, v4}, Landroid/support/v4/content/p;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroid/support/v4/content/p;->c:Landroid/support/v4/content/p;

    const/4 v0, 0x3

    new-array v0, v0, [Landroid/support/v4/content/p;

    sget-object v1, Landroid/support/v4/content/p;->a:Landroid/support/v4/content/p;

    aput-object v1, v0, v2

    sget-object v1, Landroid/support/v4/content/p;->b:Landroid/support/v4/content/p;

    aput-object v1, v0, v3

    sget-object v1, Landroid/support/v4/content/p;->c:Landroid/support/v4/content/p;

    aput-object v1, v0, v4

    sput-object v0, Landroid/support/v4/content/p;->d:[Landroid/support/v4/content/p;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Landroid/support/v4/content/p;
    .registers 2

    const-class v0, Landroid/support/v4/content/p;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Landroid/support/v4/content/p;

    return-object v0
.end method

.method public static values()[Landroid/support/v4/content/p;
    .registers 1

    sget-object v0, Landroid/support/v4/content/p;->d:[Landroid/support/v4/content/p;

    invoke-virtual {v0}, [Landroid/support/v4/content/p;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroid/support/v4/content/p;

    return-object v0
.end method
