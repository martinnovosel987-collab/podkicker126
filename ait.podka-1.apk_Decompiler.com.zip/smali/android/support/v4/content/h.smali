###### Class android.support.v4.content.h (android.support.v4.content.h)
.class public interface abstract Landroid/support/v4/content/h;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/support/v4/content/f;Ljava/lang/Object;)V
.end method
