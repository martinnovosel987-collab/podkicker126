###### Class android.support.v4.content.q (android.support.v4.content.q)
.class abstract Landroid/support/v4/content/q;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field b:[Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(B)V
    .registers 2

    invoke-direct {p0}, Landroid/support/v4/content/q;-><init>()V

    return-void
.end method
