###### Class android.support.v4.content.i (android.support.v4.content.i)
.class abstract Landroid/support/v4/content/i;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/concurrent/ThreadFactory;

.field private static final b:Ljava/util/concurrent/BlockingQueue;

.field private static final c:Landroid/support/v4/content/o;

.field public static final d:Ljava/util/concurrent/Executor;

.field private static volatile e:Ljava/util/concurrent/Executor;


# instance fields
.field private final f:Landroid/support/v4/content/q;

.field private final g:Ljava/util/concurrent/FutureTask;

.field private volatile h:Landroid/support/v4/content/p;

.field private final i:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    new-instance v0, Landroid/support/v4/content/j;

    invoke-direct {v0}, Landroid/support/v4/content/j;-><init>()V

    sput-object v0, Landroid/support/v4/content/i;->a:Ljava/util/concurrent/ThreadFactory;

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    sput-object v0, Landroid/support/v4/content/i;->b:Ljava/util/concurrent/BlockingQueue;

    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v1, 0x5

    const/16 v2, 0x80

    const-wide/16 v3, 0x1

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    sget-object v6, Landroid/support/v4/content/i;->b:Ljava/util/concurrent/BlockingQueue;

    sget-object v7, Landroid/support/v4/content/i;->a:Ljava/util/concurrent/ThreadFactory;

    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    sput-object v0, Landroid/support/v4/content/i;->d:Ljava/util/concurrent/Executor;

    new-instance v0, Landroid/support/v4/content/o;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroid/support/v4/content/o;-><init>(B)V

    sput-object v0, Landroid/support/v4/content/i;->c:Landroid/support/v4/content/o;

    sget-object v0, Landroid/support/v4/content/i;->d:Ljava/util/concurrent/Executor;

    sput-object v0, Landroid/support/v4/content/i;->e:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Landroid/support/v4/content/p;->a:Landroid/support/v4/content/p;

    iput-object v0, p0, Landroid/support/v4/content/i;->h:Landroid/support/v4/content/p;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    iput-object v0, p0, Landroid/support/v4/content/i;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v0, Landroid/support/v4/content/k;

    invoke-direct {v0, p0}, Landroid/support/v4/content/k;-><init>(Landroid/support/v4/content/i;)V

    iput-object v0, p0, Landroid/support/v4/content/i;->f:Landroid/support/v4/content/q;

    new-instance v0, Landroid/support/v4/content/l;

    iget-object v1, p0, Landroid/support/v4/content/i;->f:Landroid/support/v4/content/q;

    invoke-direct {v0, p0, v1}, Landroid/support/v4/content/l;-><init>(Landroid/support/v4/content/i;Ljava/util/concurrent/Callable;)V

    iput-object v0, p0, Landroid/support/v4/content/i;->g:Ljava/util/concurrent/FutureTask;

    return-void
.end method

.method static synthetic a(Landroid/support/v4/content/i;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-direct {p0, p1}, Landroid/support/v4/content/i;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method static synthetic a(Landroid/support/v4/content/i;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 2

    iget-object v0, p0, Landroid/support/v4/content/i;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method private b(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    const/4 v4, 0x1

    sget-object v0, Landroid/support/v4/content/i;->c:Landroid/support/v4/content/o;

    new-instance v1, Landroid/support/v4/content/n;

    new-array v2, v4, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p1, v2, v3

    invoke-direct {v1, p0, v2}, Landroid/support/v4/content/n;-><init>(Landroid/support/v4/content/i;[Ljava/lang/Object;)V

    invoke-virtual {v0, v4, v1}, Landroid/support/v4/content/o;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    return-object p1
.end method

.method static synthetic b(Landroid/support/v4/content/i;Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, Landroid/support/v4/content/i;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-nez v0, :cond_b

    invoke-direct {p0, p1}, Landroid/support/v4/content/i;->b(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b
    return-void
.end method

.method protected static varargs c()V
    .registers 0

    return-void
.end method

.method static synthetic c(Landroid/support/v4/content/i;Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, Landroid/support/v4/content/i;->g:Ljava/util/concurrent/FutureTask;

    invoke-virtual {v0}, Ljava/util/concurrent/FutureTask;->isCancelled()Z

    move-result v0

    if-eqz v0, :cond_10

    invoke-virtual {p0}, Landroid/support/v4/content/i;->a()V

    :goto_b
    sget-object v0, Landroid/support/v4/content/p;->c:Landroid/support/v4/content/p;

    iput-object v0, p0, Landroid/support/v4/content/i;->h:Landroid/support/v4/content/p;

    return-void

    :cond_10
    invoke-virtual {p0, p1}, Landroid/support/v4/content/i;->a(Ljava/lang/Object;)V

    goto :goto_b
.end method


# virtual methods
.method public final varargs a(Ljava/util/concurrent/Executor;)Landroid/support/v4/content/i;
    .registers 4

    iget-object v0, p0, Landroid/support/v4/content/i;->h:Landroid/support/v4/content/p;

    sget-object v1, Landroid/support/v4/content/p;->a:Landroid/support/v4/content/p;

    if-eq v0, v1, :cond_13

    sget-object v0, Landroid/support/v4/content/m;->a:[I

    iget-object v1, p0, Landroid/support/v4/content/i;->h:Landroid/support/v4/content/p;

    invoke-virtual {v1}, Landroid/support/v4/content/p;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_32

    :cond_13
    sget-object v0, Landroid/support/v4/content/p;->b:Landroid/support/v4/content/p;

    iput-object v0, p0, Landroid/support/v4/content/i;->h:Landroid/support/v4/content/p;

    iget-object v0, p0, Landroid/support/v4/content/i;->f:Landroid/support/v4/content/q;

    const/4 v1, 0x0

    iput-object v1, v0, Landroid/support/v4/content/q;->b:[Ljava/lang/Object;

    iget-object v0, p0, Landroid/support/v4/content/i;->g:Ljava/util/concurrent/FutureTask;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-object p0

    :pswitch_22
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot execute task: the task is already running."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_2a
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot execute task: the task has already been executed (a task can be executed only once)"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_data_32
    .packed-switch 0x1
        :pswitch_22
        :pswitch_2a
    .end packed-switch
.end method

.method protected a()V
    .registers 1

    return-void
.end method

.method protected a(Ljava/lang/Object;)V
    .registers 2

    return-void
.end method

.method protected varargs abstract b()Ljava/lang/Object;
.end method

.method public final d()Z
    .registers 3

    iget-object v0, p0, Landroid/support/v4/content/i;->g:Ljava/util/concurrent/FutureTask;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/FutureTask;->cancel(Z)Z

    move-result v0

    return v0
.end method
