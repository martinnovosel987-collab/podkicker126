###### Class android.support.v4.content.f (android.support.v4.content.f)
.class public Landroid/support/v4/content/f;
.super Ljava/lang/Object;


# instance fields
.field public m:I

.field public n:Landroid/support/v4/content/h;

.field o:Landroid/content/Context;

.field p:Z

.field q:Z

.field r:Z

.field s:Z

.field t:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean v1, p0, Landroid/support/v4/content/f;->p:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->q:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/f;->r:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->s:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->t:Z

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/content/f;->o:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method protected a()V
    .registers 1

    return-void
.end method

.method public final a(Landroid/support/v4/content/h;)V
    .registers 4

    iget-object v0, p0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    if-nez v0, :cond_c

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "No listener register"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    iget-object v0, p0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    if-eq v0, p1, :cond_18

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Attempting to unregister the wrong listener"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_18
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 6

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mId="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/content/f;->m:I

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(I)V

    const-string v0, " mListener="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    iget-boolean v0, p0, Landroid/support/v4/content/f;->p:Z

    if-nez v0, :cond_23

    iget-boolean v0, p0, Landroid/support/v4/content/f;->s:Z

    if-nez v0, :cond_23

    iget-boolean v0, p0, Landroid/support/v4/content/f;->t:Z

    if-eqz v0, :cond_44

    :cond_23
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mStarted="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/f;->p:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mContentChanged="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/f;->s:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mProcessingChange="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/f;->t:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    :cond_44
    iget-boolean v0, p0, Landroid/support/v4/content/f;->q:Z

    if-nez v0, :cond_4c

    iget-boolean v0, p0, Landroid/support/v4/content/f;->r:Z

    if-eqz v0, :cond_63

    :cond_4c
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mAbandoned="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/f;->q:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    const-string v0, " mReset="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/f;->r:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    :cond_63
    return-void
.end method

.method public b(Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    if-eqz v0, :cond_9

    iget-object v0, p0, Landroid/support/v4/content/f;->n:Landroid/support/v4/content/h;

    invoke-interface {v0, p0, p1}, Landroid/support/v4/content/h;->a(Landroid/support/v4/content/f;Ljava/lang/Object;)V

    :cond_9
    return-void
.end method

.method protected e()V
    .registers 1

    return-void
.end method

.method protected f()V
    .registers 1

    return-void
.end method

.method protected g()V
    .registers 1

    return-void
.end method

.method public final h()V
    .registers 3

    const/4 v1, 0x0

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/f;->p:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->r:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->q:Z

    invoke-virtual {p0}, Landroid/support/v4/content/f;->e()V

    return-void
.end method

.method public final i()V
    .registers 1

    invoke-virtual {p0}, Landroid/support/v4/content/f;->a()V

    return-void
.end method

.method public final j()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/content/f;->p:Z

    invoke-virtual {p0}, Landroid/support/v4/content/f;->f()V

    return-void
.end method

.method public final k()V
    .registers 3

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/support/v4/content/f;->g()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/f;->r:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->p:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->q:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->s:Z

    iput-boolean v1, p0, Landroid/support/v4/content/f;->t:Z

    return-void
.end method

.method public final l()V
    .registers 2

    iget-boolean v0, p0, Landroid/support/v4/content/f;->p:Z

    if-eqz v0, :cond_8

    invoke-virtual {p0}, Landroid/support/v4/content/f;->a()V

    :goto_7
    return-void

    :cond_8
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/f;->s:Z

    goto :goto_7
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x40

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-static {p0, v0}, Landroid/support/v4/b/d;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    const-string v1, " id="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/v4/content/f;->m:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
