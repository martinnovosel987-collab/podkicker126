###### Class android.support.v4.content.n (android.support.v4.content.n)
.class final Landroid/support/v4/content/n;
.super Ljava/lang/Object;


# instance fields
.field final a:Landroid/support/v4/content/i;

.field final b:[Ljava/lang/Object;


# direct methods
.method varargs constructor <init>(Landroid/support/v4/content/i;[Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v4/content/n;->a:Landroid/support/v4/content/i;

    iput-object p2, p0, Landroid/support/v4/content/n;->b:[Ljava/lang/Object;

    return-void
.end method
