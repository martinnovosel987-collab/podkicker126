###### Class android.support.v4.content.g (android.support.v4.content.g)
.class public final Landroid/support/v4/content/g;
.super Landroid/database/ContentObserver;


# instance fields
.field final synthetic a:Landroid/support/v4/content/f;


# direct methods
.method public constructor <init>(Landroid/support/v4/content/f;)V
    .registers 3

    iput-object p1, p0, Landroid/support/v4/content/g;->a:Landroid/support/v4/content/f;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    invoke-direct {p0, v0}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public final deliverSelfNotifications()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final onChange(Z)V
    .registers 3

    iget-object v0, p0, Landroid/support/v4/content/g;->a:Landroid/support/v4/content/f;

    invoke-virtual {v0}, Landroid/support/v4/content/f;->l()V

    return-void
.end method
