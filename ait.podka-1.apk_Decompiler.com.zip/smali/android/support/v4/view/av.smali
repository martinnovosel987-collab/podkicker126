###### Class android.support.v4.view.av (android.support.v4.view.av)
.class final Landroid/support/v4/view/av;
.super Landroid/support/v4/view/au;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/au;-><init>()V

    return-void
.end method
