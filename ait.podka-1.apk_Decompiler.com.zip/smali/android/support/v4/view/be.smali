###### Class android.support.v4.view.be (android.support.v4.view.be)
.class interface abstract Landroid/support/v4/view/be;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/ViewGroup;Z)V
.end method
