###### Class android.support.v4.view.af (android.support.v4.view.af)
.class final Landroid/support/v4/view/af;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/support/v4/view/ae;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/widget/TextView;)V
    .registers 2

    invoke-virtual {p1}, Landroid/widget/TextView;->setSingleLine()V

    return-void
.end method
