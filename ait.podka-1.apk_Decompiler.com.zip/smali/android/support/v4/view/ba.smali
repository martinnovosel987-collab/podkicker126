###### Class android.support.v4.view.ba (android.support.v4.view.ba)
.class interface abstract Landroid/support/v4/view/ba;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/ViewConfiguration;)I
.end method
