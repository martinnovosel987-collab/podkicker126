###### Class android.support.v4.view.bf (android.support.v4.view.bf)
.class final Landroid/support/v4/view/bf;
.super Landroid/support/v4/view/bd;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/bd;-><init>()V

    return-void
.end method
