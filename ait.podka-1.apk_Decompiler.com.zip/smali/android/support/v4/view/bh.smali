###### Class android.support.v4.view.bh (android.support.v4.view.bh)
.class final Landroid/support/v4/view/bh;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 5

    check-cast p1, Landroid/support/v4/view/bl;

    check-cast p2, Landroid/support/v4/view/bl;

    iget v0, p1, Landroid/support/v4/view/bl;->b:I

    iget v1, p2, Landroid/support/v4/view/bl;->b:I

    sub-int/2addr v0, v1

    return v0
.end method
