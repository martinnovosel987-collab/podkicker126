###### Class android.support.v4.view.bl (android.support.v4.view.bl)
.class final Landroid/support/v4/view/bl;
.super Ljava/lang/Object;


# instance fields
.field a:Ljava/lang/Object;

.field b:I

.field c:Z

.field d:F

.field e:F


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
