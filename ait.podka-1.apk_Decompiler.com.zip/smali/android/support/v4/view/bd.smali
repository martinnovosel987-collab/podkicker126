###### Class android.support.v4.view.bd (android.support.v4.view.bd)
.class Landroid/support/v4/view/bd;
.super Landroid/support/v4/view/bc;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/bc;-><init>()V

    return-void
.end method
