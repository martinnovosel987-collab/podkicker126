###### Class android.support.v4.view.ap (android.support.v4.view.ap)
.class Landroid/support/v4/view/ap;
.super Landroid/support/v4/view/ao;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/ao;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Landroid/view/View;)Z
    .registers 3

    invoke-virtual {p1}, Landroid/view/View;->isOpaque()Z

    move-result v0

    return v0
.end method
