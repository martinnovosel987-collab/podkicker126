###### Class android.support.v4.view.ay (android.support.v4.view.ay)
.class final Landroid/support/v4/view/ay;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/support/v4/view/ba;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/ViewConfiguration;)I
    .registers 3

    invoke-virtual {p1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v0

    return v0
.end method
