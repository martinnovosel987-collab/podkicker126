###### Class android.support.v4.view.a.y (android.support.v4.view.a.y)
.class final Landroid/support/v4/view/a/y;
.super Landroid/support/v4/view/a/w;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/a/w;-><init>()V

    return-void
.end method
