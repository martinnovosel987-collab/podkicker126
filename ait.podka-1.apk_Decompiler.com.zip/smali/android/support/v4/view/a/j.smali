###### Class android.support.v4.view.a.j (android.support.v4.view.a.j)
.class final Landroid/support/v4/view/a/j;
.super Landroid/support/v4/view/a/n;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/a/n;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/support/v4/view/a/h;)Ljava/lang/Object;
    .registers 4

    new-instance v0, Landroid/support/v4/view/a/k;

    invoke-direct {v0, p0, p1}, Landroid/support/v4/view/a/k;-><init>(Landroid/support/v4/view/a/j;Landroid/support/v4/view/a/h;)V

    new-instance v1, Landroid/support/v4/view/a/p;

    invoke-direct {v1, v0}, Landroid/support/v4/view/a/p;-><init>(Landroid/support/v4/view/a/q;)V

    return-object v1
.end method
