###### Class android.support.v4.view.a.f (android.support.v4.view.a.f)
.class final Landroid/support/v4/view/a/f;
.super Landroid/support/v4/view/a/e;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/a/e;-><init>()V

    return-void
.end method
