###### Class android.support.v4.view.am (android.support.v4.view.am)
.class interface abstract Landroid/support/v4/view/am;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/VelocityTracker;I)F
.end method

.method public abstract b(Landroid/view/VelocityTracker;I)F
.end method
