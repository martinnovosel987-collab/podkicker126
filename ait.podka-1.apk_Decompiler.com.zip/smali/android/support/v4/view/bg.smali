###### Class android.support.v4.view.bg (android.support.v4.view.bg)
.class Landroid/support/v4/view/bg;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/support/v4/view/be;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/ViewGroup;Z)V
    .registers 3

    return-void
.end method
